# Canteen Companion - Backend Architecture

## Overview

Canteen Companion is a production-ready AI-powered canteen ordering system built with:
- **Frontend**: React + TanStack Start (SSR)
- **Backend**: TanStack Start Server Functions
- **Database**: Appwrite TablesDB
- **Storage**: Appwrite Storage
- **Authentication**: Appwrite Auth (Email/Password + OAuth ready)

---

## 🔐 Authentication & User Management

### Authentication Flow

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Client    │────▶│ Server Fn    │────▶│  Appwrite   │
│  (React)    │◀────│ (TanStack)   │◀────│   Auth      │
└─────────────┘     └──────────────┘     └─────────────┘
```

### Supported Auth Methods

1. **Email/Password** (Implemented)
   - Sign up with email verification
   - Sign in with session management
   - Secure HTTP-only cookies

2. **OAuth/SSO** (Ready for Integration)
   - Google OAuth
   - Microsoft Azure AD
   - Apple Sign-In
   
   To enable OAuth, configure providers in Appwrite Console:
   ```
   Appwrite Console → Auth → OAuth2 Providers
   ```

### Session Management

Sessions are stored in HTTP-only cookies:
- `appwrite-session-secret`: Session token
- `appwrite-session-id`: Session identifier

```typescript
// Server-side session validation
const { currentUser } = await authMiddleware()
if (!currentUser) throw new Error('Unauthorized')
```

### User Profiles

Extended user data stored in `user-profiles` table:
- Display name, phone, avatar
- Notification preferences (push, SMS, email)
- Payment preferences
- Staff/Admin roles
- GDPR consent timestamps

---

## 📦 Database Schema

### Core Tables

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     meals       │     │     orders      │     │   order-items   │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ $id             │     │ $id             │     │ $id             │
│ name            │◀────│ mealIds[]       │────▶│ orderId         │
│ description     │     │ quantities[]    │     │ mealId          │
│ price           │     │ totalPrice      │     │ quantity        │
│ category        │     │ status          │     │ unitPrice       │
│ calories        │     │ notes           │     │ addOns[]        │
│ allergens[]     │     │ pickupTime      │     │ specialInstr    │
│ isAvailable     │     │ createdBy       │     │ createdBy       │
│ createdBy       │     └─────────────────┘     └─────────────────┘
└─────────────────┘
```

### Inventory System

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  ingredients    │     │   inventory     │     │meal-ingredients │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ $id             │◀────│ ingredientId    │     │ mealId          │
│ name            │     │ quantityInStock │     │ ingredientId    │
│ category        │     │ minThreshold    │     │ quantityReq     │
│ unit            │     │ lastRestocked   │     │ isOptional      │
│ costPerUnit     │     │ expiresAt       │     │ isRemovable     │
│ allergens[]     │     │ createdBy       │     │ createdBy       │
│ isAvailable     │     └─────────────────┘     └─────────────────┘
│ createdBy       │
└─────────────────┘
```

### User Data

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  user-profiles  │     │dietary-profiles │     │   favorites     │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ displayName     │     │ restrictions[]  │     │ mealId          │
│ phoneNumber     │     │ allergens[]     │     │ createdBy       │
│ notifyByPush    │     │ dislikes[]      │     └─────────────────┘
│ notifyBySms     │     │ preferences[]   │
│ notifyByEmail   │     │ calorieGoal     │     ┌─────────────────┐
│ isStaff         │     │ proteinGoal     │     │    reviews      │
│ isAdmin         │     │ createdBy       │     ├─────────────────┤
│ gdprConsentAt   │     └─────────────────┘     │ mealId          │
│ createdBy       │                             │ rating          │
└─────────────────┘                             │ comment         │
                                                │ isVerified      │
                                                │ createdBy       │
                                                └─────────────────┘
```

### Promotions & Payments

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  promo-codes    │     │promo-redemptions│     │    payments     │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ code            │◀────│ promoCodeId     │     │ orderId         │
│ discountType    │     │ orderId         │     │ amount          │
│ discountValue   │     │ discountApplied │     │ currency        │
│ minOrderAmount  │     │ createdBy       │     │ status          │
│ maxDiscount     │     └─────────────────┘     │ transactionId   │
│ validFrom       │                             │ paidAt          │
│ validUntil      │                             │ createdBy       │
│ maxUses         │                             └─────────────────┘
│ isActive        │
│ createdBy       │
└─────────────────┘
```

---

## 🍳 Order Management System (OMS)

### Order Status Flow

```
┌──────────┐    ┌───────────┐    ┌───────────┐    ┌─────────┐    ┌───────────┐
│ PENDING  │───▶│ CONFIRMED │───▶│ PREPARING │───▶│  READY  │───▶│ PICKED_UP │
└──────────┘    └───────────┘    └───────────┘    └─────────┘    └───────────┘
      │                                                                 
      └─────────────────────────────────────────────────────────────────┐
                                                                        ▼
                                                                 ┌───────────┐
                                                                 │ CANCELLED │
                                                                 └───────────┘
```

### Kitchen Display System (KDS)

The kitchen dashboard provides:
- **Kanban Board**: Drag-and-drop order management
- **Real-time Updates**: Auto-refresh every 30 seconds
- **Priority System**: 1-10 priority levels
- **Station Assignment**: Grill, Fry, Salad, Drinks, Dessert, Assembly
- **Time Tracking**: Order age and prep time monitoring

### Kitchen Queue API

```typescript
// Add order to queue
await addToKitchenQueueFn({ data: { orderId, station: 'grill', priority: 8 } })

// Update status
await updateQueueStatusFn({ data: { queueItemId, status: 'in_progress' } })

// Reorder (drag-and-drop)
await reorderQueueFn({ data: { queueItemId, newPosition: 3 } })
```

---

## 💳 Payment Gateway Integration

### Stripe Integration (Production-Ready)

The payment system is scaffolded for Stripe integration:

```typescript
// 1. Create payment intent (server)
const { clientSecret, paymentId } = await createPaymentIntentFn({
  data: { orderId, amount: 25.99, currency: 'usd' }
})

// 2. Confirm payment (client with Stripe.js)
const { error } = await stripe.confirmPayment({
  clientSecret,
  confirmParams: { return_url: '/orders' }
})

// 3. Verify payment (server webhook or polling)
await confirmPaymentFn({ data: { paymentId } })
```

### Environment Variables Required

```env
STRIPE_SECRET_KEY=sk_live_...
VITE_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
```

### Payment Statuses

- `pending`: Payment initiated
- `processing`: Payment in progress
- `succeeded`: Payment completed
- `failed`: Payment failed
- `refunded`: Payment refunded
- `cancelled`: Payment cancelled

---

## 🔔 Notification System

### Notification Channels

1. **In-App** (Implemented)
   - Real-time notification bell
   - Notification center with read/unread status

2. **Push Notifications** (Ready for Integration)
   - Firebase Cloud Messaging integration point
   - Web Push API support

3. **Email** (Ready for Integration)
   - SendGrid/Mailgun integration point
   - Transactional email templates

4. **SMS** (Ready for Integration)
   - Twilio integration point
   - Order status updates

### Notification Types

```typescript
NOTIFICATION_TYPES = {
  ORDER_CONFIRMED: 'order_confirmed',
  ORDER_PREPARING: 'order_preparing',
  ORDER_READY: 'order_ready',      // Critical: triggers pickup alert
  ORDER_CANCELLED: 'order_cancelled',
  PROMOTION: 'promotion',
  DAILY_SPECIAL: 'daily_special',
  SYSTEM: 'system',
}
```

### Auto-Notifications

Notifications are automatically created when:
- Order status changes to "Ready"
- Payment is confirmed
- Refund is processed

---

## 🤖 AI Recommendation Engine

### Recommendation Strategies

1. **Time-Based Filtering**
   ```
   6-11 AM  → Breakfast, coffee, light meals
   11-2 PM  → Main courses, bowls, sandwiches
   2-5 PM   → Snacks, drinks, desserts
   5-9 PM   → Full dinner meals
   9+ PM    → Light late-night options
   ```

2. **Collaborative Filtering**
   - Based on similar users' order patterns
   - "Users who ordered X also ordered Y"

3. **Content-Based Filtering**
   - Matches user's dietary profile
   - Respects allergen restrictions
   - Considers calorie/protein goals

4. **Reorder Suggestions**
   - Surfaces previously ordered favorites
   - "You enjoyed this before"

### Recommendation API

```typescript
const { recommendations } = await getRecommendationsFn({ data: { limit: 6 } })

// Returns:
[
  {
    meal: { ... },
    reason: "Perfect for breakfast",
    reasonType: "time_based",
    score: 0.9
  },
  ...
]
```

---

## 🆕 Advanced Features

### Real-Time Inventory & Throttling

The system provides real-time inventory tracking with automatic meal availability updates:

```
┌─────────────────────────────────────────────────────────────┐
│                  REAL-TIME INVENTORY FLOW                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐    ┌──────────────┐    ┌─────────────────┐   │
│  │ Inventory│───▶│ Availability │───▶│ Meal Card UI    │   │
│  │ Update   │    │ Sync         │    │ (Sold Out/Low)  │   │
│  └──────────┘    └──────────────┘    └─────────────────┘   │
│       │                                      │              │
│       ▼                                      ▼              │
│  ┌──────────┐                         ┌─────────────────┐   │
│  │ Alert    │                         │ Order Validation│   │
│  │ Created  │                         │ (Pre-checkout)  │   │
│  └──────────┘                         └─────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Key Functions:**
- `getMealAvailabilityFn` - Get real-time availability for meals
- `syncMealAvailabilityFn` - Update availability based on inventory
- `syncAllMealsAvailabilityFn` - Batch sync all meals
- `validateOrderInventoryFn` - Pre-checkout inventory validation
- `checkRateLimitFn` - Rate limiting for API protection

**Alert Types:**
- `out_of_stock` - Ingredient completely depleted
- `low_stock` - Below minimum threshold
- `expiring_soon` - Approaching expiration date
- `restocked` - Inventory replenished

### Future Order Scheduling

Pre-order system with intelligent queue management:

```
┌─────────────────────────────────────────────────────────────┐
│                  SCHEDULED ORDER FLOW                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  User selects     Order created      Release time          │
│  pickup time  ───▶ with status   ───▶ calculated           │
│                   "scheduled"        (pickup - prep - 20m)  │
│                                                             │
│       │                                      │              │
│       ▼                                      ▼              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              SCHEDULED ORDERS QUEUE                  │   │
│  │  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐     │   │
│  │  │11:30 AM│  │11:45 AM│  │12:00 PM│  │12:15 PM│     │   │
│  │  │Priority│  │Priority│  │Priority│  │Priority│     │   │
│  │  │   1    │  │   2    │  │   2    │  │   3    │     │   │
│  │  └────────┘  └────────┘  └────────┘  └────────┘     │   │
│  └──────────────────────────────────────────────────────┘   │
│                          │                                  │
│                          ▼                                  │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  processScheduledQueueFn (runs periodically)         │   │
│  │  - Checks releaseToKitchenAt                         │   │
│  │  - Moves to kitchen queue                            │   │
│  │  - Sends notification to user                        │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Queue Statuses:**
- `scheduled` - Order waiting for release time
- `pending_release` - Ready to be sent to kitchen
- `released` - Sent to kitchen queue
- `failed` - Processing error (with retry)
- `cancelled` - User cancelled

**Key Functions:**
- `createScheduledOrderFn` - Create pre-order with pickup time
- `getAvailablePickupSlotsFn` - Get available time slots
- `processScheduledQueueFn` - Process pending releases
- `updateScheduledTimeFn` - Modify pickup time
- `cancelScheduledOrderFn` - Cancel scheduled order

### Rating & Feedback System

5-star rating system with AI feedback integration:

```
┌─────────────────────────────────────────────────────────────┐
│                  RATING & FEEDBACK FLOW                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐    ┌──────────────┐    ┌─────────────────┐   │
│  │ Order    │───▶│ Review       │───▶│ Rating          │   │
│  │ Completed│    │ Prompt       │    │ Aggregates      │   │
│  └──────────┘    └──────────────┘    └─────────────────┘   │
│                         │                    │              │
│                         ▼                    ▼              │
│                  ┌──────────────┐    ┌─────────────────┐   │
│                  │ Sentiment    │    │ AI Training     │   │
│                  │ Tags         │    │ Data Export     │   │
│                  └──────────────┘    └─────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Sentiment Tags:**
- **Positive:** delicious, fresh, hot, generous_portion, great_value, quick_service
- **Negative:** cold, bland, small_portion, overpriced, slow_service, disappointing

**Key Functions:**
- `submitRatingFn` - Submit rating with optional comment/tags
- `getMealReviewsFn` - Get reviews for a meal
- `getMealRatingAggregateFn` - Get aggregated rating stats
- `getTopRatedMealsFn` - Get highest-rated meals
- `getPendingReviewsFn` - Get orders awaiting review
- `getAIFeedbackDataFn` - Export data for ML training

**Rating Aggregates:**
- Average rating (1-5 scale)
- Total review count
- Rating distribution (5★, 4★, 3★, 2★, 1★)
- Verified purchase count
- Sentiment score (0-100)
- Common positive/negative tags

---

## 📊 Database Schema Overview

### Core Tables
- `meals` - Menu items with pricing, calories, allergens
- `orders` - Customer orders with status tracking
- `order-items` - Individual items in orders with customization
- `order-history` - Status change audit trail

### Inventory Tables
- `ingredients` - Raw ingredients with units and costs
- `inventory` - Stock levels with thresholds and expiry
- `meal-ingredients` - Recipe requirements per meal
- `meal-availability` - Real-time availability status
- `inventory-alerts` - Stock alerts and notifications

### User Tables
- `user-profiles` - Extended user data, preferences, roles
- `dietary-profiles` - Dietary restrictions and goals
- `favorites` - User's favorite meals
- `user-taste-profile` - AI taste preferences

### Scheduling Tables
- `scheduled-orders` - Pre-orders with pickup times
- `kitchen-queue` - Kitchen display system queue

### Rating Tables
- `reviews` - User ratings and comments
- `meal-rating-aggregates` - Aggregated rating statistics

### AI/ML Tables
- `recommendations` - AI-generated meal suggestions
- `user-similarity` - Collaborative filtering data
- `meal-embeddings` - ML feature vectors
- `contextual-offers` - Smart promotional offers
- `offer-impressions` - Offer performance tracking
- `meal-pairing-rules` - Cross-sell recommendations

### Payment Tables
- `payments` - Payment transactions
- `promo-codes` - Discount codes
- `promo-redemptions` - Code usage tracking

### Notification Tables
- `notifications` - In-app notifications
- `daily-specials` - Time-limited offers

---

## 📊 Inventory Management

### Stock Tracking

```typescript
// Check stock levels
const { inventory, stats } = await getInventoryFn({
  data: { lowStockOnly: true }
})

// Restock ingredient
await restockInventoryFn({
  data: { ingredientId, quantity: 100, expiresAt: '2024-02-01' }
})

// Check meal availability
const { available, missingIngredients } = await checkMealAvailabilityFn({
  data: { mealId, quantity: 5 }
})
```

### Automatic Inventory Deduction

When an order is placed, ingredients are automatically deducted:

```typescript
await deductInventoryForOrderFn({ data: { mealId, quantity: 2 } })
```

### Low Stock Alerts

The system tracks:
- Items below minimum threshold
- Items expiring within 7 days
- Out-of-stock ingredients

---

## 🎟️ Promo Code System

### Discount Types

1. **Percentage**: 10%, 20%, 50% off
2. **Fixed Amount**: $5, $10 off

### Validation Rules

- Validity period (validFrom/validUntil)
- Minimum order amount
- Maximum discount cap
- Usage limits (per code and per user)
- Applicable meals/categories

### Promo Code API

```typescript
// Validate at checkout
const { valid, discount, error } = await validatePromoCodeFn({
  data: { code: 'SAVE20', orderTotal: 50.00, mealIds: [...] }
})

// Redeem after payment
await redeemPromoCodeFn({
  data: { promoCodeId, orderId, discountApplied: 10.00 }
})
```

---

## ⚖️ GDPR/CCPA Compliance

### Data Subject Rights

1. **Right to Access** (Data Portability)
   ```typescript
   const { data } = await exportUserDataFn()
   // Returns all user data in JSON format
   ```

2. **Right to Erasure** (Right to be Forgotten)
   ```typescript
   await deleteUserDataFn({ data: { confirmEmail: 'user@email.com' } })
   // Deletes all user data across all tables
   ```

3. **Consent Management**
   ```typescript
   await recordGdprConsentFn({
     data: { gdprConsent: true, marketingConsent: false }
   })
   ```

### Data Retention

- Order history: Retained for 7 years (legal requirement)
- User preferences: Deleted on account deletion
- Payment data: Tokenized, never stored directly

---

## 🔒 Security Best Practices

### Server-Side Only

- All database operations via server functions
- API keys never exposed to client
- Session validation on every request

### Ownership Enforcement

```typescript
// Every query filters by createdBy
const orders = await db.orders.list([
  Query.equal('createdBy', [currentUser.$id])
])

// Updates verify ownership
if (order.createdBy !== currentUser.$id) {
  throw new Error('Forbidden')
}
```

### Input Validation

All inputs validated with Zod schemas:

```typescript
.inputValidator(z.object({
  email: z.email(),
  password: z.string().min(8),
}))
```

---

## 🚀 Deployment Checklist

### Environment Variables

```env
# Appwrite (Managed)
APPWRITE_ENDPOINT=
APPWRITE_PROJECT_ID=
APPWRITE_API_KEY=
APPWRITE_DB_ID=
APPWRITE_BUCKET_ID=

# Payment (Required for production)
STRIPE_SECRET_KEY=
VITE_PUBLIC_STRIPE_PUBLISHABLE_KEY=

# Notifications (Optional)
FIREBASE_SERVER_KEY=
SENDGRID_API_KEY=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
```

### Production Considerations

1. **Rate Limiting**: Implement at API gateway level
2. **Caching**: Add Redis for session/query caching
3. **Monitoring**: Set up error tracking (Sentry)
4. **Backups**: Configure Appwrite backup schedule
5. **SSL**: Ensure HTTPS everywhere
6. **CORS**: Configure allowed origins

---

## 📁 File Structure

```
src/
├── server/
│   ├── functions/
│   │   ├── auth.ts           # Authentication
│   │   ├── orders.ts         # Order management
│   │   ├── meals.ts          # Menu management
│   │   ├── notifications.ts  # Notification system
│   │   ├── recommendations.ts # AI recommendations
│   │   ├── payments.ts       # Payment processing
│   │   ├── user-profiles.ts  # User & GDPR
│   │   ├── inventory.ts      # Stock management
│   │   ├── promo-codes.ts    # Promotions
│   │   ├── kitchen-queue.ts  # KDS queue
│   │   └── index.ts          # Exports
│   └── lib/
│       ├── appwrite.ts       # Appwrite client
│       ├── appwrite.types.ts # Type definitions
│       ├── db.ts             # Database helpers
│       └── storage.ts        # File storage
├── components/
│   ├── admin/
│   │   ├── KitchenDashboard.tsx
│   │   └── MenuManagement.tsx
│   └── user/
│       ├── OrderTracking.tsx
│       └── DietaryPreferences.tsx
└── routes/
    ├── _protected/
    │   ├── orders.tsx
    │   ├── kitchen.tsx
    │   ├── menu-management.tsx
    │   └── preferences.tsx
    └── _public/
        └── index.tsx
```

---

## 🧪 Testing Strategy

### Unit Tests
- Server function input validation
- Business logic (discount calculations, availability checks)

### Integration Tests
- Order flow (create → pay → prepare → pickup)
- Inventory deduction on order
- Notification triggers

### E2E Tests
- User registration and login
- Complete order journey
- Kitchen dashboard operations

---

## 📈 Scaling Considerations

### Horizontal Scaling
- Stateless server functions
- Session stored in cookies (not memory)
- Database handles concurrency

### Performance Optimization
- Lazy loading for dashboard components
- Pagination for large lists
- Optimistic UI updates

### Future Enhancements
- WebSocket for real-time updates
- Redis caching layer
- CDN for static assets
- Multi-tenant support
