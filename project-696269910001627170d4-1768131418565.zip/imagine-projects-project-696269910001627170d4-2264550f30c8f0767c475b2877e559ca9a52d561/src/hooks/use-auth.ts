import { signOutFn } from '@/server/functions/auth'
import { useLoaderData } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { Models } from 'node-appwrite'
import { useState, useEffect } from 'react'

export function useAuth() {
  const [isLoading, setIsLoading] = useState(true)
  const loaderData = useLoaderData({ from: '__root__' }) as {
    currentUser: Models.User<Models.Preferences> | null
  }
  const signOut = useServerFn(signOutFn)

  useEffect(() => {
    // Once we have loader data, we're no longer loading
    setIsLoading(false)
  }, [loaderData])

  return {
    user: loaderData?.currentUser ?? null,
    currentUser: loaderData?.currentUser ?? null, // Keep for backwards compatibility
    isLoading,
    isAuthenticated: !!loaderData?.currentUser,
    signOut,
  }
}
