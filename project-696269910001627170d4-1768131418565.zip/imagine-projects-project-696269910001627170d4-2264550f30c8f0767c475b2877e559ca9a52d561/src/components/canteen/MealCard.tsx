import { Heart, Plus, Clock, Flame } from 'lucide-react'
import { motion } from 'motion/react'
import { useState } from 'react'
import {
  MealCustomizationModal,
  type MealCustomization,
} from './MealCustomizationModal'

export interface MealCardProps {
  id: string
  name: string
  description: string
  price: number
  calories?: number
  prepTime?: string
  imageUrl: string
  category: string
  isPopular?: boolean
  isFavorite?: boolean
  onAddToCart?: (
    id: string,
    customization?: MealCustomization,
    totalPrice?: number,
  ) => void
  onToggleFavorite?: (id: string) => void
}

export function MealCard({
  id,
  name,
  description,
  price,
  calories,
  prepTime = '5-10 min',
  imageUrl,
  isPopular = false,
  isFavorite = false,
  onAddToCart,
  onToggleFavorite,
}: MealCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [localFavorite, setLocalFavorite] = useState(isFavorite)
  const [isCustomizationOpen, setIsCustomizationOpen] = useState(false)

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    setLocalFavorite(!localFavorite)
    onToggleFavorite?.(id)
  }

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsCustomizationOpen(true)
  }

  const handleCustomizedAddToCart = (
    mealId: string,
    customization: MealCustomization,
    totalPrice: number,
  ) => {
    onAddToCart?.(mealId, customization, totalPrice)
    // You could add a toast notification here
    console.log('Added to cart:', { mealId, customization, totalPrice })
  }

  return (
    <>
      <motion.div
        className="group relative bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-500 border border-[#2D3436]/5"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        whileHover={{ y: -8 }}
        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      >
        {/* Image container */}
        <div className="relative h-48 overflow-hidden bg-[#F5F5F5]">
          <motion.img
            src={imageUrl}
            alt={name}
            className="w-full h-full object-cover"
            animate={{ scale: isHovered ? 1.08 : 1 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Popular badge */}
          {isPopular && (
            <motion.div
              className="absolute top-3 left-3 px-3 py-1.5 bg-[#E07A5F] text-white text-xs font-semibold rounded-full shadow-lg"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              🔥 Popular
            </motion.div>
          )}

          {/* Customizable badge */}
          <motion.div
            className="absolute top-3 left-3 px-2 py-1 bg-[#81B29A] text-white text-[10px] font-semibold rounded-full shadow-lg"
            style={{
              fontFamily: 'DM Sans, sans-serif',
              left: isPopular ? '5.5rem' : '0.75rem',
            }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            ✨ Customizable
          </motion.div>

          {/* Favorite button */}
          <motion.button
            onClick={handleFavoriteClick}
            className={`
                            absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center
                            transition-all duration-300 backdrop-blur-sm
                            ${
                              localFavorite
                                ? 'bg-[#E07A5F] text-white'
                                : 'bg-white/80 text-[#2D3436]/60 hover:bg-white hover:text-[#E07A5F]'
                            }
                        `}
            whileTap={{ scale: 0.9 }}
          >
            <Heart
              className={`w-5 h-5 ${localFavorite ? 'fill-current' : ''}`}
            />
          </motion.button>
        </div>

        {/* Content */}
        <div className="p-5">
          <div className="flex items-start justify-between gap-3 mb-2">
            <h3
              className="text-lg font-bold text-[#2D3436] leading-tight"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              {name}
            </h3>
            <span
              className="text-lg font-bold text-[#E07A5F] whitespace-nowrap"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              ${price.toFixed(2)}
            </span>
          </div>

          <p
            className="text-sm text-[#2D3436]/60 mb-4 line-clamp-2"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {description}
          </p>

          {/* Meta info */}
          <div className="flex items-center gap-4 mb-4">
            <div
              className="flex items-center gap-1.5 text-xs text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{prepTime}</span>
            </div>
            {calories && (
              <div
                className="flex items-center gap-1.5 text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>{calories} cal</span>
              </div>
            )}
          </div>

          {/* Add to cart button */}
          <motion.button
            onClick={handleAddToCart}
            className="w-full flex items-center justify-center gap-2 py-3 bg-[#2D3436] text-white font-semibold rounded-xl hover:bg-[#1a1f20] transition-colors duration-300"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Plus className="w-4 h-4" />
            Customize & Add
          </motion.button>
        </div>
      </motion.div>

      {/* Customization Modal */}
      <MealCustomizationModal
        isOpen={isCustomizationOpen}
        onClose={() => setIsCustomizationOpen(false)}
        meal={{
          id,
          name,
          description,
          price,
          calories,
          prepTime,
          imageUrl,
        }}
        onAddToCart={handleCustomizedAddToCart}
      />
    </>
  )
}
