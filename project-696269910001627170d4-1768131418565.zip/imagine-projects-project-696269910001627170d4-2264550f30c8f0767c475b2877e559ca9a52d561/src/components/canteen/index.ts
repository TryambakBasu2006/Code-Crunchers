export { Hero } from './Hero'
export { Navbar } from './Navbar'
export { CategoryNav } from './CategoryNav'
export { MealCard } from './MealCard'
export type { MealCardProps } from './MealCard'
export { MealCustomizationModal } from './MealCustomizationModal'
export type {
  MealCustomization,
  MealCustomizationModalProps,
} from './MealCustomizationModal'
export { MenuPage } from './MenuPage'
export { FeaturedMeals } from './FeaturedMeals'
export { HowItWorks } from './HowItWorks'
export { Footer } from './Footer'
export { AIRecommendations, AIRecommendationsCompact } from './AIRecommendations'
