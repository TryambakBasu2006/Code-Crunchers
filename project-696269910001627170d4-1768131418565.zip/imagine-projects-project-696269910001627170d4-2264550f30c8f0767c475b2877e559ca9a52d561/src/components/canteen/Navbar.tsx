import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { Link } from '@tanstack/react-router'
import {
  ChevronDown,
  Flame,
  Sparkles,
  Tag,
  Clock,
  Star,
  TrendingUp,
  Percent,
  ShoppingBag,
  User,
  Search,
  Zap,
  Package,
  Settings,
  ChefHat,
  LogOut,
  Heart,
  Boxes,
  UserCog,
  Brain,
  Gift,
  Calendar,
  MessageSquare,
  Activity,
  LayoutDashboard,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'

interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  image: string
  badge?: 'hot' | 'new' | 'bestseller'
  discount?: number
  rating?: number
  prepTime?: string
}

const recommendedItems: MenuItem[] = [
  {
    id: 'rec-1',
    name: 'Chowmein Special',
    description: 'Stir-fried noodles with seasonal vegetables & secret sauce',
    price: 89,
    image:
      'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400&auto=format&fit=crop&q=80',
    badge: 'bestseller',
    rating: 4.9,
    prepTime: '8 min',
  },
  {
    id: 'rec-2',
    name: 'Butter Chicken Bowl',
    description: 'Creamy tomato curry with tender chicken & basmati rice',
    price: 149,
    image:
      'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&auto=format&fit=crop&q=80',
    badge: 'hot',
    rating: 4.8,
    prepTime: '12 min',
  },
  {
    id: 'rec-3',
    name: 'Steamed Momos',
    description: 'Handmade dumplings with spicy red chutney',
    price: 79,
    image:
      'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400&auto=format&fit=crop&q=80',
    badge: 'new',
    rating: 4.7,
    prepTime: '10 min',
  },
]

const hotDeals: MenuItem[] = [
  {
    id: 'deal-1',
    name: 'Combo Meal: Fried Rice + Chilli Chicken',
    description: 'Perfect lunch combo with a cold drink',
    price: 169,
    originalPrice: 229,
    discount: 26,
    image:
      'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&auto=format&fit=crop&q=80',
    prepTime: '15 min',
  },
  {
    id: 'deal-2',
    name: 'Student Special Thali',
    description: 'Dal, rice, roti, sabzi & sweet',
    price: 99,
    originalPrice: 149,
    discount: 33,
    image:
      'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&auto=format&fit=crop&q=80',
    prepTime: '10 min',
  },
  {
    id: 'deal-3',
    name: 'Maggi + Cold Coffee',
    description: 'Quick snack combo for busy days',
    price: 69,
    originalPrice: 99,
    discount: 30,
    image:
      'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=400&auto=format&fit=crop&q=80',
    prepTime: '5 min',
  },
]

const discountOffers = [
  {
    code: 'FIRST50',
    discount: '50% OFF',
    description: 'First order discount',
    minOrder: 199,
  },
  {
    code: 'LUNCH20',
    discount: '20% OFF',
    description: 'Weekday lunch special (12-3 PM)',
    minOrder: 149,
  },
  {
    code: 'COMBO15',
    discount: '15% OFF',
    description: 'On all combo meals',
    minOrder: 0,
  },
]

export function Navbar() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const [cartCount] = useState(2)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const { user, isLoading } = useAuth()

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setActiveDropdown(null)
      }
      if (
        userMenuRef.current &&
        !userMenuRef.current.contains(event.target as Node)
      ) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const navItems = [
    { id: 'recommended', label: 'Recommended', icon: Sparkles },
    { id: 'hot-deals', label: 'Hot Deals', icon: Flame },
    { id: 'discounts', label: 'Discounts', icon: Tag },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b border-[#2D3436]/5 shadow-sm">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-[#E07A5F] to-[#C4563D] rounded-xl flex items-center justify-center shadow-lg shadow-[#E07A5F]/20">
              <span className="text-xl">🍽️</span>
            </div>
            <span
              className="text-xl font-bold text-[#2D3436]"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              Canteen<span className="text-[#E07A5F]">.</span>
            </span>
          </Link>

          {/* Navigation Items */}
          <div className="hidden md:flex items-center gap-1" ref={dropdownRef}>
            {navItems.map((item) => (
              <div key={item.id} className="relative">
                <button
                  onClick={() =>
                    setActiveDropdown(
                      activeDropdown === item.id ? null : item.id,
                    )
                  }
                  className={`
                                        flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium
                                        transition-all duration-200
                                        ${
                                          activeDropdown === item.id
                                            ? 'bg-[#2D3436] text-white'
                                            : 'text-[#2D3436]/70 hover:bg-[#F5F5F5] hover:text-[#2D3436]'
                                        }
                                    `}
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                  <ChevronDown
                    className={`w-4 h-4 transition-transform duration-200 ${activeDropdown === item.id ? 'rotate-180' : ''}`}
                  />
                </button>

                {/* Dropdown Menus */}
                <AnimatePresence>
                  {activeDropdown === item.id && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                      className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-[420px] bg-white rounded-2xl shadow-2xl shadow-[#2D3436]/15 border border-[#2D3436]/5 overflow-hidden"
                    >
                      {item.id === 'recommended' && (
                        <RecommendedDropdown items={recommendedItems} />
                      )}
                      {item.id === 'hot-deals' && (
                        <HotDealsDropdown items={hotDeals} />
                      )}
                      {item.id === 'discounts' && (
                        <DiscountsDropdown offers={discountOffers} />
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}

            {/* Menu Link */}
            <Link
              to="/menu"
              className="px-4 py-2 text-sm font-medium text-[#2D3436]/70 hover:text-[#2D3436] transition-colors"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Full Menu
            </Link>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            <button className="p-2 text-[#2D3436]/60 hover:text-[#2D3436] hover:bg-[#F5F5F5] rounded-xl transition-colors">
              <Search className="w-5 h-5" />
            </button>

            <button className="relative p-2 text-[#2D3436]/60 hover:text-[#2D3436] hover:bg-[#F5F5F5] rounded-xl transition-colors">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#E07A5F] text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* User Menu */}
            {!isLoading && (
              <>
                {user ? (
                  <div className="relative" ref={userMenuRef}>
                    <button
                      onClick={() => setUserMenuOpen(!userMenuOpen)}
                      className="flex items-center gap-2 px-3 py-2 bg-[#F5F5F5] rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    >
                      <div className="w-7 h-7 bg-gradient-to-br from-[#E07A5F] to-[#C4563D] rounded-lg flex items-center justify-center text-white text-xs font-bold">
                        {user.email?.charAt(0).toUpperCase() || 'U'}
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-[#2D3436]/60 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`}
                      />
                    </button>

                    <AnimatePresence>
                      {userMenuOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 top-full mt-2 w-64 bg-white rounded-xl shadow-xl border border-[#2D3436]/5 overflow-hidden"
                        >
                          <div className="p-3 border-b border-[#2D3436]/5">
                            <p
                              className="text-sm font-medium text-[#2D3436]"
                              style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                              {user.email}
                            </p>
                            <p
                              className="text-xs text-[#2D3436]/50"
                              style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                              Welcome back!
                            </p>
                          </div>

                          <div className="p-2">
                            <Link
                              to="/orders"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Package className="w-4 h-4 text-[#2D3436]/60" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                My Orders
                              </span>
                            </Link>
                            <Link
                              to="/scheduled"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Calendar className="w-4 h-4 text-[#3D5A80]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Scheduled Orders
                              </span>
                            </Link>
                            <Link
                              to="/reviews"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <MessageSquare className="w-4 h-4 text-[#F2CC8F]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                My Reviews
                              </span>
                            </Link>
                            <Link
                              to="/preferences"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Heart className="w-4 h-4 text-[#2D3436]/60" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Dietary Preferences
                              </span>
                            </Link>
                            <Link
                              to="/taste-profile"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Brain className="w-4 h-4 text-[#81B29A]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                AI Taste Profile
                              </span>
                            </Link>

                            {/* Admin Links */}
                            <div className="my-2 border-t border-[#2D3436]/5" />
                            <p className="px-3 py-1 text-[10px] font-medium text-[#2D3436]/40 uppercase tracking-wider">
                              Admin
                            </p>
                            <Link
                              to="/admin"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <LayoutDashboard className="w-4 h-4 text-[#3D5A80]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Admin Dashboard
                              </span>
                            </Link>
                            <Link
                              to="/kitchen"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <ChefHat className="w-4 h-4 text-[#E07A5F]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Kitchen Dashboard
                              </span>
                            </Link>
                            <Link
                              to="/menu-management"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Settings className="w-4 h-4 text-[#2D3436]/60" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Menu Management
                              </span>
                            </Link>
                            <Link
                              to="/offers"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Gift className="w-4 h-4 text-[#F2CC8F]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Contextual Offers
                              </span>
                            </Link>
                            <Link
                              to="/inventory"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Boxes className="w-4 h-4 text-[#2D3436]/60" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Inventory
                              </span>
                            </Link>
                            <Link
                              to="/inventory"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <Activity className="w-4 h-4 text-[#E07A5F]" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Real-Time Stock
                              </span>
                            </Link>
                            <Link
                              to="/settings"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition-colors"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <UserCog className="w-4 h-4 text-[#2D3436]/60" />
                              <span
                                className="text-sm text-[#2D3436]"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Settings
                              </span>
                            </Link>

                            <div className="my-2 border-t border-[#2D3436]/5" />
                            <Link
                              to="/sign-out"
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#FEE2E2] transition-colors text-[#EF4444]"
                              onClick={() => setUserMenuOpen(false)}
                            >
                              <LogOut className="w-4 h-4" />
                              <span
                                className="text-sm"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                              >
                                Sign Out
                              </span>
                            </Link>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Link
                      to="/admin-login"
                      className="hidden sm:flex items-center gap-2 px-3 py-2 text-[#2D3436]/60 text-sm font-medium rounded-xl hover:bg-[#F5F5F5] hover:text-[#2D3436] transition-colors"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      <ChefHat className="w-4 h-4" />
                      Staff
                    </Link>
                    <Link
                      to="/sign-in"
                      className="hidden sm:flex items-center gap-2 px-4 py-2 bg-[#2D3436] text-white text-sm font-medium rounded-xl hover:bg-[#1a1f20] transition-colors"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      <User className="w-4 h-4" />
                      Sign In
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}

function RecommendedDropdown({ items }: { items: MenuItem[] }) {
  return (
    <div className="p-4">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#2D3436]/5">
        <div className="w-8 h-8 bg-gradient-to-br from-[#81B29A] to-[#5A9A7A] rounded-lg flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div>
          <h3
            className="text-sm font-bold text-[#2D3436]"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            AI Recommended For You
          </h3>
          <p
            className="text-xs text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Based on your preferences
          </p>
        </div>
      </div>

      {/* Items */}
      <div className="space-y-3">
        {items.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="group flex gap-3 p-2 rounded-xl hover:bg-[#F8F8F8] cursor-pointer transition-colors"
          >
            {/* Image */}
            <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              {item.badge && (
                <div
                  className={`
                                    absolute top-1 left-1 px-1.5 py-0.5 text-[10px] font-bold rounded-md
                                    ${item.badge === 'hot' ? 'bg-[#E07A5F] text-white' : ''}
                                    ${item.badge === 'new' ? 'bg-[#81B29A] text-white' : ''}
                                    ${item.badge === 'bestseller' ? 'bg-[#F2CC8F] text-[#2D3436]' : ''}
                                `}
                >
                  {item.badge === 'hot' && '🔥 HOT'}
                  {item.badge === 'new' && '✨ NEW'}
                  {item.badge === 'bestseller' && '⭐ #1'}
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <h4
                  className="text-sm font-semibold text-[#2D3436] truncate"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {item.name}
                </h4>
                <span
                  className="text-sm font-bold text-[#E07A5F] whitespace-nowrap"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  ₹{item.price}
                </span>
              </div>
              <p
                className="text-xs text-[#2D3436]/50 line-clamp-1 mt-0.5"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {item.description}
              </p>
              <div className="flex items-center gap-3 mt-1.5">
                {item.rating && (
                  <span className="flex items-center gap-1 text-xs text-[#2D3436]/60">
                    <Star className="w-3 h-3 fill-[#F2CC8F] text-[#F2CC8F]" />
                    {item.rating}
                  </span>
                )}
                {item.prepTime && (
                  <span className="flex items-center gap-1 text-xs text-[#2D3436]/60">
                    <Clock className="w-3 h-3" />
                    {item.prepTime}
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Footer */}
      <button
        className="w-full mt-4 py-2.5 text-sm font-medium text-[#81B29A] hover:bg-[#81B29A]/10 rounded-xl transition-colors"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        View All Recommendations →
      </button>
    </div>
  )
}

function HotDealsDropdown({ items }: { items: MenuItem[] }) {
  return (
    <div className="p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#2D3436]/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-[#E07A5F] to-[#C4563D] rounded-lg flex items-center justify-center animate-pulse">
            <Flame className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3
              className="text-sm font-bold text-[#2D3436]"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              🔥 Hot Deals Today
            </h3>
            <p
              className="text-xs text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Limited time offers
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 bg-[#E07A5F]/10 rounded-lg">
          <Clock className="w-3 h-3 text-[#E07A5F]" />
          <span
            className="text-xs font-medium text-[#E07A5F]"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Ends in 2h 34m
          </span>
        </div>
      </div>

      {/* Items */}
      <div className="space-y-3">
        {items.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="group relative flex gap-3 p-3 rounded-xl bg-gradient-to-r from-[#FEF3E8] to-transparent hover:from-[#FDE8D8] cursor-pointer transition-colors border border-[#E07A5F]/10"
          >
            {/* Discount Badge */}
            {item.discount && (
              <div className="absolute -top-2 -right-2 px-2 py-1 bg-[#E07A5F] text-white text-xs font-bold rounded-lg shadow-lg shadow-[#E07A5F]/30 z-10">
                -{item.discount}%
              </div>
            )}

            {/* Image */}
            <div className="relative w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 shadow-md">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <h4
                className="text-sm font-semibold text-[#2D3436] line-clamp-1"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {item.name}
              </h4>
              <p
                className="text-xs text-[#2D3436]/50 line-clamp-1 mt-0.5"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {item.description}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <span
                  className="text-base font-bold text-[#E07A5F]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  ₹{item.price}
                </span>
                {item.originalPrice && (
                  <span
                    className="text-sm text-[#2D3436]/40 line-through"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    ₹{item.originalPrice}
                  </span>
                )}
                <span className="ml-auto flex items-center gap-1 text-xs text-[#2D3436]/50">
                  <Clock className="w-3 h-3" />
                  {item.prepTime}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Footer */}
      <button
        className="w-full mt-4 py-2.5 bg-gradient-to-r from-[#E07A5F] to-[#C4563D] text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-[#E07A5F]/30 transition-all"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        <span className="flex items-center justify-center gap-2">
          <Zap className="w-4 h-4" />
          Grab All Deals
        </span>
      </button>
    </div>
  )
}

function DiscountsDropdown({ offers }: { offers: typeof discountOffers }) {
  const [copiedCode, setCopiedCode] = useState<string | null>(null)

  const handleCopyCode = (code: string) => {
    void navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  return (
    <div className="p-4">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#2D3436]/5">
        <div className="w-8 h-8 bg-gradient-to-br from-[#F2CC8F] to-[#E5B86F] rounded-lg flex items-center justify-center">
          <Percent className="w-4 h-4 text-white" />
        </div>
        <div>
          <h3
            className="text-sm font-bold text-[#2D3436]"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Exclusive Discounts
          </h3>
          <p
            className="text-xs text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Apply at checkout
          </p>
        </div>
      </div>

      {/* Offers */}
      <div className="space-y-3">
        {offers.map((offer, index) => (
          <motion.div
            key={offer.code}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="relative p-4 rounded-xl border-2 border-dashed border-[#F2CC8F]/50 bg-gradient-to-r from-[#FDF8F3] to-white hover:border-[#F2CC8F] transition-colors"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-lg font-bold text-[#E07A5F]"
                    style={{ fontFamily: 'Fraunces, serif' }}
                  >
                    {offer.discount}
                  </span>
                  <TrendingUp className="w-4 h-4 text-[#81B29A]" />
                </div>
                <p
                  className="text-xs text-[#2D3436]/60 mt-0.5"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {offer.description}
                </p>
                {offer.minOrder > 0 && (
                  <p
                    className="text-[10px] text-[#2D3436]/40 mt-1"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Min. order: ₹{offer.minOrder}
                  </p>
                )}
              </div>
              <button
                onClick={() => handleCopyCode(offer.code)}
                className={`
                                    px-3 py-2 rounded-lg text-xs font-bold transition-all
                                    ${
                                      copiedCode === offer.code
                                        ? 'bg-[#81B29A] text-white'
                                        : 'bg-[#2D3436] text-white hover:bg-[#1a1f20]'
                                    }
                                `}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {copiedCode === offer.code ? '✓ Copied!' : offer.code}
              </button>
            </div>

            {/* Decorative circles */}
            <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full border-2 border-[#F2CC8F]/30" />
            <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full border-2 border-[#F2CC8F]/30" />
          </motion.div>
        ))}
      </div>

      {/* Promo Banner */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="mt-4 p-3 bg-gradient-to-r from-[#2D3436] to-[#3D4446] rounded-xl text-white"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
            <span className="text-xl">🎉</span>
          </div>
          <div className="flex-1">
            <p
              className="text-xs font-semibold"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Refer a friend & get ₹100 off!
            </p>
            <p
              className="text-[10px] text-white/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Share your code and earn rewards
            </p>
          </div>
          <button
            className="px-3 py-1.5 bg-white text-[#2D3436] text-xs font-bold rounded-lg hover:bg-white/90 transition-colors"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Share
          </button>
        </div>
      </motion.div>
    </div>
  )
}
