import { Search, Sparkles } from 'lucide-react'
import { motion } from 'motion/react'
import { useState } from 'react'

export function Hero() {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
      {/* Warm gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#FDF8F3] via-[#FEF3E8] to-[#F5EDE4]" />

      {/* Decorative blobs */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 bg-[#E07A5F]/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 bg-[#81B29A]/10 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Floating food illustrations */}
      <motion.div
        className="absolute top-32 right-[15%] text-6xl"
        animate={{ y: [0, -15, 0], rotate: [0, 5, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
      >
        🍜
      </motion.div>
      <motion.div
        className="absolute top-48 left-[12%] text-5xl"
        animate={{ y: [0, -12, 0], rotate: [0, -5, 0] }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 0.5,
        }}
      >
        🥗
      </motion.div>
      <motion.div
        className="absolute bottom-32 left-[20%] text-5xl"
        animate={{ y: [0, -10, 0], rotate: [0, 8, 0] }}
        transition={{
          duration: 4.5,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 1,
        }}
      >
        🍛
      </motion.div>
      <motion.div
        className="absolute bottom-40 right-[18%] text-6xl"
        animate={{ y: [0, -14, 0], rotate: [0, -6, 0] }}
        transition={{
          duration: 5.5,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 0.8,
        }}
      >
        🥪
      </motion.div>

      {/* Main content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-[#E07A5F]/20 mb-8">
            <Sparkles className="w-4 h-4 text-[#E07A5F]" />
            <span
              className="text-sm font-medium text-[#2D3436]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              AI-Powered Recommendations
            </span>
          </div>
        </motion.div>

        <motion.h1
          className="text-5xl md:text-7xl lg:text-8xl font-bold text-[#2D3436] mb-6 leading-[0.95]"
          style={{ fontFamily: 'Fraunces, serif' }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        >
          Your Canteen,
          <br />
          <span className="text-[#E07A5F]">Reimagined</span>
        </motion.h1>

        <motion.p
          className="text-lg md:text-xl text-[#2D3436]/70 max-w-2xl mx-auto mb-10"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        >
          Discover delicious meals, get personalized suggestions, and skip the
          queue. Your smart companion for better lunch breaks.
        </motion.p>

        {/* Search bar */}
        <motion.div
          className="relative max-w-xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#E07A5F] to-[#81B29A] rounded-2xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300" />
            <div className="relative flex items-center bg-white rounded-2xl shadow-xl shadow-[#2D3436]/5 border border-[#2D3436]/5">
              <Search className="w-5 h-5 text-[#2D3436]/40 ml-5" />
              <input
                type="text"
                placeholder="What are you craving today?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 px-4 py-5 bg-transparent text-[#2D3436] placeholder:text-[#2D3436]/40 focus:outline-none text-lg"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              />
              <button
                className="mr-2 px-6 py-3 bg-gradient-to-r from-[#E07A5F] to-[#D4694F] text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-[#E07A5F]/25 transition-all duration-300 hover:-translate-y-0.5"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Search
              </button>
            </div>
          </div>
        </motion.div>

        {/* Quick stats */}
        <motion.div
          className="flex flex-wrap justify-center gap-8 mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          {[
            { value: '50+', label: 'Daily Meals' },
            { value: '< 5min', label: 'Avg. Wait Time' },
            { value: '4.9★', label: 'User Rating' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
            >
              <div
                className="text-2xl md:text-3xl font-bold text-[#2D3436]"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                {stat.value}
              </div>
              <div
                className="text-sm text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full"
        >
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  )
}
