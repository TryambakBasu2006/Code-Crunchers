import { useState } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  X,
  Flame,
  Leaf,
  Plus,
  Minus,
  Check,
  ChefHat,
  Utensils,
  Clock,
  ShoppingBag,
  Info,
} from 'lucide-react'

export interface MealCustomization {
  spiceLevel: number
  portionSize: 'small' | 'regular' | 'large' | 'family'
  addOns: string[]
  dietaryPreferences: string[]
  specialInstructions: string
  quantity: number
}

export interface AddOn {
  id: string
  name: string
  price: number
  calories?: number
  isPopular?: boolean
  icon?: string
}

export interface MealCustomizationModalProps {
  isOpen: boolean
  onClose: () => void
  meal: {
    id: string
    name: string
    description: string
    price: number
    calories?: number
    prepTime?: string
    imageUrl: string
  }
  onAddToCart: (
    mealId: string,
    customization: MealCustomization,
    totalPrice: number,
  ) => void
}

const spiceLevels = [
  {
    level: 0,
    label: 'No Spice',
    emoji: '🥛',
    color: '#81B29A',
    description: 'Mild & creamy',
  },
  {
    level: 1,
    label: 'Mild',
    emoji: '🌶️',
    color: '#F2CC8F',
    description: 'Subtle warmth',
  },
  {
    level: 2,
    label: 'Medium',
    emoji: '🌶️🌶️',
    color: '#E07A5F',
    description: 'Balanced heat',
  },
  {
    level: 3,
    label: 'Hot',
    emoji: '🔥',
    color: '#C4563D',
    description: 'Fiery kick',
  },
  {
    level: 4,
    label: 'Extra Hot',
    emoji: '🔥🔥',
    color: '#A03E2D',
    description: 'Intense heat',
  },
]

const portionSizes = [
  {
    id: 'small',
    label: 'Small',
    multiplier: 0.7,
    calories: 0.7,
    description: 'Light appetite',
    icon: '🥄',
  },
  {
    id: 'regular',
    label: 'Regular',
    multiplier: 1,
    calories: 1,
    description: 'Standard serving',
    icon: '🍽️',
  },
  {
    id: 'large',
    label: 'Large',
    multiplier: 1.4,
    calories: 1.35,
    description: 'Hungry mode',
    icon: '🍲',
  },
  {
    id: 'family',
    label: 'Family',
    multiplier: 2.5,
    calories: 2.5,
    description: 'Serves 3-4',
    icon: '👨‍👩‍👧‍👦',
  },
]

const defaultAddOns: AddOn[] = [
  {
    id: 'extra-cheese',
    name: 'Extra Cheese',
    price: 1.49,
    calories: 110,
    icon: '🧀',
    isPopular: true,
  },
  {
    id: 'grilled-chicken',
    name: 'Grilled Chicken',
    price: 2.99,
    calories: 165,
    icon: '🍗',
  },
  {
    id: 'avocado',
    name: 'Fresh Avocado',
    price: 1.99,
    calories: 80,
    icon: '🥑',
    isPopular: true,
  },
  { id: 'bacon', name: 'Crispy Bacon', price: 2.49, calories: 120, icon: '🥓' },
  { id: 'egg', name: 'Fried Egg', price: 1.29, calories: 90, icon: '🍳' },
  {
    id: 'mushrooms',
    name: 'Sautéed Mushrooms',
    price: 1.49,
    calories: 25,
    icon: '🍄',
  },
  { id: 'jalapenos', name: 'Jalapeños', price: 0.99, calories: 10, icon: '🌶️' },
  {
    id: 'extra-sauce',
    name: 'Extra Sauce',
    price: 0.79,
    calories: 45,
    icon: '🫗',
  },
]

const dietaryOptions = [
  { id: 'vegetarian', label: 'Vegetarian', icon: '🥬', color: '#81B29A' },
  { id: 'vegan', label: 'Vegan', icon: '🌱', color: '#5A9A7A' },
  { id: 'gluten-free', label: 'Gluten-Free', icon: '🌾', color: '#F2CC8F' },
  { id: 'dairy-free', label: 'Dairy-Free', icon: '🥛', color: '#E07A5F' },
  { id: 'nut-free', label: 'Nut-Free', icon: '🥜', color: '#C4563D' },
  { id: 'halal', label: 'Halal', icon: '☪️', color: '#3D5A80' },
]

export function MealCustomizationModal({
  isOpen,
  onClose,
  meal,
  onAddToCart,
}: MealCustomizationModalProps) {
  const [customization, setCustomization] = useState<MealCustomization>({
    spiceLevel: 1,
    portionSize: 'regular',
    addOns: [],
    dietaryPreferences: [],
    specialInstructions: '',
    quantity: 1,
  })

  const [activeSection, setActiveSection] = useState<string | null>(null)

  const selectedPortion = portionSizes.find(
    (p) => p.id === customization.portionSize,
  )!
  const addOnsTotal = customization.addOns.reduce((sum, addOnId) => {
    const addOn = defaultAddOns.find((a) => a.id === addOnId)
    return sum + (addOn?.price || 0)
  }, 0)

  const basePrice = meal.price * selectedPortion.multiplier
  const itemTotal = basePrice + addOnsTotal
  const grandTotal = itemTotal * customization.quantity

  const baseCalories = meal.calories || 0
  const addOnsCalories = customization.addOns.reduce((sum, addOnId) => {
    const addOn = defaultAddOns.find((a) => a.id === addOnId)
    return sum + (addOn?.calories || 0)
  }, 0)
  const totalCalories = Math.round(
    (baseCalories * selectedPortion.calories + addOnsCalories) *
      customization.quantity,
  )

  const toggleAddOn = (addOnId: string) => {
    setCustomization((prev) => ({
      ...prev,
      addOns: prev.addOns.includes(addOnId)
        ? prev.addOns.filter((id) => id !== addOnId)
        : [...prev.addOns, addOnId],
    }))
  }

  const toggleDietary = (dietaryId: string) => {
    setCustomization((prev) => ({
      ...prev,
      dietaryPreferences: prev.dietaryPreferences.includes(dietaryId)
        ? prev.dietaryPreferences.filter((id) => id !== dietaryId)
        : [...prev.dietaryPreferences, dietaryId],
    }))
  }

  const handleAddToCart = () => {
    onAddToCart(meal.id, customization, grandTotal)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl md:max-h-[90vh] bg-white rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          >
            {/* Header with Image */}
            <div className="relative h-48 md:h-56 flex-shrink-0">
              <img
                src={meal.imageUrl}
                alt={meal.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Meal info overlay */}
              <div className="absolute bottom-4 left-4 right-4">
                <h2
                  className="text-2xl md:text-3xl font-bold text-white mb-1"
                  style={{ fontFamily: 'Fraunces, serif' }}
                >
                  {meal.name}
                </h2>
                <p
                  className="text-white/80 text-sm line-clamp-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {meal.description}
                </p>
                <div className="flex items-center gap-4 mt-2">
                  {meal.prepTime && (
                    <span className="flex items-center gap-1 text-white/70 text-xs">
                      <Clock className="w-3.5 h-3.5" />
                      {meal.prepTime}
                    </span>
                  )}
                  {meal.calories && (
                    <span className="flex items-center gap-1 text-white/70 text-xs">
                      <Flame className="w-3.5 h-3.5" />
                      {meal.calories} cal
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Spice Level */}
              <div>
                <div
                  className="flex items-center justify-between mb-3 cursor-pointer"
                  onClick={() =>
                    setActiveSection(activeSection === 'spice' ? null : 'spice')
                  }
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-[#E07A5F]/10 rounded-lg flex items-center justify-center">
                      <Flame className="w-4 h-4 text-[#E07A5F]" />
                    </div>
                    <div>
                      <h3
                        className="text-sm font-semibold text-[#2D3436]"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Spice Level
                      </h3>
                      <p className="text-xs text-[#2D3436]/50">
                        {spiceLevels[customization.spiceLevel].label}
                      </p>
                    </div>
                  </div>
                  <span className="text-xl">
                    {spiceLevels[customization.spiceLevel].emoji}
                  </span>
                </div>

                <div className="flex gap-2">
                  {spiceLevels.map((spice) => (
                    <motion.button
                      key={spice.level}
                      onClick={() =>
                        setCustomization((prev) => ({
                          ...prev,
                          spiceLevel: spice.level,
                        }))
                      }
                      className={`
                                                flex-1 py-3 px-2 rounded-xl text-center transition-all duration-200
                                                ${
                                                  customization.spiceLevel ===
                                                  spice.level
                                                    ? 'ring-2 ring-offset-2'
                                                    : 'bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                                }
                                            `}
                      style={{
                        backgroundColor:
                          customization.spiceLevel === spice.level
                            ? `${spice.color}15`
                            : undefined,
                        // @ts-expect-error - ringColor is a valid CSS custom property for Tailwind
                        '--tw-ring-color':
                          customization.spiceLevel === spice.level
                            ? spice.color
                            : undefined,
                      }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <span className="text-lg block mb-1">{spice.emoji}</span>
                      <span
                        className="text-[10px] font-medium text-[#2D3436]/70 block"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {spice.label}
                      </span>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Portion Size */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-[#81B29A]/10 rounded-lg flex items-center justify-center">
                    <Utensils className="w-4 h-4 text-[#81B29A]" />
                  </div>
                  <h3
                    className="text-sm font-semibold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Portion Size
                  </h3>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {portionSizes.map((portion) => (
                    <motion.button
                      key={portion.id}
                      onClick={() =>
                        setCustomization((prev) => ({
                          ...prev,
                          portionSize:
                            portion.id as MealCustomization['portionSize'],
                        }))
                      }
                      className={`
                                                relative p-3 rounded-xl text-left transition-all duration-200 border-2
                                                ${
                                                  customization.portionSize ===
                                                  portion.id
                                                    ? 'border-[#81B29A] bg-[#81B29A]/5'
                                                    : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                                }
                                            `}
                      whileTap={{ scale: 0.95 }}
                    >
                      {customization.portionSize === portion.id && (
                        <div className="absolute top-2 right-2 w-5 h-5 bg-[#81B29A] rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                      <span className="text-xl block mb-1">{portion.icon}</span>
                      <span
                        className="text-sm font-semibold text-[#2D3436] block"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {portion.label}
                      </span>
                      <span
                        className="text-[10px] text-[#2D3436]/50 block"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {portion.description}
                      </span>
                      {portion.multiplier !== 1 && (
                        <span
                          className={`text-xs font-medium mt-1 block ${portion.multiplier < 1 ? 'text-[#81B29A]' : 'text-[#E07A5F]'}`}
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                          {portion.multiplier < 1
                            ? '-30%'
                            : portion.multiplier === 1.4
                              ? '+40%'
                              : '+150%'}
                        </span>
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Add-ons */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-[#F2CC8F]/20 rounded-lg flex items-center justify-center">
                      <Plus className="w-4 h-4 text-[#D4A84B]" />
                    </div>
                    <h3
                      className="text-sm font-semibold text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Add-ons
                    </h3>
                  </div>
                  {customization.addOns.length > 0 && (
                    <span
                      className="text-xs font-medium text-[#81B29A] bg-[#81B29A]/10 px-2 py-1 rounded-full"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {customization.addOns.length} selected
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {defaultAddOns.map((addOn) => (
                    <motion.button
                      key={addOn.id}
                      onClick={() => toggleAddOn(addOn.id)}
                      className={`
                                                relative flex items-center gap-3 p-3 rounded-xl text-left transition-all duration-200 border-2
                                                ${
                                                  customization.addOns.includes(
                                                    addOn.id,
                                                  )
                                                    ? 'border-[#E07A5F] bg-[#E07A5F]/5'
                                                    : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                                }
                                            `}
                      whileTap={{ scale: 0.95 }}
                    >
                      {addOn.isPopular && (
                        <div className="absolute -top-1 -right-1 px-1.5 py-0.5 bg-[#F2CC8F] text-[#2D3436] text-[8px] font-bold rounded-md">
                          POPULAR
                        </div>
                      )}
                      <span className="text-xl">{addOn.icon}</span>
                      <div className="flex-1 min-w-0">
                        <span
                          className="text-sm font-medium text-[#2D3436] block truncate"
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                          {addOn.name}
                        </span>
                        <span
                          className="text-xs text-[#2D3436]/50"
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                          +${addOn.price.toFixed(2)}
                        </span>
                      </div>
                      <div
                        className={`
                                                w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors
                                                ${
                                                  customization.addOns.includes(
                                                    addOn.id,
                                                  )
                                                    ? 'bg-[#E07A5F] border-[#E07A5F]'
                                                    : 'border-[#2D3436]/20'
                                                }
                                            `}
                      >
                        {customization.addOns.includes(addOn.id) && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Dietary Preferences */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-[#81B29A]/10 rounded-lg flex items-center justify-center">
                    <Leaf className="w-4 h-4 text-[#81B29A]" />
                  </div>
                  <h3
                    className="text-sm font-semibold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Dietary Preferences
                  </h3>
                </div>

                <div className="flex flex-wrap gap-2">
                  {dietaryOptions.map((option) => (
                    <motion.button
                      key={option.id}
                      onClick={() => toggleDietary(option.id)}
                      className={`
                                                flex items-center gap-2 px-3 py-2 rounded-full text-sm transition-all duration-200
                                                ${
                                                  customization.dietaryPreferences.includes(
                                                    option.id,
                                                  )
                                                    ? 'text-white'
                                                    : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB]'
                                                }
                                            `}
                      style={{
                        backgroundColor:
                          customization.dietaryPreferences.includes(option.id)
                            ? option.color
                            : undefined,
                        fontFamily: 'DM Sans, sans-serif',
                      }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <span>{option.icon}</span>
                      <span className="font-medium">{option.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Special Instructions */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-[#3D5A80]/10 rounded-lg flex items-center justify-center">
                    <ChefHat className="w-4 h-4 text-[#3D5A80]" />
                  </div>
                  <h3
                    className="text-sm font-semibold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Special Instructions
                  </h3>
                </div>

                <textarea
                  value={customization.specialInstructions}
                  onChange={(e) =>
                    setCustomization((prev) => ({
                      ...prev,
                      specialInstructions: e.target.value,
                    }))
                  }
                  placeholder="Any allergies, preferences, or special requests? Let us know..."
                  className="w-full p-4 bg-[#F5F5F5] rounded-xl text-sm text-[#2D3436] placeholder:text-[#2D3436]/40 resize-none focus:outline-none focus:ring-2 focus:ring-[#81B29A]/50 transition-all"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                  rows={3}
                  maxLength={200}
                />
                <div className="flex justify-end mt-1">
                  <span
                    className="text-xs text-[#2D3436]/40"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {customization.specialInstructions.length}/200
                  </span>
                </div>
              </div>

              {/* Nutrition Summary */}
              {meal.calories && (
                <div className="p-4 bg-gradient-to-r from-[#F8F8F8] to-[#F5F5F5] rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="w-4 h-4 text-[#2D3436]/40" />
                    <span
                      className="text-xs font-medium text-[#2D3436]/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Estimated Nutrition
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span
                      className="text-sm text-[#2D3436]/70"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Total Calories
                    </span>
                    <span
                      className="text-lg font-bold text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {totalCalories} cal
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Footer - Fixed */}
            <div className="flex-shrink-0 p-4 bg-white border-t border-[#2D3436]/5">
              {/* Quantity Selector */}
              <div className="flex items-center justify-between mb-4">
                <span
                  className="text-sm font-medium text-[#2D3436]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Quantity
                </span>
                <div className="flex items-center gap-3">
                  <motion.button
                    onClick={() =>
                      setCustomization((prev) => ({
                        ...prev,
                        quantity: Math.max(1, prev.quantity - 1),
                      }))
                    }
                    className="w-10 h-10 bg-[#F5F5F5] rounded-xl flex items-center justify-center text-[#2D3436] hover:bg-[#EBEBEB] transition-colors disabled:opacity-50"
                    disabled={customization.quantity <= 1}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Minus className="w-4 h-4" />
                  </motion.button>
                  <span
                    className="w-8 text-center text-lg font-bold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {customization.quantity}
                  </span>
                  <motion.button
                    onClick={() =>
                      setCustomization((prev) => ({
                        ...prev,
                        quantity: Math.min(10, prev.quantity + 1),
                      }))
                    }
                    className="w-10 h-10 bg-[#F5F5F5] rounded-xl flex items-center justify-center text-[#2D3436] hover:bg-[#EBEBEB] transition-colors disabled:opacity-50"
                    disabled={customization.quantity >= 10}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Plus className="w-4 h-4" />
                  </motion.button>
                </div>
              </div>

              {/* Price Breakdown */}
              <div
                className="space-y-1 mb-4 text-sm"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <div className="flex justify-between text-[#2D3436]/60">
                  <span>Base ({selectedPortion.label})</span>
                  <span>${basePrice.toFixed(2)}</span>
                </div>
                {addOnsTotal > 0 && (
                  <div className="flex justify-between text-[#2D3436]/60">
                    <span>Add-ons ({customization.addOns.length})</span>
                    <span>+${addOnsTotal.toFixed(2)}</span>
                  </div>
                )}
                {customization.quantity > 1 && (
                  <div className="flex justify-between text-[#2D3436]/60">
                    <span>× {customization.quantity}</span>
                    <span></span>
                  </div>
                )}
              </div>

              {/* Add to Cart Button */}
              <motion.button
                onClick={handleAddToCart}
                className="w-full flex items-center justify-center gap-3 py-4 bg-gradient-to-r from-[#E07A5F] to-[#C4563D] text-white font-semibold rounded-xl shadow-lg shadow-[#E07A5F]/30 hover:shadow-xl hover:shadow-[#E07A5F]/40 transition-all"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <ShoppingBag className="w-5 h-5" />
                <span>Add to Order</span>
                <span className="px-3 py-1 bg-white/20 rounded-lg font-bold">
                  ${grandTotal.toFixed(2)}
                </span>
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
