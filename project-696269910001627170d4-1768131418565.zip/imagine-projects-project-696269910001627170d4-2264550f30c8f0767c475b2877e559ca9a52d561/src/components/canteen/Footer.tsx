import { motion } from 'motion/react'
import { Link } from '@tanstack/react-router'
import { Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-[#2D3436] text-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <motion.div
            className="md:col-span-1"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3
              className="text-2xl font-bold mb-4"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              Canteen<span className="text-[#E07A5F]">.</span>
            </h3>
            <p
              className="text-white/60 text-sm leading-relaxed"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Your AI-powered companion for smarter, faster, and more delicious
              lunch breaks.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h4
              className="text-sm font-semibold uppercase tracking-wider text-white/40 mb-4"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Menu
            </h4>
            <ul
              className="space-y-3"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {[
                "Today's Specials",
                'Full Menu',
                'Nutrition Info',
                'Allergens',
              ].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="text-white/60 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Support */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h4
              className="text-sm font-semibold uppercase tracking-wider text-white/40 mb-4"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Support
            </h4>
            <ul
              className="space-y-3"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <li>
                <a
                  href="#"
                  className="text-white/60 hover:text-white transition-colors duration-200 text-sm"
                >
                  Help Center
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/60 hover:text-white transition-colors duration-200 text-sm"
                >
                  Contact Us
                </a>
              </li>
              <li>
                <Link
                  to="/privacy"
                  className="text-white/60 hover:text-white transition-colors duration-200 text-sm"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/60 hover:text-white transition-colors duration-200 text-sm"
                >
                  Terms of Service
                </a>
              </li>
            </ul>
          </motion.div>

          {/* Hours */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h4
              className="text-sm font-semibold uppercase tracking-wider text-white/40 mb-4"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Hours
            </h4>
            <div
              className="space-y-2 text-sm"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <p className="text-white/60">
                <span className="text-white">Mon - Fri:</span> 7:00 AM - 7:00 PM
              </p>
              <p className="text-white/60">
                <span className="text-white">Saturday:</span> 8:00 AM - 4:00 PM
              </p>
              <p className="text-white/60">
                <span className="text-white">Sunday:</span> Closed
              </p>
            </div>
          </motion.div>
        </div>

        {/* Bottom bar */}
        <motion.div
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <p
            className="text-white/40 text-sm"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            © {new Date().getFullYear()} Canteen Companion. All rights reserved.
          </p>
          <p
            className="text-white/40 text-sm flex items-center gap-1"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Made with{' '}
            <Heart className="w-4 h-4 text-[#E07A5F] fill-[#E07A5F]" /> for
            better lunches
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
