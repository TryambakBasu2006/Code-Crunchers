import { motion } from 'motion/react'
import { Link } from '@tanstack/react-router'
import { MealCard } from './MealCard'
import { Sparkles } from 'lucide-react'

const featuredMeals = [
  {
    id: '1',
    name: 'Mediterranean Buddha Bowl',
    description:
      'Fresh quinoa, roasted chickpeas, cucumber, tomatoes, feta cheese, and tahini dressing',
    price: 12.99,
    calories: 520,
    prepTime: '5-8 min',
    imageUrl:
      'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&auto=format&fit=crop&q=80',
    category: 'bowls',
    isPopular: true,
  },
  {
    id: '2',
    name: 'Spicy Thai Noodle Soup',
    description:
      'Rice noodles in aromatic coconut broth with tofu, mushrooms, and fresh herbs',
    price: 10.99,
    calories: 380,
    prepTime: '8-10 min',
    imageUrl:
      'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop&q=80',
    category: 'soups',
    isPopular: false,
  },
  {
    id: '3',
    name: 'Classic Club Sandwich',
    description:
      'Triple-decker with turkey, bacon, lettuce, tomato, and herb mayo on toasted sourdough',
    price: 11.49,
    calories: 650,
    prepTime: '5-7 min',
    imageUrl:
      'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=80',
    category: 'sandwiches',
    isPopular: true,
  },
  {
    id: '4',
    name: 'Grilled Salmon Plate',
    description:
      'Atlantic salmon with lemon herb butter, seasonal vegetables, and wild rice',
    price: 15.99,
    calories: 580,
    prepTime: '10-12 min',
    imageUrl:
      'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&auto=format&fit=crop&q=80',
    category: 'mains',
    isPopular: false,
  },
  {
    id: '5',
    name: 'Veggie Burrito Bowl',
    description:
      'Black beans, cilantro lime rice, grilled peppers, corn salsa, guacamole, and sour cream',
    price: 11.99,
    calories: 490,
    prepTime: '5-8 min',
    imageUrl:
      'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=800&auto=format&fit=crop&q=80',
    category: 'bowls',
    isPopular: true,
  },
  {
    id: '6',
    name: 'Chicken Tikka Masala',
    description:
      'Tender chicken in creamy tomato curry sauce with basmati rice and naan bread',
    price: 13.49,
    calories: 720,
    prepTime: '8-10 min',
    imageUrl:
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop&q=80',
    category: 'mains',
    isPopular: false,
  },
]

export function FeaturedMeals() {
  return (
    <section className="bg-white py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#81B29A]/10 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-[#81B29A]" />
            <span
              className="text-sm font-medium text-[#81B29A]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Today's Selection
            </span>
          </div>
          <h2
            className="text-3xl md:text-5xl font-bold text-[#2D3436] mb-4"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Featured Meals
          </h2>
          <p
            className="text-lg text-[#2D3436]/60 max-w-2xl mx-auto"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Hand-picked favorites from our kitchen, made fresh daily with
            locally sourced ingredients.
          </p>
        </motion.div>

        {/* Meals grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {featuredMeals.map((meal, index) => (
            <motion.div
              key={meal.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              <MealCard {...meal} />
            </motion.div>
          ))}
        </div>

        {/* View all button */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Link
            to="/menu"
            className="inline-block px-8 py-4 bg-[#F5F5F5] text-[#2D3436] font-semibold rounded-xl hover:bg-[#EBEBEB] transition-colors duration-300"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            View Full Menu →
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
