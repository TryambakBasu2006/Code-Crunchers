import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { useServerFn } from '@tanstack/react-start'
import { Link } from '@tanstack/react-router'
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  ArrowLeft,
  Loader2,
  UtensilsCrossed,
  Flame,
  Leaf,
  AlertCircle,
} from 'lucide-react'
import {
  getMealsFn,
  getMealCategoriesFn,
  getDailySpecialsFn,
} from '@/server/functions'
import { MealCard } from './MealCard'
import { Navbar } from './Navbar'
import { Footer } from './Footer'
import type { Meals, DailySpecials } from '@/server/lib/appwrite.types'

// Category configuration with emojis
const CATEGORY_CONFIG: Record<string, { emoji: string; label: string }> = {
  all: { emoji: '✨', label: 'All' },
  bowls: { emoji: '🥗', label: 'Bowls' },
  mains: { emoji: '🍛', label: 'Mains' },
  sandwiches: { emoji: '🥪', label: 'Sandwiches' },
  soups: { emoji: '🍜', label: 'Soups' },
  snacks: { emoji: '🍟', label: 'Snacks' },
  drinks: { emoji: '🧃', label: 'Drinks' },
  desserts: { emoji: '🍰', label: 'Desserts' },
  salads: { emoji: '🥬', label: 'Salads' },
  breakfast: { emoji: '🍳', label: 'Breakfast' },
  sides: { emoji: '🍚', label: 'Sides' },
}

interface SpecialWithMeal extends DailySpecials {
  meal: Meals
  finalPrice: number
}

export function MenuPage() {
  const [meals, setMeals] = useState<Meals[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [specials, setSpecials] = useState<SpecialWithMeal[]>([])
  const [activeCategory, setActiveCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)

  const getMeals = useServerFn(getMealsFn)
  const getCategories = useServerFn(getMealCategoriesFn)
  const getSpecials = useServerFn(getDailySpecialsFn)

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      setError(null)
      try {
        const [mealsResult, categoriesResult, specialsResult] =
          await Promise.all([
            getMeals({ data: { limit: 100 } }),
            getCategories(),
            getSpecials(),
          ])

        setMeals(mealsResult.meals)
        setCategories(['all', ...(categoriesResult.categories as string[])])
        setSpecials(specialsResult.specials as SpecialWithMeal[])
      } catch (err) {
        console.error('Failed to fetch menu data:', err)
        setError('Failed to load menu. Please try again.')
      } finally {
        setIsLoading(false)
      }
    }

    void fetchData()
  }, [])

  // Fetch meals when category changes
  useEffect(() => {
    const fetchMeals = async () => {
      if (activeCategory === 'all' && !searchQuery) return

      setIsLoading(true)
      try {
        const result = await getMeals({
          data: {
            category: activeCategory === 'all' ? undefined : activeCategory,
            search: searchQuery || undefined,
            limit: 100,
          },
        })
        setMeals(result.meals)
      } catch (err) {
        console.error('Failed to fetch meals:', err)
      } finally {
        setIsLoading(false)
      }
    }

    const debounceTimer = setTimeout(() => {
      void fetchMeals()
    }, 300)

    return () => clearTimeout(debounceTimer)
  }, [activeCategory, searchQuery])

  // Filter meals client-side for immediate feedback
  const filteredMeals = meals.filter((meal) => {
    const matchesCategory =
      activeCategory === 'all' || meal.category === activeCategory
    const matchesSearch =
      !searchQuery ||
      meal.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      meal.description?.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const handleAddToCart = (id: string) => {
    console.log('Add to cart:', id)
    // TODO: Implement cart functionality
  }

  const handleToggleFavorite = (id: string) => {
    console.log('Toggle favorite:', id)
    // TODO: Implement favorites functionality
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#FAFAFA] to-white">
      <Navbar />

      <div className="pt-20">
        {/* Hero Section */}
        <section className="relative py-12 md:py-16 overflow-hidden">
          {/* Background decoration */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#81B29A]/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#E07A5F]/10 rounded-full blur-3xl" />
          </div>

          <div className="max-w-7xl mx-auto px-6 relative">
            {/* Back link */}
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-[#2D3436]/60 hover:text-[#2D3436] transition-colors mb-6"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#81B29A]/10 rounded-full mb-4">
                <UtensilsCrossed className="w-4 h-4 text-[#81B29A]" />
                <span
                  className="text-sm font-medium text-[#81B29A]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Fresh & Delicious
                </span>
              </div>

              <h1
                className="text-4xl md:text-6xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                Our Menu
              </h1>
              <p
                className="text-lg text-[#2D3436]/60 max-w-2xl"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Explore our full selection of freshly prepared meals, crafted
                with locally sourced ingredients and made with love.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Daily Specials */}
        {specials.length > 0 && (
          <section className="py-8 bg-gradient-to-r from-[#E07A5F]/5 via-[#E07A5F]/10 to-[#E07A5F]/5">
            <div className="max-w-7xl mx-auto px-6">
              <motion.div
                className="flex items-center gap-3 mb-6"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <div className="p-2 bg-[#E07A5F] rounded-xl">
                  <Flame className="w-5 h-5 text-white" />
                </div>
                <h2
                  className="text-2xl font-bold text-[#2D3436]"
                  style={{ fontFamily: 'Fraunces, serif' }}
                >
                  Today's Specials
                </h2>
              </motion.div>

              <div className="flex gap-4 overflow-x-auto pb-4 -mx-6 px-6">
                {specials.map((special, index) => (
                  <motion.div
                    key={special.$id}
                    className="flex-shrink-0 w-72 bg-white rounded-2xl p-4 shadow-lg border border-[#E07A5F]/20"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className="relative h-32 rounded-xl overflow-hidden mb-3">
                      <img
                        src={
                          special.meal.imageId ||
                          'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400'
                        }
                        alt={special.meal.name}
                        className="w-full h-full object-cover"
                      />
                      {special.discountPercent && (
                        <div className="absolute top-2 right-2 px-2 py-1 bg-[#E07A5F] text-white text-xs font-bold rounded-full">
                          -{special.discountPercent}%
                        </div>
                      )}
                    </div>
                    <h3
                      className="font-bold text-[#2D3436] mb-1"
                      style={{ fontFamily: 'Fraunces, serif' }}
                    >
                      {special.meal.name}
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-[#E07A5F]">
                        ${special.finalPrice.toFixed(2)}
                      </span>
                      <span className="text-sm text-[#2D3436]/40 line-through">
                        ${special.meal.price.toFixed(2)}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Search and Filters */}
        <section className="py-8 sticky top-16 z-30 bg-white/80 backdrop-blur-lg border-b border-[#2D3436]/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search bar */}
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#2D3436]/40" />
                <input
                  type="text"
                  placeholder="Search meals..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-[#F5F5F5] rounded-xl border-2 border-transparent focus:border-[#81B29A] focus:bg-white outline-none transition-all duration-300"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>

              {/* Filter toggle (mobile) */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="md:hidden flex items-center justify-center gap-2 px-4 py-3 bg-[#F5F5F5] rounded-xl hover:bg-[#EBEBEB] transition-colors"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <SlidersHorizontal className="w-5 h-5" />
                Filters
              </button>
            </div>

            {/* Category pills */}
            <AnimatePresence>
              <motion.div
                className={`flex gap-2 overflow-x-auto py-4 ${showFilters || 'md:flex'} ${!showFilters && 'hidden md:flex'}`}
                style={{ scrollbarWidth: 'none' }}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                {categories.map((category, index) => {
                  const config = CATEGORY_CONFIG[category] || {
                    emoji: '🍽️',
                    label: category.charAt(0).toUpperCase() + category.slice(1),
                  }
                  return (
                    <motion.button
                      key={category}
                      onClick={() => setActiveCategory(category)}
                      className={`
                                                flex items-center gap-2 px-4 py-2.5 rounded-full whitespace-nowrap
                                                transition-all duration-300 font-medium text-sm
                                                ${
                                                  activeCategory === category
                                                    ? 'bg-[#2D3436] text-white shadow-lg shadow-[#2D3436]/20'
                                                    : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB] hover:text-[#2D3436]'
                                                }
                                            `}
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.03 }}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <span>{config.emoji}</span>
                      <span>{config.label}</span>
                    </motion.button>
                  )
                })}
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        {/* Meals Grid */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-6">
            {/* Results count */}
            <div className="flex items-center justify-between mb-8">
              <p
                className="text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {isLoading ? (
                  'Loading...'
                ) : (
                  <>
                    Showing{' '}
                    <span className="font-semibold text-[#2D3436]">
                      {filteredMeals.length}
                    </span>{' '}
                    {filteredMeals.length === 1 ? 'meal' : 'meals'}
                    {activeCategory !== 'all' && (
                      <>
                        {' '}
                        in{' '}
                        <span className="font-semibold text-[#81B29A]">
                          {CATEGORY_CONFIG[activeCategory]?.label ||
                            activeCategory}
                        </span>
                      </>
                    )}
                  </>
                )}
              </p>

              {/* Dietary filter badges */}
              <div className="hidden md:flex items-center gap-2">
                <button className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-700 rounded-full text-xs font-medium hover:bg-green-100 transition-colors">
                  <Leaf className="w-3.5 h-3.5" />
                  Vegetarian
                </button>
              </div>
            </div>

            {/* Loading state */}
            {isLoading && (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="w-10 h-10 text-[#81B29A] animate-spin mb-4" />
                <p
                  className="text-[#2D3436]/60"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Loading delicious meals...
                </p>
              </div>
            )}

            {/* Error state */}
            {error && (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="p-4 bg-red-50 rounded-full mb-4">
                  <AlertCircle className="w-8 h-8 text-red-500" />
                </div>
                <p
                  className="text-[#2D3436] font-medium mb-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {error}
                </p>
                <button
                  onClick={() => window.location.reload()}
                  className="text-[#81B29A] hover:underline"
                >
                  Try again
                </button>
              </div>
            )}

            {/* Empty state */}
            {!isLoading && !error && filteredMeals.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="p-4 bg-[#F5F5F5] rounded-full mb-4">
                  <UtensilsCrossed className="w-8 h-8 text-[#2D3436]/40" />
                </div>
                <p
                  className="text-[#2D3436] font-medium mb-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  No meals found
                </p>
                <p
                  className="text-[#2D3436]/60 text-sm"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Try adjusting your search or filters
                </p>
              </div>
            )}

            {/* Meals grid */}
            {!isLoading && !error && filteredMeals.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {filteredMeals.map((meal, index) => (
                  <motion.div
                    key={meal.$id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.4,
                      delay: index * 0.05,
                      ease: [0.22, 1, 0.36, 1],
                    }}
                  >
                    <MealCard
                      id={meal.$id}
                      name={meal.name}
                      description={meal.description || ''}
                      price={meal.price}
                      calories={meal.calories || undefined}
                      prepTime="5-10 min"
                      imageUrl={
                        meal.imageId ||
                        'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80'
                      }
                      category={meal.category || 'mains'}
                      isPopular={false}
                      onAddToCart={handleAddToCart}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Quick info banner */}
        <section className="py-8 bg-[#2D3436]">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Sparkles className="w-6 h-6 text-[#81B29A]" />
                <p
                  className="text-white/90"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  All meals are prepared fresh daily with locally sourced
                  ingredients
                </p>
              </div>
              <Link
                to="/"
                className="px-6 py-2.5 bg-white text-[#2D3436] font-semibold rounded-xl hover:bg-[#F5F5F5] transition-colors"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Learn More
              </Link>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </main>
  )
}
