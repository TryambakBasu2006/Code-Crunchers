import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
    Sparkles,
    Brain,
    Clock,
    Users,
    Heart,
    TrendingUp,
    ChevronRight,
    Zap,
    Gift,
    Timer,
    Percent,
    X,
    Plus,
    Star,
    Flame,
    Coffee,
    Utensils,
} from 'lucide-react'
import {
    getHybridRecommendationsFn,
    getContextualOffersFn,
} from '@/server/functions'
import type { Meals, AddOns } from '@/server/lib/appwrite.types'

interface Recommendation {
    meal: Meals
    reason: string
    reasonType: string
    score: number
    confidence: number
    strategy: string
}

interface ContextualOffer {
    type: 'pairing' | 'addon' | 'time_deal' | 'upsell' | 'bundle'
    title: string
    description: string
    item?: Meals | AddOns
    discount?: { type: string; value: number }
    reason: string
    priority: number
    expiresAt?: string
}

interface AIRecommendationsProps {
    cartMealIds?: string[]
    currentMealId?: string
    cartTotal?: number
    onAddToCart?: (meal: Meals) => void
    onAddAddOn?: (addOn: AddOns) => void
    compact?: boolean
}

export function AIRecommendations({
    cartMealIds = [],
    currentMealId,
    cartTotal = 0,
    onAddToCart,
    onAddAddOn,
    compact = false,
}: AIRecommendationsProps) {
    const [recommendations, setRecommendations] = useState<Recommendation[]>([])
    const [offers, setOffers] = useState<ContextualOffer[]>([])
    const [isLoading, setIsLoading] = useState(true)
    const [activeTab, setActiveTab] = useState<'for-you' | 'offers'>('for-you')
    const [dismissedOffers, setDismissedOffers] = useState<Set<string>>(new Set())

    useEffect(() => {
        const fetchRecommendations = async () => {
            setIsLoading(true)
            try {
                const [recsResult, offersResult] = await Promise.all([
                    getHybridRecommendationsFn({
                        data: {
                            limit: compact ? 4 : 8,
                            strategy: 'hybrid',
                            cartMealIds,
                            contextMealId: currentMealId,
                        },
                    }),
                    getContextualOffersFn({
                        data: {
                            currentMealId,
                            cartMealIds,
                            cartTotal,
                        },
                    }),
                ])

                setRecommendations(recsResult.recommendations)
                setOffers(offersResult.offers)
            } catch (error) {
                console.error('Failed to fetch recommendations:', error)
            } finally {
                setIsLoading(false)
            }
        }

        void fetchRecommendations()
    }, [cartMealIds, currentMealId, cartTotal, compact])

    const getStrategyIcon = (strategy: string) => {
        switch (strategy) {
            case 'collaborative':
                return <Users className="w-3.5 h-3.5" />
            case 'content_based':
                return <Heart className="w-3.5 h-3.5" />
            case 'hybrid':
                return <Brain className="w-3.5 h-3.5" />
            case 'time_contextual':
                return <Clock className="w-3.5 h-3.5" />
            case 'trending':
                return <TrendingUp className="w-3.5 h-3.5" />
            default:
                return <Sparkles className="w-3.5 h-3.5" />
        }
    }

    const getOfferIcon = (type: string) => {
        switch (type) {
            case 'pairing':
                return <Utensils className="w-4 h-4" />
            case 'addon':
                return <Plus className="w-4 h-4" />
            case 'time_deal':
                return <Timer className="w-4 h-4" />
            case 'upsell':
                return <TrendingUp className="w-4 h-4" />
            case 'bundle':
                return <Gift className="w-4 h-4" />
            default:
                return <Zap className="w-4 h-4" />
        }
    }

    const getTimeOfDayGreeting = () => {
        const hour = new Date().getHours()
        if (hour >= 6 && hour < 11) return { text: 'Good morning!', icon: <Coffee className="w-5 h-5" /> }
        if (hour >= 11 && hour < 14) return { text: 'Lunch time!', icon: <Utensils className="w-5 h-5" /> }
        if (hour >= 14 && hour < 17) return { text: 'Afternoon pick-me-up', icon: <Zap className="w-5 h-5" /> }
        if (hour >= 17 && hour < 21) return { text: 'Dinner time!', icon: <Flame className="w-5 h-5" /> }
        return { text: 'Late night cravings?', icon: <Star className="w-5 h-5" /> }
    }

    const dismissOffer = (index: number) => {
        setDismissedOffers((prev) => new Set([...prev, index.toString()]))
    }

    const visibleOffers = offers.filter((_, idx) => !dismissedOffers.has(idx.toString()))
    const greeting = getTimeOfDayGreeting()

    if (isLoading) {
        return (
            <div className="bg-gradient-to-br from-[#F8F8F8] to-white rounded-2xl p-6 border border-[#2D3436]/5">
                <div className="flex items-center gap-3 mb-6">
                    <motion.div
                        className="w-10 h-10 bg-gradient-to-br from-[#81B29A] to-[#3D5A80] rounded-xl flex items-center justify-center"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                    >
                        <Brain className="w-5 h-5 text-white" />
                    </motion.div>
                    <div>
                        <div className="h-4 w-32 bg-[#2D3436]/10 rounded animate-pulse" />
                        <div className="h-3 w-48 bg-[#2D3436]/5 rounded mt-2 animate-pulse" />
                    </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="bg-white rounded-xl p-4 animate-pulse">
                            <div className="w-full h-24 bg-[#2D3436]/5 rounded-lg mb-3" />
                            <div className="h-4 w-3/4 bg-[#2D3436]/10 rounded mb-2" />
                            <div className="h-3 w-1/2 bg-[#2D3436]/5 rounded" />
                        </div>
                    ))}
                </div>
            </div>
        )
    }

    if (recommendations.length === 0 && offers.length === 0) {
        return null
    }

    return (
        <div className="bg-gradient-to-br from-[#F8F8F8] to-white rounded-2xl border border-[#2D3436]/5 overflow-hidden">
            {/* Header */}
            <div className="p-6 pb-4">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-[#81B29A] to-[#3D5A80] rounded-xl flex items-center justify-center shadow-lg shadow-[#81B29A]/20">
                            <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <div className="flex items-center gap-2">
                                <h2
                                    className="text-lg font-bold text-[#2D3436]"
                                    style={{ fontFamily: 'Fraunces, serif' }}
                                >
                                    {greeting.text}
                                </h2>
                                {greeting.icon}
                            </div>
                            <p
                                className="text-sm text-[#2D3436]/60"
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                                AI-curated picks just for you
                            </p>
                        </div>
                    </div>

                    {/* Tab Switcher */}
                    {visibleOffers.length > 0 && (
                        <div className="flex bg-[#2D3436]/5 rounded-lg p-1">
                            <button
                                onClick={() => setActiveTab('for-you')}
                                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                                    activeTab === 'for-you'
                                        ? 'bg-white text-[#2D3436] shadow-sm'
                                        : 'text-[#2D3436]/60 hover:text-[#2D3436]'
                                }`}
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                                For You
                            </button>
                            <button
                                onClick={() => setActiveTab('offers')}
                                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-1.5 ${
                                    activeTab === 'offers'
                                        ? 'bg-white text-[#2D3436] shadow-sm'
                                        : 'text-[#2D3436]/60 hover:text-[#2D3436]'
                                }`}
                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                                <Gift className="w-3.5 h-3.5" />
                                Deals
                                {visibleOffers.length > 0 && (
                                    <span className="w-5 h-5 bg-[#E07A5F] text-white text-xs rounded-full flex items-center justify-center">
                                        {visibleOffers.length}
                                    </span>
                                )}
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {/* Content */}
            <AnimatePresence mode="wait">
                {activeTab === 'for-you' ? (
                    <motion.div
                        key="recommendations"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="px-6 pb-6"
                    >
                        <div className={`grid gap-4 ${compact ? 'grid-cols-2' : 'grid-cols-2 md:grid-cols-4'}`}>
                            {recommendations.slice(0, compact ? 4 : 8).map((rec, idx) => (
                                <motion.div
                                    key={rec.meal.$id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className="group bg-white rounded-xl overflow-hidden border border-[#2D3436]/5 hover:border-[#81B29A]/30 hover:shadow-lg hover:shadow-[#81B29A]/10 transition-all cursor-pointer"
                                    onClick={() => onAddToCart?.(rec.meal)}
                                >
                                    {/* Image */}
                                    <div className="relative h-28 bg-gradient-to-br from-[#F2CC8F]/20 to-[#81B29A]/20 overflow-hidden">
                                        {rec.meal.imageId ? (
                                            <img
                                                src={`/api/storage/preview/${rec.meal.imageId}`}
                                                alt={rec.meal.name}
                                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                            />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center">
                                                <Utensils className="w-8 h-8 text-[#2D3436]/20" />
                                            </div>
                                        )}

                                        {/* Confidence Badge */}
                                        <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 bg-white/90 backdrop-blur-sm rounded-full">
                                            {getStrategyIcon(rec.strategy)}
                                            <span
                                                className="text-[10px] font-medium text-[#2D3436]"
                                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                                            >
                                                {rec.confidence}% match
                                            </span>
                                        </div>

                                        {/* Quick Add */}
                                        <motion.button
                                            className="absolute bottom-2 right-2 w-8 h-8 bg-[#81B29A] text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                                            whileHover={{ scale: 1.1 }}
                                            whileTap={{ scale: 0.9 }}
                                            onClick={(e) => {
                                                e.stopPropagation()
                                                onAddToCart?.(rec.meal)
                                            }}
                                        >
                                            <Plus className="w-4 h-4" />
                                        </motion.button>
                                    </div>

                                    {/* Content */}
                                    <div className="p-3">
                                        <h3
                                            className="font-semibold text-[#2D3436] text-sm line-clamp-1 mb-1"
                                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                                        >
                                            {rec.meal.name}
                                        </h3>
                                        <p
                                            className="text-xs text-[#2D3436]/50 line-clamp-1 mb-2"
                                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                                        >
                                            {rec.reason}
                                        </p>
                                        <div className="flex items-center justify-between">
                                            <span
                                                className="font-bold text-[#81B29A]"
                                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                                            >
                                                ${rec.meal.price.toFixed(2)}
                                            </span>
                                            {rec.meal.calories && (
                                                <span
                                                    className="text-xs text-[#2D3436]/40"
                                                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                                                >
                                                    {rec.meal.calories} cal
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                ) : (
                    <motion.div
                        key="offers"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="px-6 pb-6 space-y-3"
                    >
                        {visibleOffers.map((offer, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="relative bg-white rounded-xl p-4 border border-[#2D3436]/5 hover:border-[#F2CC8F]/50 hover:shadow-md transition-all"
                            >
                                {/* Dismiss Button */}
                                <button
                                    onClick={() => dismissOffer(idx)}
                                    className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center text-[#2D3436]/30 hover:text-[#2D3436]/60 transition-colors"
                                >
                                    <X className="w-4 h-4" />
                                </button>

                                <div className="flex items-start gap-4">
                                    {/* Icon */}
                                    <div
                                        className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                                            offer.type === 'time_deal'
                                                ? 'bg-gradient-to-br from-[#E07A5F] to-[#D4A84B] text-white'
                                                : offer.type === 'pairing'
                                                  ? 'bg-gradient-to-br from-[#81B29A] to-[#3D5A80] text-white'
                                                  : 'bg-gradient-to-br from-[#F2CC8F] to-[#E07A5F] text-white'
                                        }`}
                                    >
                                        {getOfferIcon(offer.type)}
                                    </div>

                                    {/* Content */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h3
                                                className="font-semibold text-[#2D3436] text-sm"
                                                style={{ fontFamily: 'DM Sans, sans-serif' }}
                                            >
                                                {offer.title}
                                            </h3>
                                            {offer.discount && (
                                                <span className="px-2 py-0.5 bg-[#E07A5F]/10 text-[#E07A5F] text-xs font-bold rounded-full flex items-center gap-1">
                                                    <Percent className="w-3 h-3" />
                                                    {offer.discount.type === 'percentage'
                                                        ? `${offer.discount.value}% OFF`
                                                        : `$${offer.discount.value} OFF`}
                                                </span>
                                            )}
                                        </div>
                                        <p
                                            className="text-xs text-[#2D3436]/60 mb-2"
                                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                                        >
                                            {offer.description}
                                        </p>

                                        {/* Item Preview */}
                                        {offer.item && (
                                            <div className="flex items-center gap-2 p-2 bg-[#F8F8F8] rounded-lg">
                                                <div className="w-10 h-10 bg-[#2D3436]/5 rounded-lg flex items-center justify-center">
                                                    <Utensils className="w-4 h-4 text-[#2D3436]/30" />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <p
                                                        className="text-sm font-medium text-[#2D3436] truncate"
                                                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                                                    >
                                                        {offer.item.name}
                                                    </p>
                                                    <p
                                                        className="text-xs text-[#81B29A] font-semibold"
                                                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                                                    >
                                                        ${'price' in offer.item ? offer.item.price.toFixed(2) : '0.00'}
                                                    </p>
                                                </div>
                                                <motion.button
                                                    className="px-3 py-1.5 bg-[#81B29A] text-white text-xs font-medium rounded-lg flex items-center gap-1"
                                                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                                                    whileHover={{ scale: 1.02 }}
                                                    whileTap={{ scale: 0.98 }}
                                                    onClick={() => {
                                                        if ('isAvailable' in offer.item! && 'category' in offer.item!) {
                                                            onAddToCart?.(offer.item as Meals)
                                                        } else {
                                                            onAddAddOn?.(offer.item as AddOns)
                                                        }
                                                    }}
                                                >
                                                    <Plus className="w-3 h-3" />
                                                    Add
                                                </motion.button>
                                            </div>
                                        )}

                                        {/* Expiry */}
                                        {offer.expiresAt && (
                                            <div className="flex items-center gap-1 mt-2 text-xs text-[#E07A5F]">
                                                <Timer className="w-3 h-3" />
                                                <span style={{ fontFamily: 'DM Sans, sans-serif' }}>
                                                    Expires {new Date(offer.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </motion.div>
                        ))}

                        {visibleOffers.length === 0 && (
                            <div className="text-center py-8">
                                <Gift className="w-12 h-12 text-[#2D3436]/20 mx-auto mb-3" />
                                <p
                                    className="text-sm text-[#2D3436]/50"
                                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                                >
                                    No active offers right now
                                </p>
                            </div>
                        )}
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Footer */}
            {!compact && (
                <div className="px-6 py-4 bg-gradient-to-r from-[#81B29A]/5 to-[#3D5A80]/5 border-t border-[#2D3436]/5">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs text-[#2D3436]/50">
                            <Brain className="w-4 h-4" />
                            <span style={{ fontFamily: 'DM Sans, sans-serif' }}>
                                Powered by hybrid AI • Collaborative + Content-based filtering
                            </span>
                        </div>
                        <button
                            className="flex items-center gap-1 text-xs text-[#81B29A] font-medium hover:text-[#6a9a82] transition-colors"
                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                            View all recommendations
                            <ChevronRight className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            )}
        </div>
    )
}

// Compact version for cart sidebar
export function AIRecommendationsCompact({
    cartMealIds,
    cartTotal,
    onAddToCart,
}: {
    cartMealIds: string[]
    cartTotal: number
    onAddToCart?: (meal: Meals) => void
}) {
    return (
        <AIRecommendations
            cartMealIds={cartMealIds}
            cartTotal={cartTotal}
            onAddToCart={onAddToCart}
            compact
        />
    )
}
