import { motion } from 'motion/react'
import { useState } from 'react'

const categories = [
  { id: 'all', label: 'All', emoji: '✨' },
  { id: 'bowls', label: 'Bowls', emoji: '🥗' },
  { id: 'mains', label: 'Mains', emoji: '🍛' },
  { id: 'sandwiches', label: 'Sandwiches', emoji: '🥪' },
  { id: 'soups', label: 'Soups', emoji: '🍜' },
  { id: 'snacks', label: 'Snacks', emoji: '🍟' },
  { id: 'drinks', label: 'Drinks', emoji: '🧃' },
  { id: 'desserts', label: 'Desserts', emoji: '🍰' },
]

interface CategoryNavProps {
  onCategoryChange?: (category: string) => void
}

export function CategoryNav({ onCategoryChange }: CategoryNavProps) {
  const [activeCategory, setActiveCategory] = useState('all')

  const handleCategoryClick = (categoryId: string) => {
    setActiveCategory(categoryId)
    onCategoryChange?.(categoryId)
  }

  return (
    <section className="bg-white py-8 sticky top-0 z-40 border-b border-[#2D3436]/5">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          className="flex gap-3 overflow-x-auto pb-2"
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {categories.map((category, index) => (
            <motion.button
              key={category.id}
              onClick={() => handleCategoryClick(category.id)}
              className={`
                                relative flex items-center gap-2 px-5 py-3 rounded-full whitespace-nowrap
                                transition-all duration-300 font-medium text-sm
                                ${
                                  activeCategory === category.id
                                    ? 'bg-[#2D3436] text-white shadow-lg shadow-[#2D3436]/20'
                                    : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB] hover:text-[#2D3436]'
                                }
                            `}
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="text-lg">{category.emoji}</span>
              <span>{category.label}</span>
            </motion.button>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
