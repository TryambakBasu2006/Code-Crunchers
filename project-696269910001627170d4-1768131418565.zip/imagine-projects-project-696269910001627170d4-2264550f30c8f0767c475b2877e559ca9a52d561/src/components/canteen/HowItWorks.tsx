import { motion } from 'motion/react'
import { Search, ShoppingBag, Clock } from 'lucide-react'

const steps = [
  {
    icon: Search,
    title: 'Browse & Discover',
    description:
      'Explore our daily menu or let AI suggest meals based on your preferences and dietary needs.',
    color: '#E07A5F',
    bgColor: '#E07A5F/10',
  },
  {
    icon: ShoppingBag,
    title: 'Order Ahead',
    description:
      'Add items to your cart and place your order. Pay securely and skip the queue entirely.',
    color: '#81B29A',
    bgColor: '#81B29A/10',
  },
  {
    icon: Clock,
    title: 'Pick Up Fresh',
    description:
      'Get notified when your meal is ready. Walk in, grab your order, and enjoy!',
    color: '#F2CC8F',
    bgColor: '#F2CC8F/10',
  },
]

export function HowItWorks() {
  return (
    <section className="relative py-20 md:py-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-[#FDF8F3] to-white" />

      {/* Decorative elements */}
      <div className="absolute top-20 left-0 w-64 h-64 bg-[#E07A5F]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-0 w-80 h-80 bg-[#81B29A]/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2
            className="text-3xl md:text-5xl font-bold text-[#2D3436] mb-4"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            How It Works
          </h2>
          <p
            className="text-lg text-[#2D3436]/60 max-w-xl mx-auto"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Three simple steps to a better lunch experience
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              className="relative text-center"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.15,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              {/* Connector line (hidden on mobile) */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-[2px] bg-gradient-to-r from-[#2D3436]/10 to-transparent" />
              )}

              {/* Step number */}
              <motion.div
                className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-8 bg-white rounded-full border-2 border-[#2D3436]/10 flex items-center justify-center text-sm font-bold text-[#2D3436]/40 z-10"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileHover={{ scale: 1.1, borderColor: step.color }}
              >
                {index + 1}
              </motion.div>

              {/* Icon container */}
              <motion.div
                className="relative w-24 h-24 mx-auto mb-6 rounded-3xl flex items-center justify-center"
                style={{ backgroundColor: `${step.color}15` }}
                whileHover={{ scale: 1.05, rotate: 5 }}
                transition={{ duration: 0.3 }}
              >
                <step.icon
                  className="w-10 h-10"
                  style={{ color: step.color }}
                  strokeWidth={1.5}
                />
              </motion.div>

              {/* Content */}
              <h3
                className="text-xl font-bold text-[#2D3436] mb-3"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                {step.title}
              </h3>
              <p
                className="text-[#2D3436]/60 leading-relaxed max-w-xs mx-auto"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
