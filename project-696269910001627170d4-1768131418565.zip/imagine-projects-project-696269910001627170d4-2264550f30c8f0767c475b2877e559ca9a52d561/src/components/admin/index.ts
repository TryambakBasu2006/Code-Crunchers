export { AdminDashboard } from './AdminDashboard'
export { KitchenDashboard } from './KitchenDashboard'
export { MenuManagement } from './MenuManagement'
export { InventoryManagement } from './InventoryManagement'
export { ContextualOffersManager } from './ContextualOffersManager'
export {
    RealTimeInventoryDashboard,
    SoldOutBadge,
    LowStockIndicator,
} from './RealTimeInventoryDashboard'
export { AdminLoginPage } from './AdminLoginPage'
export { AdminSetupPage } from './AdminSetupPage'
