import { useState } from 'react'
import { motion } from 'motion/react'
import { useMutation } from '@tanstack/react-query'
import { useNavigate, useRouter, Link } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import {
  ChefHat,
  Lock,
  Mail,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowLeft,
  Shield,
  Loader2,
} from 'lucide-react'
import { signInFn, checkAdminStatusFn } from '@/server/functions'

const adminLoginSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(1, 'Password is required'),
})

type AdminLoginForm = z.infer<typeof adminLoginSchema>

export function AdminLoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [authError, setAuthError] = useState<string | null>(null)
  const navigate = useNavigate()
  const router = useRouter()

  const signIn = useServerFn(signInFn)
  const checkAdminStatus = useServerFn(checkAdminStatusFn)

  const form = useForm<AdminLoginForm>({
    resolver: zodResolver(adminLoginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  })

  const loginMutation = useMutation({
    mutationFn: async (data: AdminLoginForm) => {
      setAuthError(null)

      // First, sign in the user
      try {
        await signIn({
          data: {
            email: data.email,
            password: data.password,
          },
        })
      } catch (error: unknown) {
        // Check if it's a redirect (successful login)
        const err = error as {
          status?: number
          redirect?: boolean
          message?: string
        }
        if (err?.status === 302 || err?.redirect) {
          // Login successful, continue to check admin status
        } else {
          throw error
        }
      }

      // Invalidate router to refresh auth state
      await router.invalidate()

      // Check if user is admin/staff
      const adminStatus = await checkAdminStatus()

      if (!adminStatus.isAdmin && !adminStatus.isStaff) {
        throw new Error('ACCESS_DENIED')
      }

      return adminStatus
    },
    onSuccess: async (data) => {
      // Redirect based on role
      if (data.isAdmin) {
        await navigate({ to: '/menu-management' })
      } else if (data.isStaff) {
        await navigate({ to: '/kitchen' })
      }
    },
    onError: (error: Error) => {
      if (error.message === 'ACCESS_DENIED') {
        setAuthError('Access denied. This login is for staff members only.')
      } else {
        setAuthError(error.message || 'Invalid email or password')
      }
    },
  })

  const onSubmit = (data: AdminLoginForm) => {
    loginMutation.mutate(data)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#2D3436] via-[#1a1f20] to-[#2D3436] flex items-center justify-center p-6">
      {/* Background pattern */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
        </div>
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#E07A5F]/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#81B29A]/20 rounded-full blur-3xl" />
      </div>

      <motion.div
        className="relative w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Back to home */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-8"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        {/* Login card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#2D3436] to-[#3d4446] p-8 text-center">
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-2xl mb-4"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            >
              <ChefHat className="w-8 h-8 text-white" />
            </motion.div>
            <h1
              className="text-2xl font-bold text-white mb-2"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              Staff Portal
            </h1>
            <p
              className="text-white/60 text-sm"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Sign in to access the kitchen dashboard
            </p>
          </div>

          {/* Form */}
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="p-8 space-y-6"
          >
            {/* Error message */}
            {authError && (
              <motion.div
                className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                <p
                  className="text-sm text-red-700"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {authError}
                </p>
              </motion.div>
            )}

            {/* Email field */}
            <div className="space-y-2">
              <label
                htmlFor="email"
                className="block text-sm font-medium text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#2D3436]/40" />
                <input
                  {...form.register('email')}
                  type="email"
                  id="email"
                  placeholder="staff@canteen.com"
                  className={`
                                        w-full pl-12 pr-4 py-3.5 bg-[#F5F5F5] rounded-xl
                                        border-2 transition-all duration-300 outline-none
                                        ${
                                          form.formState.errors.email
                                            ? 'border-red-300 focus:border-red-500'
                                            : 'border-transparent focus:border-[#81B29A] focus:bg-white'
                                        }
                                    `}
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>
              {form.formState.errors.email && (
                <p
                  className="text-sm text-red-500"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {form.formState.errors.email.message}
                </p>
              )}
            </div>

            {/* Password field */}
            <div className="space-y-2">
              <label
                htmlFor="password"
                className="block text-sm font-medium text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#2D3436]/40" />
                <input
                  {...form.register('password')}
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  placeholder="Enter your password"
                  className={`
                                        w-full pl-12 pr-12 py-3.5 bg-[#F5F5F5] rounded-xl
                                        border-2 transition-all duration-300 outline-none
                                        ${
                                          form.formState.errors.password
                                            ? 'border-red-300 focus:border-red-500'
                                            : 'border-transparent focus:border-[#81B29A] focus:bg-white'
                                        }
                                    `}
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#2D3436]/40 hover:text-[#2D3436] transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              {form.formState.errors.password && (
                <p
                  className="text-sm text-red-500"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {form.formState.errors.password.message}
                </p>
              )}
            </div>

            {/* Submit button */}
            <motion.button
              type="submit"
              disabled={loginMutation.isPending}
              className={`
                                w-full flex items-center justify-center gap-2 py-4 rounded-xl
                                font-semibold text-white transition-all duration-300
                                ${
                                  loginMutation.isPending
                                    ? 'bg-[#2D3436]/70 cursor-not-allowed'
                                    : 'bg-[#2D3436] hover:bg-[#1a1f20] shadow-lg shadow-[#2D3436]/20'
                                }
                            `}
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              whileHover={{ scale: loginMutation.isPending ? 1 : 1.02 }}
              whileTap={{ scale: loginMutation.isPending ? 1 : 0.98 }}
            >
              {loginMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Signing in...
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5" />
                  Sign In to Staff Portal
                </>
              )}
            </motion.button>
          </form>

          {/* Footer */}
          <div className="px-8 pb-8">
            <div className="pt-6 border-t border-[#2D3436]/10 text-center">
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Not a staff member?{' '}
                <Link
                  to="/sign-in"
                  className="text-[#81B29A] hover:underline font-medium"
                >
                  Customer login
                </Link>
              </p>
            </div>
          </div>
        </div>

        {/* Security notice */}
        <motion.div
          className="mt-6 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <p
            className="text-white/40 text-xs"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            🔒 This is a secure staff-only portal. Unauthorized access attempts
            are logged.
          </p>
        </motion.div>
      </motion.div>
    </main>
  )
}
