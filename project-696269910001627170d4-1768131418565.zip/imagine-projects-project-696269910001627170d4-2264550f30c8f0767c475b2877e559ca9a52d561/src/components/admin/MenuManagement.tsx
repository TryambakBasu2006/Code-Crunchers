import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Plus,
  Search,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  DollarSign,
  Flame,
  AlertTriangle,
  X,
  Sparkles,
  Percent,
  Clock,
} from 'lucide-react'
import {
  getMealsFn,
  createMealFn,
  updateMealFn,
  deleteMealFn,
  toggleMealAvailabilityFn,
  getDailySpecialsFn,
  createDailySpecialFn,
  deleteDailySpecialFn,
} from '@/server/functions/meals'
import type { Meals, DailySpecials } from '@/server/lib/appwrite.types'

interface MealFormData {
  name: string
  description: string
  price: number
  category: string
  calories: number | null
  allergens: string[]
  isAvailable: boolean
}

const defaultFormData: MealFormData = {
  name: '',
  description: '',
  price: 0,
  category: '',
  calories: null,
  allergens: [],
  isAvailable: true,
}

const allergenOptions = [
  'Gluten',
  'Dairy',
  'Eggs',
  'Nuts',
  'Peanuts',
  'Soy',
  'Fish',
  'Shellfish',
  'Sesame',
]

const categoryOptions = [
  'Breakfast',
  'Lunch',
  'Dinner',
  'Bowls',
  'Sandwiches',
  'Soups',
  'Salads',
  'Mains',
  'Sides',
  'Desserts',
  'Drinks',
]

interface SpecialWithMeal extends DailySpecials {
  meal?: Meals
  finalPrice?: number
}

export function MenuManagement() {
  const [meals, setMeals] = useState<Meals[]>([])
  const [specials, setSpecials] = useState<SpecialWithMeal[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [showUnavailable, setShowUnavailable] = useState(true)

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isSpecialModalOpen, setIsSpecialModalOpen] = useState(false)
  const [editingMeal, setEditingMeal] = useState<Meals | null>(null)
  const [formData, setFormData] = useState<MealFormData>(defaultFormData)
  const [isSaving, setIsSaving] = useState(false)

  // Special form
  const [specialForm, setSpecialForm] = useState({
    mealId: '',
    discountPercent: 20,
    validFrom: '',
    validUntil: '',
  })

  const fetchData = async () => {
    try {
      const [mealsResult, specialsResult] = await Promise.all([
        getMealsFn({ data: { limit: 100 } }),
        getDailySpecialsFn(),
      ])
      setMeals(mealsResult.meals)
      // Filter out null values
      const validSpecials = (specialsResult.specials || []).filter(
        (s) => s !== null && s !== undefined,
      ) as SpecialWithMeal[]
      setSpecials(validSpecials)
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    void fetchData()
  }, [])

  const handleOpenModal = (meal?: Meals) => {
    if (meal) {
      setEditingMeal(meal)
      setFormData({
        name: meal.name,
        description: meal.description || '',
        price: meal.price,
        category: meal.category || '',
        calories: meal.calories,
        allergens: meal.allergens || [],
        isAvailable: meal.isAvailable,
      })
    } else {
      setEditingMeal(null)
      setFormData(defaultFormData)
    }
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setEditingMeal(null)
    setFormData(defaultFormData)
  }

  const handleSave = async () => {
    if (!formData.name || formData.price <= 0) return

    setIsSaving(true)
    try {
      if (editingMeal) {
        await updateMealFn({
          data: {
            mealId: editingMeal.$id,
            updates: {
              name: formData.name,
              description: formData.description || undefined,
              price: formData.price,
              category: formData.category || undefined,
              calories: formData.calories || undefined,
              allergens:
                formData.allergens.length > 0 ? formData.allergens : undefined,
              isAvailable: formData.isAvailable,
            },
          },
        })
      } else {
        await createMealFn({
          data: {
            name: formData.name,
            description: formData.description || undefined,
            price: formData.price,
            category: formData.category || undefined,
            calories: formData.calories || undefined,
            allergens:
              formData.allergens.length > 0 ? formData.allergens : undefined,
            isAvailable: formData.isAvailable,
          },
        })
      }
      handleCloseModal()
      void fetchData()
    } catch (error) {
      console.error('Failed to save meal:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async (mealId: string) => {
    if (!confirm('Are you sure you want to delete this meal?')) return

    try {
      await deleteMealFn({ data: { mealId } })
      void fetchData()
    } catch (error) {
      console.error('Failed to delete meal:', error)
    }
  }

  const handleToggleAvailability = async (mealId: string) => {
    try {
      await toggleMealAvailabilityFn({ data: { mealId } })
      void fetchData()
    } catch (error) {
      console.error('Failed to toggle availability:', error)
    }
  }

  const handleCreateSpecial = async () => {
    if (
      !specialForm.mealId ||
      !specialForm.validFrom ||
      !specialForm.validUntil
    )
      return

    try {
      await createDailySpecialFn({
        data: {
          mealId: specialForm.mealId,
          discountPercent: specialForm.discountPercent,
          validFrom: new Date(specialForm.validFrom).toISOString(),
          validUntil: new Date(specialForm.validUntil).toISOString(),
        },
      })
      setIsSpecialModalOpen(false)
      setSpecialForm({
        mealId: '',
        discountPercent: 20,
        validFrom: '',
        validUntil: '',
      })
      void fetchData()
    } catch (error) {
      console.error('Failed to create special:', error)
    }
  }

  const handleDeleteSpecial = async (specialId: string) => {
    try {
      await deleteDailySpecialFn({ data: { specialId } })
      void fetchData()
    } catch (error) {
      console.error('Failed to delete special:', error)
    }
  }

  const filteredMeals = meals.filter((meal) => {
    if (!showUnavailable && !meal.isAvailable) return false
    if (selectedCategory && meal.category !== selectedCategory) return false
    if (searchQuery) {
      return (
        meal.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        meal.description?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }
    return true
  })

  const categories = [...new Set(meals.map((m) => m.category).filter(Boolean))]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8F8F8] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Sparkles className="w-12 h-12 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#2D3436]/10 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1
                className="text-2xl font-bold text-[#2D3436]"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                Menu Management
              </h1>
              <p
                className="text-sm text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {meals.length} items •{' '}
                {meals.filter((m) => m.isAvailable).length} available
              </p>
            </div>

            <div className="flex items-center gap-3">
              <motion.button
                onClick={() => setIsSpecialModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[#F2CC8F] text-[#2D3436] font-medium rounded-xl hover:bg-[#E8C285] transition-colors"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <Sparkles className="w-4 h-4" />
                Add Special
              </motion.button>
              <motion.button
                onClick={() => handleOpenModal()}
                className="flex items-center gap-2 px-4 py-2 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <Plus className="w-4 h-4" />
                Add Meal
              </motion.button>
            </div>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex flex-wrap items-center gap-4">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
            <input
              type="text"
              placeholder="Search meals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white rounded-xl border border-[#2D3436]/10 text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />
          </div>

          {/* Category filter */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                !selectedCategory
                  ? 'bg-[#2D3436] text-white'
                  : 'bg-white text-[#2D3436]/70 hover:bg-[#F5F5F5]'
              }`}
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat as string)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#2D3436] text-white'
                    : 'bg-white text-[#2D3436]/70 hover:bg-[#F5F5F5]'
                }`}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Show unavailable toggle */}
          <button
            onClick={() => setShowUnavailable(!showUnavailable)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              showUnavailable
                ? 'bg-white text-[#2D3436]/70'
                : 'bg-[#E07A5F]/10 text-[#E07A5F]'
            }`}
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {showUnavailable ? (
              <Eye className="w-4 h-4" />
            ) : (
              <EyeOff className="w-4 h-4" />
            )}
            {showUnavailable ? 'Showing all' : 'Hiding unavailable'}
          </button>
        </div>
      </div>

      {/* Daily Specials */}
      {specials.length > 0 && (
        <div className="max-w-7xl mx-auto px-6 mb-6">
          <h2
            className="text-lg font-semibold text-[#2D3436] mb-3"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            🌟 Active Specials
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {specials.map((special) => (
              <div
                key={special.$id}
                className="bg-gradient-to-r from-[#F2CC8F]/20 to-[#F2CC8F]/5 rounded-xl p-4 border border-[#F2CC8F]/30"
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="font-semibold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {special.meal?.name || 'Unknown Meal'}
                  </span>
                  <button
                    onClick={() => handleDeleteSpecial(special.$id)}
                    className="p-1 text-[#EF4444] hover:bg-[#EF4444]/10 rounded"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-4 text-sm text-[#2D3436]/60">
                  <span className="flex items-center gap-1">
                    <Percent className="w-3.5 h-3.5" />
                    {special.discountPercent}% off
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Until {new Date(special.validUntil).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Meals Grid */}
      <div className="max-w-7xl mx-auto px-6 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMeals.map((meal) => (
            <motion.div
              key={meal.$id}
              layout
              className={`bg-white rounded-xl border overflow-hidden ${
                meal.isAvailable
                  ? 'border-[#2D3436]/5'
                  : 'border-[#EF4444]/20 opacity-60'
              }`}
            >
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3
                      className="font-semibold text-[#2D3436] line-clamp-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {meal.name}
                    </h3>
                    {meal.category && (
                      <span
                        className="inline-block px-2 py-0.5 bg-[#F5F5F5] rounded text-xs text-[#2D3436]/60 mt-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {meal.category}
                      </span>
                    )}
                  </div>
                  <span
                    className="text-lg font-bold text-[#E07A5F]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    ${meal.price.toFixed(2)}
                  </span>
                </div>

                {meal.description && (
                  <p
                    className="text-sm text-[#2D3436]/60 line-clamp-2 mb-3"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {meal.description}
                  </p>
                )}

                <div className="flex items-center gap-3 text-xs text-[#2D3436]/50 mb-3">
                  {meal.calories && (
                    <span className="flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5" />
                      {meal.calories} cal
                    </span>
                  )}
                  {meal.allergens && meal.allergens.length > 0 && (
                    <span className="flex items-center gap-1 text-[#E07A5F]">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {meal.allergens.length} allergens
                    </span>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-3 border-t border-[#2D3436]/5">
                  <button
                    onClick={() => handleToggleAvailability(meal.$id)}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                      meal.isAvailable
                        ? 'bg-[#81B29A]/10 text-[#81B29A] hover:bg-[#81B29A]/20'
                        : 'bg-[#EF4444]/10 text-[#EF4444] hover:bg-[#EF4444]/20'
                    }`}
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {meal.isAvailable ? (
                      <>
                        <Eye className="w-4 h-4" />
                        Available
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-4 h-4" />
                        Sold Out
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleOpenModal(meal)}
                    className="p-2 bg-[#F5F5F5] rounded-lg hover:bg-[#EBEBEB] transition-colors"
                  >
                    <Edit3 className="w-4 h-4 text-[#2D3436]/60" />
                  </button>
                  <button
                    onClick={() => handleDelete(meal.$id)}
                    className="p-2 bg-[#FEE2E2] rounded-lg hover:bg-[#FECACA] transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-[#EF4444]" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredMeals.length === 0 && (
          <div className="text-center py-12">
            <p
              className="text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              No meals found
            </p>
          </div>
        )}
      </div>

      {/* Add/Edit Meal Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseModal}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-lg bg-white rounded-2xl z-50 overflow-hidden"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2
                    className="text-xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'Fraunces, serif' }}
                  >
                    {editingMeal ? 'Edit Meal' : 'Add New Meal'}
                  </h2>
                  <button
                    onClick={handleCloseModal}
                    className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-[#2D3436]/60" />
                  </button>
                </div>

                <div className="space-y-4">
                  {/* Name */}
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      placeholder="Mediterranean Buddha Bowl"
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Description
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          description: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30 resize-none"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      rows={3}
                      placeholder="Fresh quinoa, roasted chickpeas..."
                    />
                  </div>

                  {/* Price & Calories */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Price *
                      </label>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={formData.price || ''}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              price: parseFloat(e.target.value) || 0,
                            })
                          }
                          className="w-full pl-10 pr-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                          placeholder="12.99"
                        />
                      </div>
                    </div>
                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Calories
                      </label>
                      <div className="relative">
                        <Flame className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                        <input
                          type="number"
                          min="0"
                          value={formData.calories || ''}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              calories: parseInt(e.target.value) || null,
                            })
                          }
                          className="w-full pl-10 pr-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                          placeholder="520"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Category */}
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Category
                    </label>
                    <select
                      value={formData.category}
                      onChange={(e) =>
                        setFormData({ ...formData, category: e.target.value })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      <option value="">Select category</option>
                      {categoryOptions.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Allergens */}
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-2"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Allergens
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {allergenOptions.map((allergen) => (
                        <button
                          key={allergen}
                          type="button"
                          onClick={() => {
                            const newAllergens = formData.allergens.includes(
                              allergen,
                            )
                              ? formData.allergens.filter((a) => a !== allergen)
                              : [...formData.allergens, allergen]
                            setFormData({
                              ...formData,
                              allergens: newAllergens,
                            })
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                            formData.allergens.includes(allergen)
                              ? 'bg-[#E07A5F] text-white'
                              : 'bg-[#F5F5F5] text-[#2D3436]/60 hover:bg-[#EBEBEB]'
                          }`}
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                          {allergen}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Availability */}
                  <div className="flex items-center justify-between p-3 bg-[#F5F5F5] rounded-xl">
                    <span
                      className="text-sm font-medium text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Available for ordering
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setFormData({
                          ...formData,
                          isAvailable: !formData.isAvailable,
                        })
                      }
                      className={`w-12 h-6 rounded-full transition-colors ${
                        formData.isAvailable
                          ? 'bg-[#81B29A]'
                          : 'bg-[#2D3436]/20'
                      }`}
                    >
                      <motion.div
                        className="w-5 h-5 bg-white rounded-full shadow"
                        animate={{ x: formData.isAvailable ? 26 : 2 }}
                      />
                    </button>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 mt-6">
                  <button
                    onClick={handleCloseModal}
                    className="flex-1 py-3 bg-[#F5F5F5] text-[#2D3436] font-medium rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving || !formData.name || formData.price <= 0}
                    className="flex-1 py-3 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {isSaving
                      ? 'Saving...'
                      : editingMeal
                        ? 'Update Meal'
                        : 'Add Meal'}
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Add Special Modal */}
      <AnimatePresence>
        {isSpecialModalOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSpecialModalOpen(false)}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md bg-white rounded-2xl z-50 overflow-hidden"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2
                    className="text-xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'Fraunces, serif' }}
                  >
                    🌟 Create Daily Special
                  </h2>
                  <button
                    onClick={() => setIsSpecialModalOpen(false)}
                    className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-[#2D3436]/60" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Select Meal
                    </label>
                    <select
                      value={specialForm.mealId}
                      onChange={(e) =>
                        setSpecialForm({
                          ...specialForm,
                          mealId: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F2CC8F]/50"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      <option value="">Choose a meal</option>
                      {meals
                        .filter((m) => m.isAvailable)
                        .map((meal) => (
                          <option key={meal.$id} value={meal.$id}>
                            {meal.name} - ${meal.price.toFixed(2)}
                          </option>
                        ))}
                    </select>
                  </div>

                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Discount: {specialForm.discountPercent}%
                    </label>
                    <input
                      type="range"
                      min="5"
                      max="50"
                      step="5"
                      value={specialForm.discountPercent}
                      onChange={(e) =>
                        setSpecialForm({
                          ...specialForm,
                          discountPercent: parseInt(e.target.value),
                        })
                      }
                      className="w-full"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Valid From
                      </label>
                      <input
                        type="datetime-local"
                        value={specialForm.validFrom}
                        onChange={(e) =>
                          setSpecialForm({
                            ...specialForm,
                            validFrom: e.target.value,
                          })
                        }
                        className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F2CC8F]/50"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      />
                    </div>
                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Valid Until
                      </label>
                      <input
                        type="datetime-local"
                        value={specialForm.validUntil}
                        onChange={(e) =>
                          setSpecialForm({
                            ...specialForm,
                            validUntil: e.target.value,
                          })
                        }
                        className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F2CC8F]/50"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-6">
                  <button
                    onClick={() => setIsSpecialModalOpen(false)}
                    className="flex-1 py-3 bg-[#F5F5F5] text-[#2D3436] font-medium rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateSpecial}
                    disabled={
                      !specialForm.mealId ||
                      !specialForm.validFrom ||
                      !specialForm.validUntil
                    }
                    className="flex-1 py-3 bg-[#F2CC8F] text-[#2D3436] font-medium rounded-xl hover:bg-[#E8C285] transition-colors disabled:opacity-50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Create Special
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
