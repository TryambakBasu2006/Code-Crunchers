import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Gift,
  Clock,
  Utensils,
  Percent,
  Zap,
  Trash2,
  ToggleLeft,
  ToggleRight,
  TrendingUp,
  Timer,
  Coffee,
  Moon,
  Sun,
  BarChart3,
  Target,
  Eye,
  CheckCircle,
  XCircle,
  Sparkles,
} from 'lucide-react'
import {
  getContextualOffersListFn,
  createQuickOfferFn,
  toggleContextualOfferFn,
  deleteContextualOfferFn,
  getOfferAnalyticsFn,
} from '@/server/functions'
import type {
  ContextualOffers,
  Meals,
  AddOns,
} from '@/server/lib/appwrite.types'

interface EnrichedOffer extends ContextualOffers {
  suggestedMeal?: Meals | null
  suggestedAddOn?: AddOns | null
  triggerMeal?: Meals | null
}

const quickOfferTemplates = [
  {
    id: 'afternoon_soup_deal',
    title: '🍲 Afternoon Soup Deal',
    description: '50% off soup after 3 PM',
    icon: <Coffee className="w-5 h-5" />,
    color: 'from-[#F2CC8F] to-[#E07A5F]',
  },
  {
    id: 'lunch_rush_combo',
    title: '⚡ Lunch Rush Combo',
    description: 'Free drink with main course',
    icon: <Zap className="w-5 h-5" />,
    color: 'from-[#81B29A] to-[#3D5A80]',
  },
  {
    id: 'happy_hour_drinks',
    title: '🍹 Happy Hour',
    description: '2-for-1 drinks 5-7 PM',
    icon: <Sun className="w-5 h-5" />,
    color: 'from-[#E07A5F] to-[#D4A84B]',
  },
  {
    id: 'weekend_brunch',
    title: '🥞 Weekend Brunch',
    description: '20% off breakfast items',
    icon: <Sun className="w-5 h-5" />,
    color: 'from-[#3D5A80] to-[#81B29A]',
  },
  {
    id: 'late_night_snack',
    title: '🌙 Late Night Munchies',
    description: 'Snack deals after 9 PM',
    icon: <Moon className="w-5 h-5" />,
    color: 'from-[#2D3436] to-[#3D5A80]',
  },
]

export function ContextualOffersManager() {
  const [offers, setOffers] = useState<EnrichedOffer[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [analytics, setAnalytics] = useState<{
    summary: {
      totalImpressions: number
      accepted: number
      dismissed: number
      converted: number
      acceptanceRate: number
      dismissalRate: number
      conversionRate: number
    }
    byOffer: Record<
      string,
      {
        impressions: number
        accepted: number
        dismissed: number
        converted: number
      }
    >
  } | null>(null)
  const [showAnalytics, setShowAnalytics] = useState(false)
  const [activeFilter, setActiveFilter] = useState<
    'all' | 'active' | 'inactive'
  >('all')

  useEffect(() => {
    void fetchOffers()
    void fetchAnalytics()
  }, [])

  const fetchOffers = async () => {
    setIsLoading(true)
    try {
      const result = await getContextualOffersListFn({ data: { limit: 50 } })
      setOffers(result.offers)
    } catch (error) {
      console.error('Failed to fetch offers:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchAnalytics = async () => {
    try {
      const result = await getOfferAnalyticsFn()
      setAnalytics(result)
    } catch (error) {
      console.error('Failed to fetch analytics:', error)
    }
  }

  const handleCreateQuickOffer = async (templateId: string) => {
    setIsCreating(true)
    try {
      await createQuickOfferFn({
        data: {
          template: templateId as
            | 'afternoon_soup_deal'
            | 'lunch_rush_combo'
            | 'happy_hour_drinks'
            | 'weekend_brunch'
            | 'late_night_snack',
        },
      })
      await fetchOffers()
    } catch (error) {
      console.error('Failed to create offer:', error)
    } finally {
      setIsCreating(false)
    }
  }

  const handleToggleOffer = async (offerId: string) => {
    try {
      await toggleContextualOfferFn({ data: { offerId } })
      await fetchOffers()
    } catch (error) {
      console.error('Failed to toggle offer:', error)
    }
  }

  const handleDeleteOffer = async (offerId: string) => {
    if (!confirm('Are you sure you want to delete this offer?')) return
    try {
      await deleteContextualOfferFn({ data: { offerId } })
      await fetchOffers()
    } catch (error) {
      console.error('Failed to delete offer:', error)
    }
  }

  const getOfferTypeIcon = (type: string) => {
    switch (type) {
      case 'pairing':
        return <Utensils className="w-4 h-4" />
      case 'time_deal':
        return <Timer className="w-4 h-4" />
      case 'upsell':
        return <TrendingUp className="w-4 h-4" />
      case 'bundle':
        return <Gift className="w-4 h-4" />
      case 'flash_sale':
        return <Zap className="w-4 h-4" />
      default:
        return <Gift className="w-4 h-4" />
    }
  }

  const filteredOffers = offers.filter((offer) => {
    if (activeFilter === 'active') return offer.isActive
    if (activeFilter === 'inactive') return !offer.isActive
    return true
  })

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Gift className="w-8 h-8 text-[#81B29A]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1
            className="text-2xl md:text-3xl font-bold text-[#2D3436]"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Contextual Offers
          </h1>
          <p
            className="text-[#2D3436]/60 mt-1"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            AI-powered deals and smart suggestions
          </p>
        </div>

        <button
          onClick={() => setShowAnalytics(!showAnalytics)}
          className="flex items-center gap-2 px-4 py-2 bg-[#3D5A80] text-white rounded-xl text-sm font-medium"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          <BarChart3 className="w-4 h-4" />
          {showAnalytics ? 'Hide' : 'Show'} Analytics
        </button>
      </div>

      {/* Analytics Panel */}
      <AnimatePresence>
        {showAnalytics && analytics && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-8 overflow-hidden"
          >
            <div className="bg-gradient-to-br from-[#3D5A80] to-[#2D3436] rounded-2xl p-6 text-white">
              <h2
                className="text-lg font-semibold mb-4 flex items-center gap-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <BarChart3 className="w-5 h-5" />
                Offer Performance
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Eye className="w-4 h-4 text-white/60" />
                    <span
                      className="text-sm text-white/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Impressions
                    </span>
                  </div>
                  <p
                    className="text-2xl font-bold"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {analytics.summary.totalImpressions.toLocaleString()}
                  </p>
                </div>

                <div className="bg-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-4 h-4 text-[#81B29A]" />
                    <span
                      className="text-sm text-white/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Acceptance Rate
                    </span>
                  </div>
                  <p
                    className="text-2xl font-bold text-[#81B29A]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {analytics.summary.acceptanceRate}%
                  </p>
                </div>

                <div className="bg-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-4 h-4 text-[#F2CC8F]" />
                    <span
                      className="text-sm text-white/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Conversion Rate
                    </span>
                  </div>
                  <p
                    className="text-2xl font-bold text-[#F2CC8F]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {analytics.summary.conversionRate}%
                  </p>
                </div>

                <div className="bg-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <XCircle className="w-4 h-4 text-[#E07A5F]" />
                    <span
                      className="text-sm text-white/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Dismissal Rate
                    </span>
                  </div>
                  <p
                    className="text-2xl font-bold text-[#E07A5F]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {analytics.summary.dismissalRate}%
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Create Templates */}
      <section className="mb-8">
        <h2
          className="text-lg font-semibold text-[#2D3436] mb-4 flex items-center gap-2"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          <Sparkles className="w-5 h-5 text-[#F2CC8F]" />
          Quick Create
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {quickOfferTemplates.map((template) => (
            <motion.button
              key={template.id}
              onClick={() => handleCreateQuickOffer(template.id)}
              disabled={isCreating}
              className={`
                                relative p-4 rounded-xl text-left overflow-hidden
                                bg-gradient-to-br ${template.color} text-white
                                hover:shadow-lg transition-shadow disabled:opacity-50
                            `}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="absolute top-2 right-2 opacity-20">
                {template.icon}
              </div>
              <h3
                className="font-semibold text-sm mb-1"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {template.title}
              </h3>
              <p
                className="text-xs text-white/80"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {template.description}
              </p>
            </motion.button>
          ))}
        </div>
      </section>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-6">
        {(['all', 'active', 'inactive'] as const).map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`
                            px-4 py-2 rounded-lg text-sm font-medium transition-all
                            ${
                              activeFilter === filter
                                ? 'bg-[#2D3436] text-white'
                                : 'bg-[#F5F5F5] text-[#2D3436]/60 hover:bg-[#EBEBEB]'
                            }
                        `}
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {filter.charAt(0).toUpperCase() + filter.slice(1)}
            <span className="ml-2 text-xs opacity-60">
              (
              {filter === 'all'
                ? offers.length
                : filter === 'active'
                  ? offers.filter((o) => o.isActive).length
                  : offers.filter((o) => !o.isActive).length}
              )
            </span>
          </button>
        ))}
      </div>

      {/* Offers List */}
      <div className="space-y-4">
        {filteredOffers.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-[#2D3436]/5">
            <Gift className="w-12 h-12 text-[#2D3436]/20 mx-auto mb-3" />
            <p
              className="text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              No offers found. Create one using the templates above!
            </p>
          </div>
        ) : (
          filteredOffers.map((offer) => (
            <motion.div
              key={offer.$id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`
                                bg-white rounded-xl p-5 border transition-all
                                ${offer.isActive ? 'border-[#81B29A]/30' : 'border-[#2D3436]/5 opacity-60'}
                            `}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  {/* Type Icon */}
                  <div
                    className={`
                                            w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0
                                            ${
                                              offer.isActive
                                                ? 'bg-gradient-to-br from-[#81B29A] to-[#3D5A80] text-white'
                                                : 'bg-[#F5F5F5] text-[#2D3436]/40'
                                            }
                                        `}
                  >
                    {getOfferTypeIcon(offer.offerType)}
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3
                        className="font-semibold text-[#2D3436]"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {offer.title}
                      </h3>
                      <span
                        className={`
                                                    px-2 py-0.5 rounded-full text-xs font-medium
                                                    ${
                                                      offer.isActive
                                                        ? 'bg-[#81B29A]/10 text-[#81B29A]'
                                                        : 'bg-[#2D3436]/5 text-[#2D3436]/40'
                                                    }
                                                `}
                      >
                        {offer.offerType.replace('_', ' ')}
                      </span>
                      {offer.discountValue && (
                        <span className="px-2 py-0.5 bg-[#E07A5F]/10 text-[#E07A5F] rounded-full text-xs font-bold flex items-center gap-1">
                          <Percent className="w-3 h-3" />
                          {offer.discountType === 'percentage'
                            ? `${offer.discountValue}% OFF`
                            : `$${offer.discountValue} OFF`}
                        </span>
                      )}
                    </div>

                    <p
                      className="text-sm text-[#2D3436]/60 mb-2"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {offer.description}
                    </p>

                    {/* Trigger Info */}
                    <div className="flex flex-wrap items-center gap-3 text-xs text-[#2D3436]/50">
                      {offer.triggerTimeStart && offer.triggerTimeEnd && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {offer.triggerTimeStart} - {offer.triggerTimeEnd}
                        </span>
                      )}
                      {offer.suggestedMeal && (
                        <span className="flex items-center gap-1">
                          <Utensils className="w-3 h-3" />
                          {offer.suggestedMeal.name}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Target className="w-3 h-3" />
                        Priority: {offer.priority}
                      </span>
                    </div>

                    {/* Validity */}
                    <div className="mt-2 text-xs text-[#2D3436]/40">
                      Valid:{' '}
                      {offer.validFrom
                        ? new Date(offer.validFrom).toLocaleDateString()
                        : 'N/A'}{' '}
                      -{' '}
                      {offer.validUntil
                        ? new Date(offer.validUntil).toLocaleDateString()
                        : 'N/A'}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <motion.button
                    onClick={() => handleToggleOffer(offer.$id)}
                    className={`
                                            p-2 rounded-lg transition-colors
                                            ${
                                              offer.isActive
                                                ? 'text-[#81B29A] hover:bg-[#81B29A]/10'
                                                : 'text-[#2D3436]/40 hover:bg-[#F5F5F5]'
                                            }
                                        `}
                    whileTap={{ scale: 0.9 }}
                  >
                    {offer.isActive ? (
                      <ToggleRight className="w-6 h-6" />
                    ) : (
                      <ToggleLeft className="w-6 h-6" />
                    )}
                  </motion.button>

                  <motion.button
                    onClick={() => handleDeleteOffer(offer.$id)}
                    className="p-2 rounded-lg text-[#E07A5F] hover:bg-[#E07A5F]/10 transition-colors"
                    whileTap={{ scale: 0.9 }}
                  >
                    <Trash2 className="w-5 h-5" />
                  </motion.button>
                </div>
              </div>

              {/* Analytics for this offer */}
              {analytics?.byOffer[offer.$id] && (
                <div className="mt-4 pt-4 border-t border-[#2D3436]/5 flex items-center gap-6 text-xs">
                  <span className="flex items-center gap-1 text-[#2D3436]/50">
                    <Eye className="w-3 h-3" />
                    {analytics.byOffer[offer.$id].impressions} views
                  </span>
                  <span className="flex items-center gap-1 text-[#81B29A]">
                    <CheckCircle className="w-3 h-3" />
                    {analytics.byOffer[offer.$id].accepted} accepted
                  </span>
                  <span className="flex items-center gap-1 text-[#F2CC8F]">
                    <Target className="w-3 h-3" />
                    {analytics.byOffer[offer.$id].converted} converted
                  </span>
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>
    </div>
  )
}
