import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Package,
  Plus,
  Search,
  AlertTriangle,
  Clock,
  RefreshCw,
  X,
  TrendingDown,
  TrendingUp,
  Calendar,
} from 'lucide-react'
import {
  getInventoryFn,
  getIngredientsFn,
  createIngredientFn,
  updateInventoryFn,
  restockInventoryFn,
} from '@/server/functions/inventory'
import type { Ingredients } from '@/server/lib/appwrite.types'

interface InventoryItem {
  $id: string
  ingredientId: string
  quantityInStock: number
  minimumThreshold: number | null
  lastRestockedAt: string | null
  expiresAt: string | null
  ingredient?: Ingredients
  isLowStock: boolean
}

export function InventoryManagement() {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [stats, setStats] = useState<{
    totalItems: number
    lowStockItems: number
    expiringItems: number
  } | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [showLowStockOnly, setShowLowStockOnly] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Modal states
  const [showAddModal, setShowAddModal] = useState(false)
  const [showRestockModal, setShowRestockModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null)

  // Form states
  const [newIngredient, setNewIngredient] = useState({
    name: '',
    category: '',
    unit: 'kg',
    costPerUnit: 0,
  })
  const [restockData, setRestockData] = useState({
    quantity: 0,
    expiresAt: '',
  })

  const fetchData = async () => {
    try {
      const [inventoryResult] = await Promise.all([
        getInventoryFn({ data: { lowStockOnly: showLowStockOnly } }),
        getIngredientsFn(),
      ])
      setInventory(inventoryResult.inventory as InventoryItem[])
      setStats(inventoryResult.stats)
    } catch (error) {
      console.error('Failed to fetch inventory:', error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    void fetchData()
  }, [showLowStockOnly])

  const handleRefresh = () => {
    setIsRefreshing(true)
    void fetchData()
  }

  const handleAddIngredient = async () => {
    if (!newIngredient.name || !newIngredient.unit) return

    try {
      await createIngredientFn({
        data: {
          name: newIngredient.name,
          category: newIngredient.category || undefined,
          unit: newIngredient.unit,
          costPerUnit: newIngredient.costPerUnit || undefined,
          isAvailable: true,
        },
      })
      setShowAddModal(false)
      setNewIngredient({ name: '', category: '', unit: 'kg', costPerUnit: 0 })
      void fetchData()
    } catch (error) {
      console.error('Failed to add ingredient:', error)
    }
  }

  const handleRestock = async () => {
    if (!selectedItem || restockData.quantity <= 0) return

    try {
      await restockInventoryFn({
        data: {
          ingredientId: selectedItem.ingredientId,
          quantity: restockData.quantity,
          expiresAt: restockData.expiresAt || undefined,
        },
      })
      setShowRestockModal(false)
      setSelectedItem(null)
      setRestockData({ quantity: 0, expiresAt: '' })
      void fetchData()
    } catch (error) {
      console.error('Failed to restock:', error)
    }
  }

  const handleQuickAdjust = async (item: InventoryItem, change: number) => {
    try {
      await updateInventoryFn({
        data: {
          ingredientId: item.ingredientId,
          quantityChange: change,
        },
      })
      void fetchData()
    } catch (error) {
      console.error('Failed to adjust inventory:', error)
    }
  }

  const filteredInventory = inventory.filter((item) => {
    if (!searchQuery) return true
    return item.ingredient?.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  })

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const isExpiringSoon = (expiresAt: string | null) => {
    if (!expiresAt) return false
    const weekFromNow = new Date()
    weekFromNow.setDate(weekFromNow.getDate() + 7)
    return new Date(expiresAt) <= weekFromNow
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8F8F8] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Package className="w-12 h-12 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#2D3436]/10 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1
                className="text-2xl font-bold text-[#2D3436]"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                Inventory Management
              </h1>
              <p
                className="text-sm text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Track ingredients and stock levels
              </p>
            </div>

            <div className="flex items-center gap-3">
              <motion.button
                onClick={handleRefresh}
                className="p-2 bg-[#F5F5F5] rounded-xl hover:bg-[#EBEBEB] transition-colors"
                whileTap={{ scale: 0.95 }}
              >
                <RefreshCw
                  className={`w-5 h-5 text-[#2D3436]/60 ${isRefreshing ? 'animate-spin' : ''}`}
                />
              </motion.button>
              <motion.button
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <Plus className="w-4 h-4" />
                Add Ingredient
              </motion.button>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      {stats && (
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-xl p-4 border border-[#2D3436]/5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-lg flex items-center justify-center">
                  <Package className="w-5 h-5 text-[#3D5A80]" />
                </div>
                <div>
                  <p
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Total Items
                  </p>
                  <p
                    className="text-xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {stats.totalItems}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#E07A5F]/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#E07A5F]/10 rounded-lg flex items-center justify-center">
                  <TrendingDown className="w-5 h-5 text-[#E07A5F]" />
                </div>
                <div>
                  <p
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Low Stock
                  </p>
                  <p
                    className="text-xl font-bold text-[#E07A5F]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {stats.lowStockItems}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#F2CC8F]/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F2CC8F]/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-[#D4A84B]" />
                </div>
                <div>
                  <p
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Expiring Soon
                  </p>
                  <p
                    className="text-xl font-bold text-[#D4A84B]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {stats.expiringItems}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
            <input
              type="text"
              placeholder="Search ingredients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white rounded-xl border border-[#2D3436]/10 text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />
          </div>

          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              showLowStockOnly
                ? 'bg-[#E07A5F] text-white'
                : 'bg-white text-[#2D3436]/70 border border-[#2D3436]/10 hover:bg-[#F5F5F5]'
            }`}
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            <AlertTriangle className="w-4 h-4" />
            Low Stock Only
          </button>
        </div>
      </div>

      {/* Inventory Grid */}
      <div className="max-w-7xl mx-auto px-6 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredInventory.map((item) => (
            <motion.div
              key={item.$id}
              layout
              className={`bg-white rounded-xl border overflow-hidden ${
                item.isLowStock
                  ? 'border-[#E07A5F]/30'
                  : isExpiringSoon(item.expiresAt)
                    ? 'border-[#F2CC8F]/50'
                    : 'border-[#2D3436]/5'
              }`}
            >
              <div className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3
                      className="font-semibold text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {item.ingredient?.name || 'Unknown'}
                    </h3>
                    {item.ingredient?.category && (
                      <span
                        className="inline-block px-2 py-0.5 bg-[#F5F5F5] rounded text-xs text-[#2D3436]/60 mt-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {item.ingredient.category}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {item.isLowStock && (
                      <span className="px-2 py-1 bg-[#E07A5F]/10 text-[#E07A5F] rounded-lg text-xs font-medium">
                        Low
                      </span>
                    )}
                    {isExpiringSoon(item.expiresAt) && (
                      <span className="px-2 py-1 bg-[#F2CC8F]/20 text-[#D4A84B] rounded-lg text-xs font-medium">
                        Expiring
                      </span>
                    )}
                  </div>
                </div>

                {/* Stock Level */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className="text-sm text-[#2D3436]/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Stock Level
                    </span>
                    <span
                      className="text-lg font-bold text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {item.quantityInStock} {item.ingredient?.unit}
                    </span>
                  </div>
                  {item.minimumThreshold && (
                    <div className="w-full h-2 bg-[#F5F5F5] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          item.isLowStock ? 'bg-[#E07A5F]' : 'bg-[#81B29A]'
                        }`}
                        style={{
                          width: `${Math.min(100, (item.quantityInStock / item.minimumThreshold) * 50)}%`,
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="flex items-center gap-4 text-xs text-[#2D3436]/50 mb-4">
                  {item.lastRestockedAt && (
                    <span className="flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" />
                      Restocked {formatDate(item.lastRestockedAt)}
                    </span>
                  )}
                  {item.expiresAt && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      Expires {formatDate(item.expiresAt)}
                    </span>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-3 border-t border-[#2D3436]/5">
                  <button
                    onClick={() => handleQuickAdjust(item, -1)}
                    className="flex-1 py-2 bg-[#F5F5F5] text-[#2D3436]/70 font-medium rounded-lg hover:bg-[#EBEBEB] transition-colors text-sm"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    -1
                  </button>
                  <button
                    onClick={() => handleQuickAdjust(item, 1)}
                    className="flex-1 py-2 bg-[#F5F5F5] text-[#2D3436]/70 font-medium rounded-lg hover:bg-[#EBEBEB] transition-colors text-sm"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    +1
                  </button>
                  <button
                    onClick={() => {
                      setSelectedItem(item)
                      setShowRestockModal(true)
                    }}
                    className="flex-1 py-2 bg-[#81B29A]/10 text-[#81B29A] font-medium rounded-lg hover:bg-[#81B29A]/20 transition-colors text-sm"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Restock
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredInventory.length === 0 && (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-[#2D3436]/20 mx-auto mb-4" />
            <p
              className="text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              No inventory items found
            </p>
          </div>
        )}
      </div>

      {/* Add Ingredient Modal */}
      <AnimatePresence>
        {showAddModal && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md bg-white rounded-2xl z-50 overflow-hidden"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2
                    className="text-xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'Fraunces, serif' }}
                  >
                    Add Ingredient
                  </h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-[#2D3436]/60" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Name *
                    </label>
                    <input
                      type="text"
                      value={newIngredient.name}
                      onChange={(e) =>
                        setNewIngredient({
                          ...newIngredient,
                          name: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      placeholder="e.g., Chicken Breast"
                    />
                  </div>

                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Category
                    </label>
                    <input
                      type="text"
                      value={newIngredient.category}
                      onChange={(e) =>
                        setNewIngredient({
                          ...newIngredient,
                          category: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      placeholder="e.g., Proteins"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Unit *
                      </label>
                      <select
                        value={newIngredient.unit}
                        onChange={(e) =>
                          setNewIngredient({
                            ...newIngredient,
                            unit: e.target.value,
                          })
                        }
                        className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        <option value="kg">Kilograms (kg)</option>
                        <option value="g">Grams (g)</option>
                        <option value="L">Liters (L)</option>
                        <option value="ml">Milliliters (ml)</option>
                        <option value="pcs">Pieces (pcs)</option>
                        <option value="dozen">Dozen</option>
                      </select>
                    </div>

                    <div>
                      <label
                        className="block text-sm font-medium text-[#2D3436] mb-1"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Cost per Unit
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={newIngredient.costPerUnit || ''}
                        onChange={(e) =>
                          setNewIngredient({
                            ...newIngredient,
                            costPerUnit: parseFloat(e.target.value) || 0,
                          })
                        }
                        className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 py-3 bg-[#F5F5F5] text-[#2D3436] font-medium rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddIngredient}
                    disabled={!newIngredient.name || !newIngredient.unit}
                    className="flex-1 py-3 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors disabled:opacity-50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Add Ingredient
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Restock Modal */}
      <AnimatePresence>
        {showRestockModal && selectedItem && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowRestockModal(false)
                setSelectedItem(null)
              }}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md bg-white rounded-2xl z-50 overflow-hidden"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2
                    className="text-xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'Fraunces, serif' }}
                  >
                    Restock {selectedItem.ingredient?.name}
                  </h2>
                  <button
                    onClick={() => {
                      setShowRestockModal(false)
                      setSelectedItem(null)
                    }}
                    className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-[#2D3436]/60" />
                  </button>
                </div>

                <div className="p-4 bg-[#F5F5F5] rounded-xl mb-4">
                  <p
                    className="text-sm text-[#2D3436]/60"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Current Stock
                  </p>
                  <p
                    className="text-2xl font-bold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {selectedItem.quantityInStock}{' '}
                    {selectedItem.ingredient?.unit}
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Quantity to Add *
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={restockData.quantity || ''}
                      onChange={(e) =>
                        setRestockData({
                          ...restockData,
                          quantity: parseInt(e.target.value) || 0,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#81B29A]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      placeholder="Enter quantity"
                    />
                  </div>

                  <div>
                    <label
                      className="block text-sm font-medium text-[#2D3436] mb-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Expiration Date (Optional)
                    </label>
                    <input
                      type="date"
                      value={restockData.expiresAt}
                      onChange={(e) =>
                        setRestockData({
                          ...restockData,
                          expiresAt: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#81B29A]/30"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-6">
                  <button
                    onClick={() => {
                      setShowRestockModal(false)
                      setSelectedItem(null)
                    }}
                    className="flex-1 py-3 bg-[#F5F5F5] text-[#2D3436] font-medium rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleRestock}
                    disabled={restockData.quantity <= 0}
                    className="flex-1 py-3 bg-[#81B29A] text-white font-medium rounded-xl hover:bg-[#6A9A83] transition-colors disabled:opacity-50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Restock
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
