import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  ChefHat,
  Clock,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Bell,
  Users,
  DollarSign,
  Package,
  ArrowRight,
  Search,
} from 'lucide-react'
import {
  getKitchenOrdersFn,
  updateOrderStatusFn,
  getOrderStatsFn,
  type OrderStatus,
} from '@/server/functions/orders'

interface OrderItem {
  $id: string
  mealId: string
  quantity: number
  portionSize: string | null
  spiceLevel: string | null
  addOns: string[] | null
  specialInstructions: string | null
}

interface KitchenOrder {
  $id: string
  $createdAt: string
  createdBy: string
  totalPrice: number
  status: string
  notes: string | null
  pickupTime: string | null
  items: OrderItem[]
}

const statusConfig: Record<
  string,
  {
    label: string
    color: string
    bgColor: string
    icon: React.ReactNode
  }
> = {
  pending: {
    label: 'New',
    color: '#E07A5F',
    bgColor: '#E07A5F15',
    icon: <Bell className="w-4 h-4" />,
  },
  confirmed: {
    label: 'Confirmed',
    color: '#3D5A80',
    bgColor: '#3D5A8015',
    icon: <CheckCircle2 className="w-4 h-4" />,
  },
  preparing: {
    label: 'Preparing',
    color: '#F2CC8F',
    bgColor: '#F2CC8F20',
    icon: <ChefHat className="w-4 h-4" />,
  },
  ready: {
    label: 'Ready',
    color: '#81B29A',
    bgColor: '#81B29A15',
    icon: <Package className="w-4 h-4" />,
  },
  picked_up: {
    label: 'Picked Up',
    color: '#6B7280',
    bgColor: '#6B728015',
    icon: <CheckCircle2 className="w-4 h-4" />,
  },
  cancelled: {
    label: 'Cancelled',
    color: '#EF4444',
    bgColor: '#EF444415',
    icon: <XCircle className="w-4 h-4" />,
  },
}

const spiceLevelEmoji: Record<string, string> = {
  '0': '🥛',
  '1': '🌶️',
  '2': '🌶️🌶️',
  '3': '🔥',
  '4': '🔥🔥',
}

export function KitchenDashboard() {
  const [orders, setOrders] = useState<KitchenOrder[]>([])
  const [stats, setStats] = useState<{
    totalToday: number
    pending: number
    preparing: number
    ready: number
    completed: number
    cancelled: number
    revenue: number
  } | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedStatus] = useState<string[]>([
    'pending',
    'confirmed',
    'preparing',
    'ready',
  ])
  const [searchQuery, setSearchQuery] = useState('')
  const [isRefreshing, setIsRefreshing] = useState(false)

  const fetchOrders = async () => {
    try {
      const [ordersResult, statsResult] = await Promise.all([
        getKitchenOrdersFn({ data: { statuses: selectedStatus, limit: 50 } }),
        getOrderStatsFn(),
      ])
      setOrders(ordersResult.orders as KitchenOrder[])
      setStats(statsResult.stats)
    } catch (error) {
      console.error('Failed to fetch orders:', error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    void fetchOrders()
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => void fetchOrders(), 30000)
    return () => clearInterval(interval)
  }, [selectedStatus])

  const handleRefresh = () => {
    setIsRefreshing(true)
    void fetchOrders()
  }

  const handleStatusChange = async (
    orderId: string,
    newStatus: OrderStatus,
  ) => {
    try {
      await updateOrderStatusFn({ data: { orderId, newStatus } })
      void fetchOrders()
    } catch (error) {
      console.error('Failed to update order status:', error)
    }
  }

  const getNextStatus = (currentStatus: string): OrderStatus | null => {
    const flow: Record<string, OrderStatus> = {
      pending: 'confirmed',
      confirmed: 'preparing',
      preparing: 'ready',
      ready: 'picked_up',
    }
    return flow[currentStatus] || null
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getTimeSince = (dateString: string) => {
    const now = new Date()
    const then = new Date(dateString)
    const diffMs = now.getTime() - then.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    const diffHours = Math.floor(diffMins / 60)
    return `${diffHours}h ${diffMins % 60}m ago`
  }

  const filteredOrders = orders.filter((order) => {
    if (!searchQuery) return true
    return order.$id.toLowerCase().includes(searchQuery.toLowerCase())
  })

  // Group orders by status for Kanban view
  const ordersByStatus = {
    pending: filteredOrders.filter((o) => o.status === 'pending'),
    confirmed: filteredOrders.filter((o) => o.status === 'confirmed'),
    preparing: filteredOrders.filter((o) => o.status === 'preparing'),
    ready: filteredOrders.filter((o) => o.status === 'ready'),
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8F8F8] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <ChefHat className="w-12 h-12 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#2D3436]/10 sticky top-0 z-40">
        <div className="max-w-[1800px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-[#E07A5F] to-[#C4563D] rounded-xl flex items-center justify-center">
                <ChefHat className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1
                  className="text-xl font-bold text-[#2D3436]"
                  style={{ fontFamily: 'Fraunces, serif' }}
                >
                  Kitchen Dashboard
                </h1>
                <p
                  className="text-sm text-[#2D3436]/60"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Real-time order management
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                <input
                  type="text"
                  placeholder="Search orders..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30 w-64"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>

              {/* Refresh button */}
              <motion.button
                onClick={handleRefresh}
                className="p-2 bg-[#F5F5F5] rounded-xl hover:bg-[#EBEBEB] transition-colors"
                whileTap={{ scale: 0.95 }}
              >
                <RefreshCw
                  className={`w-5 h-5 text-[#2D3436]/60 ${isRefreshing ? 'animate-spin' : ''}`}
                />
              </motion.button>

              {/* Current time */}
              <div
                className="px-4 py-2 bg-[#2D3436] text-white rounded-xl text-sm font-medium"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {new Date().toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Bar */}
      {stats && (
        <div className="bg-white border-b border-[#2D3436]/5">
          <div className="max-w-[1800px] mx-auto px-6 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              <StatCard
                label="Total Today"
                value={stats.totalToday}
                icon={<Package className="w-4 h-4" />}
                color="#2D3436"
              />
              <StatCard
                label="New Orders"
                value={stats.pending}
                icon={<Bell className="w-4 h-4" />}
                color="#E07A5F"
                pulse={stats.pending > 0}
              />
              <StatCard
                label="Preparing"
                value={stats.preparing}
                icon={<ChefHat className="w-4 h-4" />}
                color="#F2CC8F"
              />
              <StatCard
                label="Ready"
                value={stats.ready}
                icon={<CheckCircle2 className="w-4 h-4" />}
                color="#81B29A"
              />
              <StatCard
                label="Completed"
                value={stats.completed}
                icon={<Users className="w-4 h-4" />}
                color="#3D5A80"
              />
              <StatCard
                label="Cancelled"
                value={stats.cancelled}
                icon={<XCircle className="w-4 h-4" />}
                color="#EF4444"
              />
              <StatCard
                label="Revenue"
                value={`$${stats.revenue.toFixed(0)}`}
                icon={<DollarSign className="w-4 h-4" />}
                color="#81B29A"
              />
            </div>
          </div>
        </div>
      )}

      {/* Kanban Board */}
      <div className="max-w-[1800px] mx-auto px-6 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {(['pending', 'confirmed', 'preparing', 'ready'] as const).map(
            (status) => (
              <div key={status} className="flex flex-col">
                {/* Column Header */}
                <div className="flex items-center justify-between mb-4 px-2">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: statusConfig[status].bgColor }}
                    >
                      <span style={{ color: statusConfig[status].color }}>
                        {statusConfig[status].icon}
                      </span>
                    </div>
                    <span
                      className="font-semibold text-[#2D3436]"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {statusConfig[status].label}
                    </span>
                  </div>
                  <span
                    className="px-2 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: statusConfig[status].bgColor,
                      color: statusConfig[status].color,
                      fontFamily: 'DM Sans, sans-serif',
                    }}
                  >
                    {ordersByStatus[status].length}
                  </span>
                </div>

                {/* Orders List */}
                <div className="flex-1 space-y-3 min-h-[400px]">
                  <AnimatePresence mode="popLayout">
                    {ordersByStatus[status].map((order) => (
                      <OrderCard
                        key={order.$id}
                        order={order}
                        onStatusChange={handleStatusChange}
                        nextStatus={getNextStatus(order.status)}
                        formatTime={formatTime}
                        getTimeSince={getTimeSince}
                      />
                    ))}
                  </AnimatePresence>

                  {ordersByStatus[status].length === 0 && (
                    <div className="flex flex-col items-center justify-center py-12 text-[#2D3436]/30">
                      <Package className="w-8 h-8 mb-2" />
                      <span
                        className="text-sm"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        No orders
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ),
          )}
        </div>
      </div>
    </div>
  )
}

function StatCard({
  label,
  value,
  icon,
  color,
  pulse = false,
}: {
  label: string
  value: number | string
  icon: React.ReactNode
  color: string
  pulse?: boolean
}) {
  return (
    <motion.div
      className="relative bg-white rounded-xl p-4 border border-[#2D3436]/5"
      whileHover={{ y: -2 }}
    >
      {pulse && (
        <span className="absolute top-2 right-2 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E07A5F] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-[#E07A5F]"></span>
        </span>
      )}
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${color}15` }}
        >
          <span style={{ color }}>{icon}</span>
        </div>
        <div>
          <p
            className="text-xs text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {label}
          </p>
          <p
            className="text-xl font-bold text-[#2D3436]"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {value}
          </p>
        </div>
      </div>
    </motion.div>
  )
}

function OrderCard({
  order,
  onStatusChange,
  nextStatus,
  formatTime,
  getTimeSince,
}: {
  order: KitchenOrder
  onStatusChange: (orderId: string, status: OrderStatus) => void
  nextStatus: OrderStatus | null
  formatTime: (date: string) => string
  getTimeSince: (date: string) => string
}) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-white rounded-xl border border-[#2D3436]/5 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
    >
      {/* Header */}
      <div
        className="p-4 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between mb-2">
          <span
            className="text-sm font-bold text-[#2D3436]"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            #{order.$id.slice(-6).toUpperCase()}
          </span>
          <div className="flex items-center gap-2">
            <span
              className="flex items-center gap-1 text-xs text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <Clock className="w-3 h-3" />
              {getTimeSince(order.$createdAt)}
            </span>
          </div>
        </div>

        {/* Items preview */}
        <div className="space-y-1">
          {order.items.slice(0, isExpanded ? undefined : 2).map((item) => (
            <div
              key={item.$id}
              className="flex items-center gap-2 text-sm"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <span className="font-medium text-[#2D3436]">
                {item.quantity}×
              </span>
              <span className="text-[#2D3436]/70 truncate flex-1">
                Meal #{item.mealId.slice(-4)}
              </span>
              {item.spiceLevel && (
                <span>{spiceLevelEmoji[item.spiceLevel] || '🌶️'}</span>
              )}
            </div>
          ))}
          {!isExpanded && order.items.length > 2 && (
            <span
              className="text-xs text-[#E07A5F]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              +{order.items.length - 2} more items
            </span>
          )}
        </div>

        {/* Expanded details */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-3 pt-3 border-t border-[#2D3436]/5"
            >
              {order.items.map((item) => (
                <div key={item.$id} className="mb-2">
                  {item.portionSize && item.portionSize !== 'regular' && (
                    <span
                      className="inline-block px-2 py-0.5 bg-[#F5F5F5] rounded text-xs mr-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {item.portionSize}
                    </span>
                  )}
                  {item.addOns && item.addOns.length > 0 && (
                    <span
                      className="inline-block px-2 py-0.5 bg-[#F2CC8F]/20 text-[#D4A84B] rounded text-xs mr-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      +{item.addOns.length} add-ons
                    </span>
                  )}
                  {item.specialInstructions && (
                    <p
                      className="text-xs text-[#E07A5F] mt-1 italic"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      ⚠️ {item.specialInstructions}
                    </p>
                  )}
                </div>
              ))}

              {order.notes && (
                <div className="mt-2 p-2 bg-[#FEF3C7] rounded-lg">
                  <p
                    className="text-xs text-[#92400E]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    📝 {order.notes}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between mt-3">
                <span
                  className="text-lg font-bold text-[#2D3436]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  ${order.totalPrice.toFixed(2)}
                </span>
                <span
                  className="text-xs text-[#2D3436]/50"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {formatTime(order.$createdAt)}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Button */}
      {nextStatus && (
        <motion.button
          onClick={() => onStatusChange(order.$id, nextStatus)}
          className="w-full py-3 flex items-center justify-center gap-2 font-medium transition-colors"
          style={{
            backgroundColor: statusConfig[nextStatus].bgColor,
            color: statusConfig[nextStatus].color,
            fontFamily: 'DM Sans, sans-serif',
          }}
          whileHover={{
            backgroundColor: statusConfig[nextStatus].color,
            color: 'white',
          }}
          whileTap={{ scale: 0.98 }}
        >
          <span>Move to {statusConfig[nextStatus].label}</span>
          <ArrowRight className="w-4 h-4" />
        </motion.button>
      )}
    </motion.div>
  )
}
