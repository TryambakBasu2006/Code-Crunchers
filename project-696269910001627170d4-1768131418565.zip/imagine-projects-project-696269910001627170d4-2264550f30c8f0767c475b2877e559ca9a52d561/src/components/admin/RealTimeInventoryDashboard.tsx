import { useState, useEffect } from 'react'
import { motion } from 'motion/react'
import {
  AlertTriangle,
  Package,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingDown,
  Zap,
  Bell,
  Eye,
  EyeOff,
  Activity,
} from 'lucide-react'
import {
  getMealAvailabilityFn,
  syncAllMealsAvailabilityFn,
  getInventoryAlertsFn,
  resolveInventoryAlertFn,
  ALERT_TYPES,
} from '@/server/functions/realtime-inventory'
import type {
  MealAvailability,
  InventoryAlerts,
} from '@/server/lib/appwrite.types'

// ============================================
// REAL-TIME INVENTORY DASHBOARD
// ============================================

export function RealTimeInventoryDashboard() {
  const [availability, setAvailability] = useState<MealAvailability[]>([])
  const [alerts, setAlerts] = useState<InventoryAlerts[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSync, setLastSync] = useState<Date | null>(null)
  const [showUnavailable, setShowUnavailable] = useState(true)

  const fetchData = async () => {
    try {
      const [availabilityResult, alertsResult] = await Promise.all([
        getMealAvailabilityFn({ data: { includeUnavailable: true } }),
        getInventoryAlertsFn({ data: { unresolvedOnly: true, limit: 20 } }),
      ])
      setAvailability(availabilityResult.availability)
      setAlerts(alertsResult.alerts)
    } catch (error) {
      console.error('Failed to fetch inventory data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    void fetchData()
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => void fetchData(), 30000)
    return () => clearInterval(interval)
  }, [])

  const handleSync = async () => {
    setIsSyncing(true)
    try {
      const result = await syncAllMealsAvailabilityFn()
      setLastSync(new Date())
      void fetchData()
      alert(
        `Synced ${result.synced} meals. ${result.unavailable} are now unavailable.`,
      )
    } catch (error) {
      console.error('Failed to sync:', error)
      alert('Failed to sync meal availability')
    } finally {
      setIsSyncing(false)
    }
  }

  const handleResolveAlert = async (alertId: string) => {
    try {
      await resolveInventoryAlertFn({ data: { alertId } })
      setAlerts((prev) => prev.filter((a) => a.$id !== alertId))
    } catch (error) {
      console.error('Failed to resolve alert:', error)
    }
  }

  const availableMeals = availability.filter((a) => a.isAvailable)
  const unavailableMeals = availability.filter((a) => !a.isAvailable)

  const getAlertConfig = (alertType: string) => {
    switch (alertType) {
      case ALERT_TYPES.OUT_OF_STOCK:
        return {
          label: 'Out of Stock',
          color: '#EF4444',
          bgColor: '#EF4444',
          icon: <XCircle className="w-4 h-4" />,
        }
      case ALERT_TYPES.LOW_STOCK:
        return {
          label: 'Low Stock',
          color: '#F2CC8F',
          bgColor: '#F2CC8F',
          icon: <TrendingDown className="w-4 h-4" />,
        }
      case ALERT_TYPES.EXPIRING_SOON:
        return {
          label: 'Expiring Soon',
          color: '#E07A5F',
          bgColor: '#E07A5F',
          icon: <Clock className="w-4 h-4" />,
        }
      default:
        return {
          label: alertType,
          color: '#6B7280',
          bgColor: '#6B7280',
          icon: <AlertTriangle className="w-4 h-4" />,
        }
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Activity className="w-8 h-8 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2
            className="text-xl font-bold text-[#2D3436] flex items-center gap-2"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            <Zap className="w-5 h-5 text-[#E07A5F]" />
            Real-Time Inventory
          </h2>
          {lastSync && (
            <p
              className="text-xs text-[#2D3436]/50 mt-1"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Last synced: {lastSync.toLocaleTimeString()}
            </p>
          )}
        </div>
        <motion.button
          onClick={handleSync}
          disabled={isSyncing}
          className="flex items-center gap-2 px-4 py-2 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors disabled:opacity-50"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          whileTap={{ scale: 0.95 }}
        >
          <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
          {isSyncing ? 'Syncing...' : 'Sync All'}
        </motion.button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-[#81B29A]/20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-[#81B29A]" />
            </div>
            <div>
              <p
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Available Meals
              </p>
              <p
                className="text-2xl font-bold text-[#81B29A]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {availableMeals.length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-[#EF4444]/20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#EF4444]/10 rounded-xl flex items-center justify-center">
              <XCircle className="w-6 h-6 text-[#EF4444]" />
            </div>
            <div>
              <p
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Sold Out
              </p>
              <p
                className="text-2xl font-bold text-[#EF4444]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {unavailableMeals.length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-[#F2CC8F]/30">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#F2CC8F]/20 rounded-xl flex items-center justify-center">
              <Bell className="w-6 h-6 text-[#D4A84B]" />
            </div>
            <div>
              <p
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Active Alerts
              </p>
              <p
                className="text-2xl font-bold text-[#D4A84B]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {alerts.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Alerts Section */}
      {alerts.length > 0 && (
        <div className="bg-white rounded-xl border border-[#2D3436]/5 overflow-hidden">
          <div className="p-4 border-b border-[#2D3436]/5 bg-gradient-to-r from-[#EF4444]/5 to-transparent">
            <h3
              className="font-semibold text-[#2D3436] flex items-center gap-2"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <AlertTriangle className="w-5 h-5 text-[#EF4444]" />
              Inventory Alerts
            </h3>
          </div>
          <div className="divide-y divide-[#2D3436]/5">
            {alerts.map((alert) => {
              const config = getAlertConfig(alert.alertType)
              return (
                <motion.div
                  key={alert.$id}
                  layout
                  className="p-4 flex items-center justify-between hover:bg-[#F5F5F5] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${config.bgColor}15` }}
                    >
                      <span style={{ color: config.color }}>{config.icon}</span>
                    </div>
                    <div>
                      <span
                        className="text-sm font-medium text-[#2D3436] block"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        {config.label}
                      </span>
                      <span
                        className="text-xs text-[#2D3436]/50"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Ingredient #{alert.ingredientId.slice(-6)} •{' '}
                        {new Date(alert.$createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleResolveAlert(alert.$id)}
                    className="px-3 py-1.5 bg-[#81B29A]/10 text-[#81B29A] font-medium rounded-lg hover:bg-[#81B29A]/20 transition-colors text-sm"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Resolve
                  </button>
                </motion.div>
              )
            })}
          </div>
        </div>
      )}

      {/* Meal Availability Grid */}
      <div className="bg-white rounded-xl border border-[#2D3436]/5 overflow-hidden">
        <div className="p-4 border-b border-[#2D3436]/5 flex items-center justify-between">
          <h3
            className="font-semibold text-[#2D3436] flex items-center gap-2"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            <Package className="w-5 h-5 text-[#3D5A80]" />
            Meal Availability
          </h3>
          <button
            onClick={() => setShowUnavailable(!showUnavailable)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#F5F5F5] rounded-lg text-sm text-[#2D3436]/70 hover:bg-[#EBEBEB] transition-colors"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {showUnavailable ? (
              <>
                <EyeOff className="w-4 h-4" />
                Hide Unavailable
              </>
            ) : (
              <>
                <Eye className="w-4 h-4" />
                Show Unavailable
              </>
            )}
          </button>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {availability
              .filter((a) => showUnavailable || a.isAvailable)
              .map((meal) => (
                <motion.div
                  key={meal.$id}
                  layout
                  className={`p-3 rounded-xl border ${
                    meal.isAvailable
                      ? 'border-[#81B29A]/20 bg-[#81B29A]/5'
                      : 'border-[#EF4444]/20 bg-[#EF4444]/5'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {meal.isAvailable ? (
                        <CheckCircle2 className="w-4 h-4 text-[#81B29A]" />
                      ) : (
                        <XCircle className="w-4 h-4 text-[#EF4444]" />
                      )}
                      <span
                        className="text-sm font-medium text-[#2D3436]"
                        style={{ fontFamily: 'DM Sans, sans-serif' }}
                      >
                        Meal #{meal.mealId.slice(-6)}
                      </span>
                    </div>
                    {meal.availableQuantity !== null && (
                      <span
                        className={`text-xs font-medium px-2 py-0.5 rounded ${
                          meal.availableQuantity > 10
                            ? 'bg-[#81B29A]/20 text-[#81B29A]'
                            : meal.availableQuantity > 0
                              ? 'bg-[#F2CC8F]/20 text-[#D4A84B]'
                              : 'bg-[#EF4444]/20 text-[#EF4444]'
                        }`}
                      >
                        {meal.availableQuantity} left
                      </span>
                    )}
                  </div>
                  {!meal.isAvailable && meal.unavailableReason && (
                    <p
                      className="text-xs text-[#EF4444]/70 mt-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {meal.unavailableReason}
                    </p>
                  )}
                  {meal.lastCheckedAt && (
                    <p
                      className="text-xs text-[#2D3436]/40 mt-1"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Checked:{' '}
                      {new Date(meal.lastCheckedAt).toLocaleTimeString()}
                    </p>
                  )}
                </motion.div>
              ))}
          </div>

          {availability.length === 0 && (
            <div className="text-center py-12">
              <Package className="w-12 h-12 text-[#2D3436]/20 mx-auto mb-4" />
              <p
                className="text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                No meal availability data. Click "Sync All" to update.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ============================================
// SOLD OUT BADGE (for MealCard)
// ============================================

export function SoldOutBadge() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-2xl flex items-center justify-center z-10"
    >
      <div className="text-center">
        <XCircle className="w-12 h-12 text-white mx-auto mb-2" />
        <span
          className="text-white font-bold text-lg"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          SOLD OUT
        </span>
      </div>
    </motion.div>
  )
}

// ============================================
// LOW STOCK INDICATOR
// ============================================

interface LowStockIndicatorProps {
  quantity: number
  threshold?: number
}

export function LowStockIndicator({
  quantity,
  threshold = 5,
}: LowStockIndicatorProps) {
  if (quantity > threshold) return null

  return (
    <motion.span
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="inline-flex items-center gap-1 px-2 py-0.5 bg-[#F2CC8F]/20 text-[#D4A84B] rounded text-xs font-medium"
    >
      <TrendingDown className="w-3 h-3" />
      Only {quantity} left
    </motion.span>
  )
}
