import { useState } from 'react'
import { motion } from 'motion/react'
import { useMutation } from '@tanstack/react-query'
import { useNavigate, Link } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import {
  Shield,
  Key,
  CheckCircle,
  AlertCircle,
  ArrowLeft,
  Loader2,
  Lock,
  UserCog,
} from 'lucide-react'
import { promoteToAdminFn } from '@/server/functions'

export function AdminSetupPage() {
  const [secretKey, setSecretKey] = useState('')
  const [success, setSuccess] = useState(false)
  const navigate = useNavigate()

  const promoteToAdmin = useServerFn(promoteToAdminFn)

  const setupMutation = useMutation({
    mutationFn: async () => {
      return await promoteToAdmin({ data: { secretKey } })
    },
    onSuccess: () => {
      setSuccess(true)
      setTimeout(() => {
        void navigate({ to: '/menu-management' })
      }, 2000)
    },
  })

  if (success) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-[#81B29A]/10 via-white to-[#81B29A]/5 flex items-center justify-center p-6">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <motion.div
            className="w-20 h-20 bg-[#81B29A] rounded-full flex items-center justify-center mx-auto mb-6"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
          >
            <CheckCircle className="w-10 h-10 text-white" />
          </motion.div>
          <h1
            className="text-2xl font-bold text-[#2D3436] mb-2"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Admin Access Granted!
          </h1>
          <p
            className="text-[#2D3436]/60 mb-4"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Redirecting to admin dashboard...
          </p>
          <Loader2 className="w-6 h-6 text-[#81B29A] animate-spin mx-auto" />
        </motion.div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#2D3436] via-[#1a1f20] to-[#2D3436] flex items-center justify-center p-6">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#81B29A]/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#E07A5F]/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        className="relative w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Back link */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-8"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        {/* Setup card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#81B29A] to-[#5A9A7A] p-8 text-center">
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-2xl mb-4"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            >
              <UserCog className="w-8 h-8 text-white" />
            </motion.div>
            <h1
              className="text-2xl font-bold text-white mb-2"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              Admin Setup
            </h1>
            <p
              className="text-white/80 text-sm"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Enter the setup key to gain admin access
            </p>
          </div>

          {/* Form */}
          <div className="p-8 space-y-6">
            {/* Info box */}
            <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-100 rounded-xl">
              <Shield className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div>
                <p
                  className="text-sm text-blue-800 font-medium"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  First-time Setup
                </p>
                <p
                  className="text-xs text-blue-600 mt-1"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  This will promote your current account to admin status. You'll
                  be able to manage the menu, staff, and orders.
                </p>
              </div>
            </div>

            {/* Error message */}
            {setupMutation.isError && (
              <motion.div
                className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                <p
                  className="text-sm text-red-700"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {(setupMutation.error as Error)?.message ||
                    'Invalid setup key'}
                </p>
              </motion.div>
            )}

            {/* Secret key field */}
            <div className="space-y-2">
              <label
                htmlFor="secretKey"
                className="block text-sm font-medium text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Setup Key
              </label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#2D3436]/40" />
                <input
                  type="password"
                  id="secretKey"
                  value={secretKey}
                  onChange={(e) => setSecretKey(e.target.value)}
                  placeholder="Enter the admin setup key"
                  className="w-full pl-12 pr-4 py-3.5 bg-[#F5F5F5] rounded-xl border-2 border-transparent focus:border-[#81B29A] focus:bg-white outline-none transition-all duration-300"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>
              <p
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Default key:{' '}
                <code className="bg-[#F5F5F5] px-1.5 py-0.5 rounded">
                  canteen-admin-setup-2024
                </code>
              </p>
            </div>

            {/* Submit button */}
            <motion.button
              type="button"
              onClick={() => setupMutation.mutate()}
              disabled={setupMutation.isPending || !secretKey}
              className={`
                                w-full flex items-center justify-center gap-2 py-4 rounded-xl
                                font-semibold text-white transition-all duration-300
                                ${
                                  setupMutation.isPending || !secretKey
                                    ? 'bg-[#81B29A]/50 cursor-not-allowed'
                                    : 'bg-[#81B29A] hover:bg-[#5A9A7A] shadow-lg shadow-[#81B29A]/20'
                                }
                            `}
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              whileHover={{ scale: setupMutation.isPending ? 1 : 1.02 }}
              whileTap={{ scale: setupMutation.isPending ? 1 : 0.98 }}
            >
              {setupMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Setting up...
                </>
              ) : (
                <>
                  <Lock className="w-5 h-5" />
                  Activate Admin Access
                </>
              )}
            </motion.button>
          </div>

          {/* Footer */}
          <div className="px-8 pb-8">
            <div className="pt-6 border-t border-[#2D3436]/10 text-center">
              <p
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                🔒 This action is logged for security purposes
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </main>
  )
}
