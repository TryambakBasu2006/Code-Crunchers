import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Package,
  Clock,
  CheckCircle2,
  ChefHat,
  Bell,
  XCircle,
  MapPin,
  Receipt,
  ChevronDown,
  RefreshCw,
  Loader2,
} from 'lucide-react'
import {
  getUserOrdersFn,
  getOrderDetailsFn,
  cancelOrderFn,
} from '@/server/functions/orders'
import type {
  Orders,
  OrderItems,
  OrderHistory,
} from '@/server/lib/appwrite.types'

interface OrderWithDetails extends Orders {
  items?: OrderItems[]
  history?: OrderHistory[]
}

const statusConfig: Record<
  string,
  {
    label: string
    description: string
    color: string
    bgColor: string
    icon: React.ReactNode
    step: number
  }
> = {
  pending: {
    label: 'Order Placed',
    description: 'Waiting for confirmation',
    color: '#F2CC8F',
    bgColor: '#F2CC8F20',
    icon: <Clock className="w-5 h-5" />,
    step: 1,
  },
  confirmed: {
    label: 'Confirmed',
    description: 'Payment received, preparing soon',
    color: '#3D5A80',
    bgColor: '#3D5A8015',
    icon: <CheckCircle2 className="w-5 h-5" />,
    step: 2,
  },
  preparing: {
    label: 'Preparing',
    description: 'Your meal is being prepared',
    color: '#E07A5F',
    bgColor: '#E07A5F15',
    icon: <ChefHat className="w-5 h-5" />,
    step: 3,
  },
  ready: {
    label: 'Ready for Pickup',
    description: 'Head to the counter!',
    color: '#81B29A',
    bgColor: '#81B29A15',
    icon: <Bell className="w-5 h-5" />,
    step: 4,
  },
  picked_up: {
    label: 'Completed',
    description: 'Order picked up',
    color: '#6B7280',
    bgColor: '#6B728015',
    icon: <Package className="w-5 h-5" />,
    step: 5,
  },
  cancelled: {
    label: 'Cancelled',
    description: 'Order was cancelled',
    color: '#EF4444',
    bgColor: '#EF444415',
    icon: <XCircle className="w-5 h-5" />,
    step: 0,
  },
}

export function OrderTracking() {
  const [orders, setOrders] = useState<Orders[]>([])
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)
  const [orderDetails, setOrderDetails] = useState<
    Record<string, OrderWithDetails>
  >({})
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [cancellingOrder, setCancellingOrder] = useState<string | null>(null)

  const fetchOrders = async () => {
    try {
      const result = await getUserOrdersFn({ data: { limit: 20 } })
      setOrders(result.orders)
    } catch (error) {
      console.error('Failed to fetch orders:', error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    void fetchOrders()
    // Auto-refresh every 30 seconds for active orders
    const interval = setInterval(() => void fetchOrders(), 30000)
    return () => clearInterval(interval)
  }, [])

  const handleExpand = async (orderId: string) => {
    if (expandedOrder === orderId) {
      setExpandedOrder(null)
      return
    }

    setExpandedOrder(orderId)

    if (!orderDetails[orderId]) {
      try {
        const result = await getOrderDetailsFn({ data: { orderId } })
        setOrderDetails((prev) => ({
          ...prev,
          [orderId]: {
            ...result.order,
            items: result.items,
            history: result.history,
          },
        }))
      } catch (error) {
        console.error('Failed to fetch order details:', error)
      }
    }
  }

  const handleCancel = async (orderId: string) => {
    if (!confirm('Are you sure you want to cancel this order?')) return

    setCancellingOrder(orderId)
    try {
      await cancelOrderFn({ data: { orderId } })
      void fetchOrders()
    } catch (error) {
      console.error('Failed to cancel order:', error)
      alert('Failed to cancel order. Only pending orders can be cancelled.')
    } finally {
      setCancellingOrder(null)
    }
  }

  const handleRefresh = () => {
    setIsRefreshing(true)
    void fetchOrders()
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const activeOrders = orders.filter((o) =>
    ['pending', 'confirmed', 'preparing', 'ready'].includes(o.status),
  )
  const pastOrders = orders.filter((o) =>
    ['picked_up', 'cancelled'].includes(o.status),
  )

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Package className="w-8 h-8 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1
            className="text-2xl md:text-3xl font-bold text-[#2D3436] mb-2"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            My Orders
          </h1>
          <p
            className="text-[#2D3436]/60"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Track your orders and view history
          </p>
        </div>
        <motion.button
          onClick={handleRefresh}
          className="p-3 bg-white rounded-xl border border-[#2D3436]/10 hover:bg-[#F5F5F5] transition-colors"
          whileTap={{ scale: 0.95 }}
        >
          <RefreshCw
            className={`w-5 h-5 text-[#2D3436]/60 ${isRefreshing ? 'animate-spin' : ''}`}
          />
        </motion.button>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-[#2D3436]/5">
          <Package className="w-16 h-16 text-[#2D3436]/20 mx-auto mb-4" />
          <h3
            className="text-lg font-semibold text-[#2D3436] mb-2"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            No orders yet
          </h3>
          <p
            className="text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Your order history will appear here
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Active Orders */}
          {activeOrders.length > 0 && (
            <section>
              <h2
                className="text-lg font-semibold text-[#2D3436] mb-4 flex items-center gap-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#81B29A] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-[#81B29A]"></span>
                </span>
                Active Orders
              </h2>

              <div className="space-y-4">
                {activeOrders.map((order) => (
                  <OrderCard
                    key={order.$id}
                    order={order}
                    details={orderDetails[order.$id]}
                    isExpanded={expandedOrder === order.$id}
                    onExpand={() => handleExpand(order.$id)}
                    onCancel={() => handleCancel(order.$id)}
                    isCancelling={cancellingOrder === order.$id}
                    formatDate={formatDate}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Past Orders */}
          {pastOrders.length > 0 && (
            <section>
              <h2
                className="text-lg font-semibold text-[#2D3436] mb-4"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Past Orders
              </h2>

              <div className="space-y-4">
                {pastOrders.map((order) => (
                  <OrderCard
                    key={order.$id}
                    order={order}
                    details={orderDetails[order.$id]}
                    isExpanded={expandedOrder === order.$id}
                    onExpand={() => handleExpand(order.$id)}
                    onCancel={() => {}}
                    isCancelling={false}
                    formatDate={formatDate}
                    isPast
                  />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  )
}

function OrderCard({
  order,
  details,
  isExpanded,
  onExpand,
  onCancel,
  isCancelling,
  formatDate,
  isPast = false,
}: {
  order: Orders
  details?: OrderWithDetails
  isExpanded: boolean
  onExpand: () => void
  onCancel: () => void
  isCancelling: boolean
  formatDate: (date: string) => string
  isPast?: boolean
}) {
  const config = statusConfig[order.status]
  const steps = ['pending', 'confirmed', 'preparing', 'ready']

  return (
    <motion.div
      layout
      className={`bg-white rounded-2xl border overflow-hidden ${
        isPast ? 'border-[#2D3436]/5 opacity-80' : 'border-[#2D3436]/10'
      }`}
    >
      {/* Header */}
      <div className="p-4 cursor-pointer" onClick={onExpand}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: config.bgColor }}
            >
              <span style={{ color: config.color }}>{config.icon}</span>
            </div>
            <div>
              <span
                className="text-sm font-bold text-[#2D3436] block"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Order #{order.$id.slice(-6).toUpperCase()}
              </span>
              <span
                className="text-xs text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {formatDate(order.$createdAt)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span
              className="px-3 py-1 rounded-full text-xs font-medium"
              style={{
                backgroundColor: config.bgColor,
                color: config.color,
                fontFamily: 'DM Sans, sans-serif',
              }}
            >
              {config.label}
            </span>
            <motion.div animate={{ rotate: isExpanded ? 180 : 0 }}>
              <ChevronDown className="w-5 h-5 text-[#2D3436]/40" />
            </motion.div>
          </div>
        </div>

        {/* Progress Steps (for active orders) */}
        {!isPast && order.status !== 'cancelled' && (
          <div className="flex items-center gap-1 mt-4">
            {steps.map((step) => {
              const stepConfig = statusConfig[step]
              const isActive = config.step >= stepConfig.step
              const isCurrent = order.status === step

              return (
                <div key={step} className="flex-1 flex items-center">
                  <div className="flex-1 relative">
                    <div
                      className="h-1.5 rounded-full transition-colors"
                      style={{
                        backgroundColor: isActive
                          ? stepConfig.color
                          : '#E5E7EB',
                      }}
                    />
                    {isCurrent && (
                      <motion.div
                        className="absolute top-1/2 right-0 -translate-y-1/2 w-3 h-3 rounded-full"
                        style={{ backgroundColor: stepConfig.color }}
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      />
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Status Message */}
        <p
          className="text-sm text-[#2D3436]/60 mt-3"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          {config.description}
        </p>
      </div>

      {/* Expanded Details */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-[#2D3436]/5"
          >
            <div className="p-4 space-y-4">
              {/* Order Items */}
              {details?.items && details.items.length > 0 && (
                <div>
                  <h4
                    className="text-sm font-semibold text-[#2D3436] mb-2 flex items-center gap-2"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    <Receipt className="w-4 h-4" />
                    Order Items
                  </h4>
                  <div className="space-y-2">
                    {details.items.map((item) => (
                      <div
                        key={item.$id}
                        className="flex items-center justify-between p-3 bg-[#F5F5F5] rounded-xl"
                      >
                        <div className="flex items-center gap-3">
                          <span
                            className="text-sm font-medium text-[#2D3436]"
                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                          >
                            {item.quantity}×
                          </span>
                          <div>
                            <span
                              className="text-sm text-[#2D3436] block"
                              style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                              Meal #{item.mealId.slice(-4)}
                            </span>
                            <div className="flex items-center gap-2 mt-0.5">
                              {item.portionSize &&
                                item.portionSize !== 'regular' && (
                                  <span className="text-[10px] px-1.5 py-0.5 bg-white rounded text-[#2D3436]/60">
                                    {item.portionSize}
                                  </span>
                                )}
                              {item.spiceLevel && (
                                <span className="text-[10px]">
                                  {'🌶️'.repeat(parseInt(item.spiceLevel) || 1)}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <span
                          className="text-sm font-medium text-[#2D3436]"
                          style={{ fontFamily: 'DM Sans, sans-serif' }}
                        >
                          ${item.totalPrice.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Order Notes */}
              {order.notes && (
                <div className="p-3 bg-[#FEF3C7] rounded-xl">
                  <p
                    className="text-sm text-[#92400E]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    📝 {order.notes}
                  </p>
                </div>
              )}

              {/* Order History Timeline */}
              {details?.history && details.history.length > 0 && (
                <div>
                  <h4
                    className="text-sm font-semibold text-[#2D3436] mb-2 flex items-center gap-2"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    <Clock className="w-4 h-4" />
                    Order Timeline
                  </h4>
                  <div className="space-y-2">
                    {details.history.map((entry, index) => (
                      <div key={entry.$id} className="flex items-start gap-3">
                        <div className="flex flex-col items-center">
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{
                              backgroundColor:
                                statusConfig[entry.newStatus]?.color ||
                                '#6B7280',
                            }}
                          />
                          {index < details.history!.length - 1 && (
                            <div className="w-0.5 h-6 bg-[#E5E7EB]" />
                          )}
                        </div>
                        <div className="flex-1 -mt-1">
                          <span
                            className="text-sm font-medium text-[#2D3436]"
                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                          >
                            {statusConfig[entry.newStatus]?.label ||
                              entry.newStatus}
                          </span>
                          <span
                            className="text-xs text-[#2D3436]/50 block"
                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                          >
                            {formatDate(entry.$createdAt)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Total */}
              <div className="flex items-center justify-between pt-3 border-t border-[#2D3436]/5">
                <span
                  className="text-sm text-[#2D3436]/60"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Total
                </span>
                <span
                  className="text-xl font-bold text-[#2D3436]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  ${order.totalPrice.toFixed(2)}
                </span>
              </div>

              {/* Cancel Button (only for pending orders) */}
              {order.status === 'pending' && (
                <motion.button
                  onClick={(e) => {
                    e.stopPropagation()
                    onCancel()
                  }}
                  disabled={isCancelling}
                  className="w-full py-3 bg-[#FEE2E2] text-[#EF4444] font-medium rounded-xl hover:bg-[#FECACA] transition-colors disabled:opacity-50"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isCancelling ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Cancelling...
                    </span>
                  ) : (
                    'Cancel Order'
                  )}
                </motion.button>
              )}

              {/* Ready for Pickup Banner */}
              {order.status === 'ready' && (
                <motion.div
                  className="p-4 bg-gradient-to-r from-[#81B29A] to-[#5A9A7A] rounded-xl text-white text-center"
                  animate={{ scale: [1, 1.02, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Bell className="w-8 h-8 mx-auto mb-2" />
                  <p
                    className="font-semibold text-lg"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Your order is ready!
                  </p>
                  <p
                    className="text-sm text-white/80 flex items-center justify-center gap-1 mt-1"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    <MapPin className="w-4 h-4" />
                    Pick up at the counter
                  </p>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
