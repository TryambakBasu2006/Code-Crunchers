import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Calendar,
  Clock,
  Package,
  X,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Edit3,
  Trash2,
} from 'lucide-react'
import {
  getScheduledOrdersFn,
  getAvailablePickupSlotsFn,
  cancelScheduledOrderFn,
  updateScheduledTimeFn,
  QUEUE_STATUSES,
} from '@/server/functions/scheduled-orders'
import type {
  ScheduledOrders as ScheduledOrderType,
  Orders,
} from '@/server/lib/appwrite.types'

interface ScheduledOrderWithDetails extends ScheduledOrderType {
  order?: Orders
}

// ============================================
// PICKUP TIME SELECTOR
// ============================================

interface PickupTimeSelectorProps {
  selectedTime: string | null
  onSelect: (time: string) => void
  onClose: () => void
}

export function PickupTimeSelector({
  selectedTime,
  onSelect,
  onClose,
}: PickupTimeSelectorProps) {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [slots, setSlots] = useState<
    Array<{
      time: string
      available: boolean
      ordersCount: number
      maxOrders: number
    }>
  >([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchSlots = async () => {
      setIsLoading(true)
      try {
        const result = await getAvailablePickupSlotsFn({
          data: { date: selectedDate.toISOString() },
        })
        setSlots(result.slots)
      } catch (error) {
        console.error('Failed to fetch slots:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchSlots()
  }, [selectedDate])

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate)
    newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1))

    // Don't allow past dates
    if (newDate < new Date()) return

    setSelectedDate(newDate)
  }

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const formatDate = (date: Date) => {
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    if (date.toDateString() === today.toDateString()) return 'Today'
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow'

    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    })
  }

  // Group slots by hour
  const groupedSlots: Record<number, typeof slots> = {}
  slots.forEach((slot) => {
    const hour = new Date(slot.time).getHours()
    if (!groupedSlots[hour]) groupedSlots[hour] = []
    groupedSlots[hour].push(slot)
  })

  return (
    <div className="bg-white rounded-2xl border border-[#2D3436]/5 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-[#2D3436]/5 bg-gradient-to-r from-[#3D5A80]/5 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-xl flex items-center justify-center">
              <Calendar className="w-5 h-5 text-[#3D5A80]" />
            </div>
            <div>
              <h3
                className="font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Select Pickup Time
              </h3>
              <p
                className="text-xs text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Choose when you'd like to pick up your order
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#2D3436]/60" />
          </button>
        </div>
      </div>

      {/* Date Navigation */}
      <div className="p-4 border-b border-[#2D3436]/5">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigateDate('prev')}
            disabled={selectedDate.toDateString() === new Date().toDateString()}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors disabled:opacity-30"
          >
            <ChevronLeft className="w-5 h-5 text-[#2D3436]/60" />
          </button>
          <span
            className="font-semibold text-[#2D3436]"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {formatDate(selectedDate)}
          </span>
          <button
            onClick={() => navigateDate('next')}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-[#2D3436]/60" />
          </button>
        </div>
      </div>

      {/* Time Slots */}
      <div className="p-4 max-h-[400px] overflow-y-auto">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-[#E07A5F] animate-spin" />
          </div>
        ) : slots.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-12 h-12 text-[#2D3436]/20 mx-auto mb-4" />
            <p
              className="text-[#2D3436]/50"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              No available slots for this date
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {Object.entries(groupedSlots).map(([hour, hourSlots]) => (
              <div key={hour}>
                <p
                  className="text-xs text-[#2D3436]/40 mb-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {parseInt(hour) < 12
                    ? `${hour} AM`
                    : parseInt(hour) === 12
                      ? '12 PM'
                      : `${parseInt(hour) - 12} PM`}
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {hourSlots.map((slot) => (
                    <motion.button
                      key={slot.time}
                      onClick={() => slot.available && onSelect(slot.time)}
                      disabled={!slot.available}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                        selectedTime === slot.time
                          ? 'bg-[#E07A5F] text-white'
                          : slot.available
                            ? 'bg-[#F5F5F5] text-[#2D3436] hover:bg-[#EBEBEB]'
                            : 'bg-[#F5F5F5] text-[#2D3436]/30 cursor-not-allowed'
                      }`}
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                      whileTap={slot.available ? { scale: 0.95 } : {}}
                    >
                      {formatTime(slot.time)}
                    </motion.button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Selected Time Confirmation */}
      {selectedTime && (
        <div className="p-4 border-t border-[#2D3436]/5 bg-[#81B29A]/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#81B29A]" />
              <span
                className="text-sm font-medium text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Pickup at {formatTime(selectedTime)}
              </span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#81B29A] text-white font-medium rounded-lg hover:bg-[#6A9A83] transition-colors"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Confirm
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================
// SCHEDULED ORDERS LIST
// ============================================

export function ScheduledOrdersList() {
  const [orders, setOrders] = useState<ScheduledOrderWithDetails[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [cancellingId, setCancellingId] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [newPickupTime, setNewPickupTime] = useState<string | null>(null)

  const fetchOrders = async () => {
    try {
      const result = await getScheduledOrdersFn({
        data: { upcoming: true, limit: 20 },
      })
      setOrders(result.scheduledOrders)
    } catch (error) {
      console.error('Failed to fetch scheduled orders:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    void fetchOrders()
  }, [])

  const handleCancel = async (scheduledOrderId: string) => {
    if (!confirm('Are you sure you want to cancel this scheduled order?'))
      return

    setCancellingId(scheduledOrderId)
    try {
      await cancelScheduledOrderFn({
        data: { scheduledOrderId, reason: 'Cancelled by user' },
      })
      void fetchOrders()
    } catch (error) {
      console.error('Failed to cancel order:', error)
      alert(
        'Failed to cancel order. It may have already been sent to the kitchen.',
      )
    } finally {
      setCancellingId(null)
    }
  }

  const handleUpdateTime = async (scheduledOrderId: string) => {
    if (!newPickupTime) return

    try {
      await updateScheduledTimeFn({
        data: { scheduledOrderId, newPickupTime },
      })
      setEditingId(null)
      setNewPickupTime(null)
      void fetchOrders()
    } catch (error) {
      console.error('Failed to update pickup time:', error)
      alert('Failed to update pickup time.')
    }
  }

  const formatDateTime = (isoString: string) => {
    const date = new Date(isoString)
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case QUEUE_STATUSES.SCHEDULED:
        return {
          label: 'Scheduled',
          color: '#3D5A80',
          bgColor: '#3D5A80/10',
          icon: <Calendar className="w-4 h-4" />,
        }
      case QUEUE_STATUSES.PENDING_RELEASE:
        return {
          label: 'Preparing Soon',
          color: '#F2CC8F',
          bgColor: '#F2CC8F/20',
          icon: <Clock className="w-4 h-4" />,
        }
      case QUEUE_STATUSES.RELEASED:
        return {
          label: 'In Kitchen',
          color: '#E07A5F',
          bgColor: '#E07A5F/10',
          icon: <Package className="w-4 h-4" />,
        }
      case QUEUE_STATUSES.CANCELLED:
        return {
          label: 'Cancelled',
          color: '#EF4444',
          bgColor: '#EF4444/10',
          icon: <XCircle className="w-4 h-4" />,
        }
      default:
        return {
          label: status,
          color: '#6B7280',
          bgColor: '#6B7280/10',
          icon: <AlertCircle className="w-4 h-4" />,
        }
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-[#E07A5F] animate-spin" />
      </div>
    )
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-2xl border border-[#2D3436]/5">
        <Calendar className="w-16 h-16 text-[#2D3436]/20 mx-auto mb-4" />
        <h3
          className="text-lg font-semibold text-[#2D3436] mb-2"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          No Scheduled Orders
        </h3>
        <p
          className="text-[#2D3436]/50"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          Pre-order your meals for later pickup
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h2
        className="text-lg font-semibold text-[#2D3436] flex items-center gap-2"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        <Calendar className="w-5 h-5 text-[#3D5A80]" />
        Scheduled Orders
      </h2>

      {orders.map((scheduled) => {
        const statusConfig = getStatusConfig(scheduled.queueStatus)
        const canModify = scheduled.queueStatus === QUEUE_STATUSES.SCHEDULED

        return (
          <motion.div
            key={scheduled.$id}
            layout
            className="bg-white rounded-xl border border-[#2D3436]/5 overflow-hidden"
          >
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span
                    className="text-sm font-bold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Order #{scheduled.orderId.slice(-6).toUpperCase()}
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className="px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                      style={{
                        backgroundColor: `${statusConfig.color}15`,
                        color: statusConfig.color,
                      }}
                    >
                      {statusConfig.icon}
                      {statusConfig.label}
                    </span>
                  </div>
                </div>
                {scheduled.order && (
                  <span
                    className="text-lg font-bold text-[#2D3436]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    ${scheduled.order.totalPrice.toFixed(2)}
                  </span>
                )}
              </div>

              {/* Pickup Time */}
              <div className="flex items-center gap-2 p-3 bg-[#F5F5F5] rounded-xl mb-3">
                <Clock className="w-4 h-4 text-[#2D3436]/60" />
                <span
                  className="text-sm text-[#2D3436]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Pickup: {formatDateTime(scheduled.scheduledPickupTime)}
                </span>
              </div>

              {/* Actions */}
              {canModify && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setEditingId(scheduled.$id)}
                    className="flex-1 py-2 bg-[#3D5A80]/10 text-[#3D5A80] font-medium rounded-lg hover:bg-[#3D5A80]/20 transition-colors text-sm flex items-center justify-center gap-2"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    <Edit3 className="w-4 h-4" />
                    Change Time
                  </button>
                  <button
                    onClick={() => handleCancel(scheduled.$id)}
                    disabled={cancellingId === scheduled.$id}
                    className="flex-1 py-2 bg-[#EF4444]/10 text-[#EF4444] font-medium rounded-lg hover:bg-[#EF4444]/20 transition-colors text-sm flex items-center justify-center gap-2 disabled:opacity-50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {cancellingId === scheduled.$id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    Cancel
                  </button>
                </div>
              )}
            </div>

            {/* Edit Time Modal */}
            <AnimatePresence>
              {editingId === scheduled.$id && (
                <>
                  <motion.div
                    className="fixed inset-0 bg-black/50 z-50"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => {
                      setEditingId(null)
                      setNewPickupTime(null)
                    }}
                  />
                  <motion.div
                    className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md z-50"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                  >
                    <PickupTimeSelector
                      selectedTime={newPickupTime}
                      onSelect={(time) => {
                        setNewPickupTime(time)
                        void handleUpdateTime(scheduled.$id)
                      }}
                      onClose={() => {
                        setEditingId(null)
                        setNewPickupTime(null)
                      }}
                    />
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </motion.div>
        )
      })}
    </div>
  )
}

// ============================================
// SCHEDULE ORDER BUTTON
// ============================================

interface ScheduleOrderButtonProps {
  onSchedule: (pickupTime: string) => void
  disabled?: boolean
}

export function ScheduleOrderButton({
  onSchedule,
  disabled,
}: ScheduleOrderButtonProps) {
  const [showPicker, setShowPicker] = useState(false)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)

  const handleSelect = (time: string) => {
    setSelectedTime(time)
  }

  const handleConfirm = () => {
    if (selectedTime) {
      onSchedule(selectedTime)
      setShowPicker(false)
      setSelectedTime(null)
    }
  }

  return (
    <>
      <motion.button
        onClick={() => setShowPicker(true)}
        disabled={disabled}
        className="flex items-center gap-2 px-4 py-2 bg-[#3D5A80]/10 text-[#3D5A80] font-medium rounded-xl hover:bg-[#3D5A80]/20 transition-colors disabled:opacity-50"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
        whileTap={{ scale: 0.95 }}
      >
        <Calendar className="w-4 h-4" />
        Schedule for Later
      </motion.button>

      <AnimatePresence>
        {showPicker && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowPicker(false)
                setSelectedTime(null)
              }}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md z-50"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <PickupTimeSelector
                selectedTime={selectedTime}
                onSelect={handleSelect}
                onClose={() => {
                  if (selectedTime) {
                    handleConfirm()
                  } else {
                    setShowPicker(false)
                  }
                }}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
