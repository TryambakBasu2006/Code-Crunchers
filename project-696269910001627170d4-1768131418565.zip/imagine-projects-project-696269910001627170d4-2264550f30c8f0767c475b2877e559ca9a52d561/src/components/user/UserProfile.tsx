import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  User,
  Phone,
  Bell,
  Mail,
  MessageSquare,
  MapPin,
  Shield,
  Download,
  Trash2,
  Save,
  Check,
  Loader2,
  AlertTriangle,
  ChevronRight,
} from 'lucide-react'
import {
  getUserProfileFn,
  updateUserProfileFn,
  recordGdprConsentFn,
  exportUserDataFn,
  deleteUserDataFn,
} from '@/server/functions/user-profiles'
import type { UserProfiles } from '@/server/lib/appwrite.types'

export function UserProfile() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [profile, setProfile] = useState<UserProfiles | null>(null)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [deleteEmail, setDeleteEmail] = useState('')
  const [isDeleting, setIsDeleting] = useState(false)
  const [isExporting, setIsExporting] = useState(false)

  const [formData, setFormData] = useState({
    displayName: '',
    phoneNumber: '',
    preferredPickupLocation: '',
    notifyByPush: true,
    notifyBySms: false,
    notifyByEmail: true,
  })

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const result = await getUserProfileFn()
        if (result.profile) {
          setProfile(result.profile)
          setFormData({
            displayName: result.profile.displayName || '',
            phoneNumber: result.profile.phoneNumber || '',
            preferredPickupLocation:
              result.profile.preferredPickupLocation || '',
            notifyByPush: result.profile.notifyByPush,
            notifyBySms: result.profile.notifyBySms,
            notifyByEmail: result.profile.notifyByEmail,
          })
        }
      } catch (error) {
        console.error('Failed to fetch profile:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchProfile()
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    setSaveSuccess(false)
    try {
      await updateUserProfileFn({ data: formData })
      setSaveSuccess(true)
      setTimeout(() => setSaveSuccess(false), 3000)
    } catch (error) {
      console.error('Failed to save profile:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleExportData = async () => {
    setIsExporting(true)
    try {
      const result = await exportUserDataFn()
      // Download as JSON file
      const blob = new Blob([JSON.stringify(result.data, null, 2)], {
        type: 'application/json',
      })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `canteen-companion-data-${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Failed to export data:', error)
    } finally {
      setIsExporting(false)
    }
  }

  const handleDeleteAccount = async () => {
    setIsDeleting(true)
    try {
      await deleteUserDataFn({ data: { confirmEmail: deleteEmail } })
      // Redirect to home after deletion
      window.location.href = '/'
    } catch (error) {
      console.error('Failed to delete account:', error)
      alert('Failed to delete account. Please verify your email address.')
    } finally {
      setIsDeleting(false)
    }
  }

  const handleGdprConsent = async () => {
    try {
      await recordGdprConsentFn({
        data: { gdprConsent: true, marketingConsent: false },
      })
    } catch (error) {
      console.error('Failed to record consent:', error)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <User className="w-8 h-8 text-[#E07A5F]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1
          className="text-2xl md:text-3xl font-bold text-[#2D3436] mb-2"
          style={{ fontFamily: 'Fraunces, serif' }}
        >
          Account Settings
        </h1>
        <p
          className="text-[#2D3436]/60"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          Manage your profile, notifications, and privacy settings.
        </p>
      </div>

      <div className="space-y-6">
        {/* Profile Information */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#E07A5F]/10 rounded-xl flex items-center justify-center">
              <User className="w-5 h-5 text-[#E07A5F]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Profile Information
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Your personal details
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label
                className="block text-sm font-medium text-[#2D3436] mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Display Name
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                <input
                  type="text"
                  value={formData.displayName}
                  onChange={(e) =>
                    setFormData({ ...formData, displayName: e.target.value })
                  }
                  placeholder="Your name"
                  className="w-full pl-12 pr-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>
            </div>

            <div>
              <label
                className="block text-sm font-medium text-[#2D3436] mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Phone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) =>
                    setFormData({ ...formData, phoneNumber: e.target.value })
                  }
                  placeholder="+1 (555) 123-4567"
                  className="w-full pl-12 pr-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>
            </div>

            <div>
              <label
                className="block text-sm font-medium text-[#2D3436] mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Preferred Pickup Location
              </label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D3436]/40" />
                <input
                  type="text"
                  value={formData.preferredPickupLocation}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      preferredPickupLocation: e.target.value,
                    })
                  }
                  placeholder="e.g., Main Cafeteria, Building A"
                  className="w-full pl-12 pr-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Notification Preferences */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#81B29A]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Notification Preferences
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                How would you like to be notified?
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <NotificationToggle
              icon={<Bell className="w-4 h-4" />}
              label="Push Notifications"
              description="Get instant alerts on your device"
              checked={formData.notifyByPush}
              onChange={(checked) =>
                setFormData({ ...formData, notifyByPush: checked })
              }
            />
            <NotificationToggle
              icon={<Mail className="w-4 h-4" />}
              label="Email Notifications"
              description="Receive order updates via email"
              checked={formData.notifyByEmail}
              onChange={(checked) =>
                setFormData({ ...formData, notifyByEmail: checked })
              }
            />
            <NotificationToggle
              icon={<MessageSquare className="w-4 h-4" />}
              label="SMS Notifications"
              description="Get text messages for order status"
              checked={formData.notifyBySms}
              onChange={(checked) =>
                setFormData({ ...formData, notifyBySms: checked })
              }
            />
          </div>
        </section>

        {/* Privacy & Data */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-[#3D5A80]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Privacy & Data
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Manage your data and privacy settings
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {/* GDPR Consent Status */}
            <div className="flex items-center justify-between p-4 bg-[#F5F5F5] rounded-xl">
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-[#81B29A]" />
                <div>
                  <span
                    className="text-sm font-medium text-[#2D3436] block"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Data Processing Consent
                  </span>
                  <span
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {profile?.gdprConsentAt
                      ? `Consented on ${new Date(profile.gdprConsentAt).toLocaleDateString()}`
                      : 'Not yet recorded'}
                  </span>
                </div>
              </div>
              {!profile?.gdprConsentAt && (
                <button
                  onClick={() => void handleGdprConsent()}
                  className="px-4 py-2 bg-[#81B29A] text-white text-sm font-medium rounded-lg hover:bg-[#6A9A83] transition-colors"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Accept
                </button>
              )}
            </div>

            {/* Export Data */}
            <button
              onClick={handleExportData}
              disabled={isExporting}
              className="w-full flex items-center justify-between p-4 bg-[#F5F5F5] rounded-xl hover:bg-[#EBEBEB] transition-colors disabled:opacity-50"
            >
              <div className="flex items-center gap-3">
                <Download className="w-5 h-5 text-[#3D5A80]" />
                <div className="text-left">
                  <span
                    className="text-sm font-medium text-[#2D3436] block"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Export My Data
                  </span>
                  <span
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Download all your data as JSON
                  </span>
                </div>
              </div>
              {isExporting ? (
                <Loader2 className="w-5 h-5 text-[#2D3436]/40 animate-spin" />
              ) : (
                <ChevronRight className="w-5 h-5 text-[#2D3436]/40" />
              )}
            </button>

            {/* Delete Account */}
            <button
              onClick={() => setShowDeleteModal(true)}
              className="w-full flex items-center justify-between p-4 bg-[#FEE2E2] rounded-xl hover:bg-[#FECACA] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Trash2 className="w-5 h-5 text-[#EF4444]" />
                <div className="text-left">
                  <span
                    className="text-sm font-medium text-[#EF4444] block"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Delete My Account
                  </span>
                  <span
                    className="text-xs text-[#EF4444]/70"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Permanently delete all your data
                  </span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#EF4444]/40" />
            </button>
          </div>
        </section>

        {/* Save Button */}
        <motion.button
          onClick={handleSave}
          disabled={isSaving}
          className={`
                        w-full flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all
                        ${
                          saveSuccess
                            ? 'bg-[#81B29A] text-white'
                            : 'bg-[#2D3436] text-white hover:bg-[#1a1f20]'
                        }
                    `}
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          whileTap={{ scale: 0.98 }}
        >
          {isSaving ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Saving...
            </>
          ) : saveSuccess ? (
            <>
              <Check className="w-5 h-5" />
              Settings Saved!
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              Save Changes
            </>
          )}
        </motion.button>
      </div>

      {/* Delete Account Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDeleteModal(false)}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md bg-white rounded-2xl z-50 overflow-hidden"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-[#FEE2E2] rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-[#EF4444]" />
                  </div>
                  <div>
                    <h3
                      className="text-lg font-bold text-[#2D3436]"
                      style={{ fontFamily: 'Fraunces, serif' }}
                    >
                      Delete Account
                    </h3>
                    <p
                      className="text-sm text-[#2D3436]/60"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      This action cannot be undone
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-[#FEF3C7] rounded-xl mb-4">
                  <p
                    className="text-sm text-[#92400E]"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    ⚠️ All your data will be permanently deleted, including:
                  </p>
                  <ul
                    className="text-sm text-[#92400E] mt-2 ml-4 list-disc"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    <li>Order history</li>
                    <li>Dietary preferences</li>
                    <li>Favorites and reviews</li>
                    <li>Payment information</li>
                  </ul>
                </div>

                <div className="mb-4">
                  <label
                    className="block text-sm font-medium text-[#2D3436] mb-2"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Type your email to confirm
                  </label>
                  <input
                    type="email"
                    value={deleteEmail}
                    onChange={(e) => setDeleteEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#EF4444]/30"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteModal(false)}
                    className="flex-1 py-3 bg-[#F5F5F5] text-[#2D3436] font-medium rounded-xl hover:bg-[#EBEBEB] transition-colors"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={isDeleting || !deleteEmail}
                    className="flex-1 py-3 bg-[#EF4444] text-white font-medium rounded-xl hover:bg-[#DC2626] transition-colors disabled:opacity-50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {isDeleting ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Deleting...
                      </span>
                    ) : (
                      'Delete Account'
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

function NotificationToggle({
  icon,
  label,
  description,
  checked,
  onChange,
}: {
  icon: React.ReactNode
  label: string
  description: string
  checked: boolean
  onChange: (checked: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between p-4 bg-[#F5F5F5] rounded-xl">
      <div className="flex items-center gap-3">
        <span className="text-[#2D3436]/60">{icon}</span>
        <div>
          <span
            className="text-sm font-medium text-[#2D3436] block"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {label}
          </span>
          <span
            className="text-xs text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {description}
          </span>
        </div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`w-12 h-6 rounded-full transition-colors ${
          checked ? 'bg-[#81B29A]' : 'bg-[#2D3436]/20'
        }`}
      >
        <motion.div
          className="w-5 h-5 bg-white rounded-full shadow"
          animate={{ x: checked ? 26 : 2 }}
        />
      </button>
    </div>
  )
}
