import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Palette,
  Beef,
  Clock,
  DollarSign,
  Save,
  Check,
  Loader2,
  Sparkles,
  Globe,
  ThermometerSun,
  Ban,
  Utensils,
  Brain,
  RefreshCw,
} from 'lucide-react'
import {
  getUserTasteProfileFn,
  updateUserTasteProfileFn,
  calculateUserSimilaritiesFn,
} from '@/server/functions'

const cuisineOptions = [
  { id: 'italian', label: 'Italian', emoji: '🇮🇹' },
  { id: 'mexican', label: 'Mexican', emoji: '🇲🇽' },
  { id: 'japanese', label: 'Japanese', emoji: '🇯🇵' },
  { id: 'chinese', label: 'Chinese', emoji: '🇨🇳' },
  { id: 'indian', label: 'Indian', emoji: '🇮🇳' },
  { id: 'thai', label: 'Thai', emoji: '🇹🇭' },
  { id: 'mediterranean', label: 'Mediterranean', emoji: '🫒' },
  { id: 'american', label: 'American', emoji: '🇺🇸' },
  { id: 'korean', label: 'Korean', emoji: '🇰🇷' },
  { id: 'vietnamese', label: 'Vietnamese', emoji: '🇻🇳' },
  { id: 'french', label: 'French', emoji: '🇫🇷' },
  { id: 'greek', label: 'Greek', emoji: '🇬🇷' },
]

const flavorOptions = [
  {
    id: 'savory',
    label: 'Savory',
    icon: '🧂',
    description: 'Rich, umami flavors',
  },
  {
    id: 'sweet',
    label: 'Sweet',
    icon: '🍯',
    description: 'Desserts & sweet dishes',
  },
  { id: 'spicy', label: 'Spicy', icon: '🌶️', description: 'Heat lovers' },
  {
    id: 'tangy',
    label: 'Tangy',
    icon: '🍋',
    description: 'Citrus & vinegar notes',
  },
  { id: 'smoky', label: 'Smoky', icon: '🔥', description: 'Grilled & charred' },
  { id: 'fresh', label: 'Fresh', icon: '🥗', description: 'Light & crisp' },
  { id: 'creamy', label: 'Creamy', icon: '🥛', description: 'Rich & smooth' },
  { id: 'herby', label: 'Herby', icon: '🌿', description: 'Aromatic herbs' },
]

const proteinOptions = [
  { id: 'chicken', label: 'Chicken', emoji: '🍗' },
  { id: 'beef', label: 'Beef', emoji: '🥩' },
  { id: 'pork', label: 'Pork', emoji: '🥓' },
  { id: 'fish', label: 'Fish', emoji: '🐟' },
  { id: 'shrimp', label: 'Shrimp', emoji: '🦐' },
  { id: 'tofu', label: 'Tofu', emoji: '🧈' },
  { id: 'eggs', label: 'Eggs', emoji: '🥚' },
  { id: 'lamb', label: 'Lamb', emoji: '🐑' },
]

const mealTimeOptions = [
  { id: 'breakfast', label: 'Breakfast', icon: '☀️', time: '6-10 AM' },
  { id: 'brunch', label: 'Brunch', icon: '🥞', time: '10-12 PM' },
  { id: 'lunch', label: 'Lunch', icon: '🍽️', time: '12-2 PM' },
  { id: 'afternoon', label: 'Afternoon', icon: '☕', time: '2-5 PM' },
  { id: 'dinner', label: 'Dinner', icon: '🌙', time: '5-9 PM' },
  { id: 'late-night', label: 'Late Night', icon: '🌃', time: '9 PM+' },
]

const portionOptions = [
  { id: 'small', label: 'Light', description: 'Smaller portions', icon: '🥗' },
  { id: 'regular', label: 'Regular', description: 'Standard size', icon: '🍽️' },
  { id: 'large', label: 'Hearty', description: 'Larger portions', icon: '🍖' },
]

const budgetOptions = [
  { id: 'budget', label: 'Budget', description: 'Under $10', icon: '💰' },
  { id: 'moderate', label: 'Moderate', description: '$10-20', icon: '💵' },
  { id: 'premium', label: 'Premium', description: '$20+', icon: '💎' },
]

export function TasteProfile() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isCalculatingSimilarities, setIsCalculatingSimilarities] =
    useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [similarityMessage, setSimilarityMessage] = useState<string | null>(
    null,
  )

  const [profile, setProfile] = useState({
    preferredCuisines: [] as string[],
    avoidedCuisines: [] as string[],
    flavorPreferences: [] as string[],
    spiceTolerance: 2,
    preferredProteins: [] as string[],
    avoidedIngredients: [] as string[],
    preferredMealTimes: [] as string[],
    preferredPortionSize: 'regular' as 'small' | 'regular' | 'large',
    budgetPreference: 'moderate' as 'budget' | 'moderate' | 'premium',
  })

  const [avoidedIngredientInput, setAvoidedIngredientInput] = useState('')
  const [, setActiveSection] = useState<string | null>(null)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const result = await getUserTasteProfileFn()
        if (result.profile) {
          setProfile({
            preferredCuisines: result.profile.preferredCuisines || [],
            avoidedCuisines: result.profile.avoidedCuisines || [],
            flavorPreferences: result.profile.flavorPreferences || [],
            spiceTolerance: result.profile.spiceTolerance ?? 2,
            preferredProteins: result.profile.preferredProteins || [],
            avoidedIngredients: result.profile.avoidedIngredients || [],
            preferredMealTimes: result.profile.preferredMealTimes || [],
            preferredPortionSize:
              (result.profile.preferredPortionSize as
                | 'small'
                | 'regular'
                | 'large') || 'regular',
            budgetPreference:
              (result.profile.budgetPreference as
                | 'budget'
                | 'moderate'
                | 'premium') || 'moderate',
          })
        }
      } catch (error) {
        console.error('Failed to fetch taste profile:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchProfile()
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    setSaveSuccess(false)
    try {
      await updateUserTasteProfileFn({
        data: {
          preferredCuisines:
            profile.preferredCuisines.length > 0
              ? profile.preferredCuisines
              : undefined,
          avoidedCuisines:
            profile.avoidedCuisines.length > 0
              ? profile.avoidedCuisines
              : undefined,
          flavorPreferences:
            profile.flavorPreferences.length > 0
              ? profile.flavorPreferences
              : undefined,
          spiceTolerance: profile.spiceTolerance,
          preferredProteins:
            profile.preferredProteins.length > 0
              ? profile.preferredProteins
              : undefined,
          avoidedIngredients:
            profile.avoidedIngredients.length > 0
              ? profile.avoidedIngredients
              : undefined,
          preferredMealTimes:
            profile.preferredMealTimes.length > 0
              ? profile.preferredMealTimes
              : undefined,
          preferredPortionSize: profile.preferredPortionSize,
          budgetPreference: profile.budgetPreference,
        },
      })
      setSaveSuccess(true)
      setTimeout(() => setSaveSuccess(false), 3000)
    } catch (error) {
      console.error('Failed to save taste profile:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleCalculateSimilarities = async () => {
    setIsCalculatingSimilarities(true)
    setSimilarityMessage(null)
    try {
      const result = await calculateUserSimilaritiesFn()
      setSimilarityMessage(result.message)
      setTimeout(() => setSimilarityMessage(null), 5000)
    } catch (error) {
      console.error('Failed to calculate similarities:', error)
      setSimilarityMessage('Failed to calculate similarities')
    } finally {
      setIsCalculatingSimilarities(false)
    }
  }

  const toggleItem = (
    category:
      | 'preferredCuisines'
      | 'avoidedCuisines'
      | 'flavorPreferences'
      | 'preferredProteins'
      | 'preferredMealTimes',
    itemId: string,
  ) => {
    setProfile((prev) => ({
      ...prev,
      [category]: prev[category].includes(itemId)
        ? prev[category].filter((id) => id !== itemId)
        : [...prev[category], itemId],
    }))
  }

  const addAvoidedIngredient = () => {
    if (
      avoidedIngredientInput.trim() &&
      !profile.avoidedIngredients.includes(avoidedIngredientInput.trim())
    ) {
      setProfile((prev) => ({
        ...prev,
        avoidedIngredients: [
          ...prev.avoidedIngredients,
          avoidedIngredientInput.trim(),
        ],
      }))
      setAvoidedIngredientInput('')
    }
  }

  const removeAvoidedIngredient = (item: string) => {
    setProfile((prev) => ({
      ...prev,
      avoidedIngredients: prev.avoidedIngredients.filter((i) => i !== item),
    }))
  }

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Brain className="w-8 h-8 text-[#81B29A]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#81B29A] to-[#3D5A80] rounded-xl flex items-center justify-center shadow-lg shadow-[#81B29A]/20">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1
              className="text-2xl md:text-3xl font-bold text-[#2D3436]"
              style={{ fontFamily: 'Fraunces, serif' }}
            >
              Your Taste Profile
            </h1>
            <p
              className="text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Help our AI understand your unique palate
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Preferred Cuisines */}
        <motion.section
          className="bg-white rounded-2xl p-6 border border-[#2D3436]/5 hover:border-[#81B29A]/20 transition-colors"
          onHoverStart={() => setActiveSection('cuisines')}
          onHoverEnd={() => setActiveSection(null)}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
              <Globe className="w-5 h-5 text-[#81B29A]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Favorite Cuisines
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                What flavors of the world do you love?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
            {cuisineOptions.map((cuisine) => (
              <motion.button
                key={cuisine.id}
                onClick={() => toggleItem('preferredCuisines', cuisine.id)}
                className={`
                                    flex items-center gap-2 px-3 py-2.5 rounded-xl transition-all border-2
                                    ${
                                      profile.preferredCuisines.includes(
                                        cuisine.id,
                                      )
                                        ? 'border-[#81B29A] bg-[#81B29A]/5'
                                        : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                    }
                                `}
                whileTap={{ scale: 0.95 }}
              >
                <span className="text-lg">{cuisine.emoji}</span>
                <span
                  className="text-sm font-medium text-[#2D3436]"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {cuisine.label}
                </span>
                {profile.preferredCuisines.includes(cuisine.id) && (
                  <Check className="w-4 h-4 text-[#81B29A] ml-auto" />
                )}
              </motion.button>
            ))}
          </div>
        </motion.section>

        {/* Flavor Preferences */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#F2CC8F]/20 rounded-xl flex items-center justify-center">
              <Palette className="w-5 h-5 text-[#D4A84B]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Flavor Profile
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                What taste sensations do you crave?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {flavorOptions.map((flavor) => (
              <motion.button
                key={flavor.id}
                onClick={() => toggleItem('flavorPreferences', flavor.id)}
                className={`
                                    relative p-3 rounded-xl text-left transition-all border-2
                                    ${
                                      profile.flavorPreferences.includes(
                                        flavor.id,
                                      )
                                        ? 'border-[#F2CC8F] bg-[#F2CC8F]/10'
                                        : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                    }
                                `}
                whileTap={{ scale: 0.95 }}
              >
                {profile.flavorPreferences.includes(flavor.id) && (
                  <div className="absolute top-2 right-2 w-5 h-5 bg-[#F2CC8F] rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
                <span className="text-2xl block mb-1">{flavor.icon}</span>
                <span
                  className="text-sm font-medium text-[#2D3436] block"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {flavor.label}
                </span>
                <span
                  className="text-[10px] text-[#2D3436]/50 block"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {flavor.description}
                </span>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Spice Tolerance */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#E07A5F]/10 rounded-xl flex items-center justify-center">
              <ThermometerSun className="w-5 h-5 text-[#E07A5F]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Spice Tolerance
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                How much heat can you handle?
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-2xl">🧊</span>
            <div className="flex-1 relative">
              <input
                type="range"
                min="0"
                max="5"
                value={profile.spiceTolerance}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    spiceTolerance: parseInt(e.target.value),
                  })
                }
                className="w-full h-2 bg-gradient-to-r from-[#81B29A] via-[#F2CC8F] to-[#E07A5F] rounded-full appearance-none cursor-pointer"
                style={{
                  WebkitAppearance: 'none',
                }}
              />
              <div className="flex justify-between mt-2 text-xs text-[#2D3436]/50">
                <span>Mild</span>
                <span>Medium</span>
                <span>Hot</span>
                <span>🔥 Extreme</span>
              </div>
            </div>
            <span className="text-2xl">🌶️</span>
          </div>

          <div className="mt-4 text-center">
            <span
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#F5F5F5] rounded-full text-sm font-medium text-[#2D3436]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {
                [
                  '🧊 No spice',
                  '🌿 Mild',
                  '🌶️ Medium',
                  '🔥 Hot',
                  '💥 Very Hot',
                  '☠️ Extreme',
                ][profile.spiceTolerance]
              }
            </span>
          </div>
        </section>

        {/* Preferred Proteins */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-xl flex items-center justify-center">
              <Beef className="w-5 h-5 text-[#3D5A80]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Preferred Proteins
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                What proteins do you enjoy most?
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {proteinOptions.map((protein) => (
              <motion.button
                key={protein.id}
                onClick={() => toggleItem('preferredProteins', protein.id)}
                className={`
                                    flex items-center gap-2 px-4 py-2 rounded-full transition-all
                                    ${
                                      profile.preferredProteins.includes(
                                        protein.id,
                                      )
                                        ? 'bg-[#3D5A80] text-white'
                                        : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB]'
                                    }
                                `}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <span>{protein.emoji}</span>
                <span className="text-sm font-medium">{protein.label}</span>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Avoided Ingredients */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#E07A5F]/10 rounded-xl flex items-center justify-center">
              <Ban className="w-5 h-5 text-[#E07A5F]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Ingredients to Avoid
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                We'll filter these out of recommendations
              </p>
            </div>
          </div>

          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={avoidedIngredientInput}
              onChange={(e) => setAvoidedIngredientInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addAvoidedIngredient()}
              placeholder="e.g., cilantro, olives, blue cheese..."
              className="flex-1 px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />
            <motion.button
              onClick={addAvoidedIngredient}
              className="px-4 py-2 bg-[#E07A5F] text-white rounded-xl text-sm font-medium"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              whileTap={{ scale: 0.95 }}
            >
              Add
            </motion.button>
          </div>

          {profile.avoidedIngredients.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {profile.avoidedIngredients.map((item) => (
                <span
                  key={item}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#E07A5F]/10 text-[#E07A5F] rounded-full text-sm"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {item}
                  <button
                    onClick={() => removeAvoidedIngredient(item)}
                    className="ml-1 hover:text-[#c4614a]"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </section>

        {/* Meal Times */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
              <Clock className="w-5 h-5 text-[#81B29A]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Preferred Meal Times
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                When do you usually order?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {mealTimeOptions.map((time) => (
              <motion.button
                key={time.id}
                onClick={() => toggleItem('preferredMealTimes', time.id)}
                className={`
                                    flex items-center gap-3 p-3 rounded-xl transition-all border-2
                                    ${
                                      profile.preferredMealTimes.includes(
                                        time.id,
                                      )
                                        ? 'border-[#81B29A] bg-[#81B29A]/5'
                                        : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                    }
                                `}
                whileTap={{ scale: 0.95 }}
              >
                <span className="text-xl">{time.icon}</span>
                <div className="text-left">
                  <span
                    className="text-sm font-medium text-[#2D3436] block"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {time.label}
                  </span>
                  <span
                    className="text-xs text-[#2D3436]/50"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    {time.time}
                  </span>
                </div>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Portion Size & Budget */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Portion Size */}
          <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-[#F2CC8F]/20 rounded-xl flex items-center justify-center">
                <Utensils className="w-5 h-5 text-[#D4A84B]" />
              </div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Portion Size
              </h2>
            </div>

            <div className="space-y-2">
              {portionOptions.map((option) => (
                <motion.button
                  key={option.id}
                  onClick={() =>
                    setProfile({
                      ...profile,
                      preferredPortionSize: option.id as
                        | 'small'
                        | 'regular'
                        | 'large',
                    })
                  }
                  className={`
                                        w-full flex items-center gap-3 p-3 rounded-xl transition-all border-2
                                        ${
                                          profile.preferredPortionSize ===
                                          option.id
                                            ? 'border-[#F2CC8F] bg-[#F2CC8F]/10'
                                            : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                        }
                                    `}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="text-xl">{option.icon}</span>
                  <div className="text-left">
                    <span
                      className="text-sm font-medium text-[#2D3436] block"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {option.label}
                    </span>
                    <span
                      className="text-xs text-[#2D3436]/50"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {option.description}
                    </span>
                  </div>
                  {profile.preferredPortionSize === option.id && (
                    <Check className="w-5 h-5 text-[#F2CC8F] ml-auto" />
                  )}
                </motion.button>
              ))}
            </div>
          </section>

          {/* Budget */}
          <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-[#81B29A]" />
              </div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Budget Preference
              </h2>
            </div>

            <div className="space-y-2">
              {budgetOptions.map((option) => (
                <motion.button
                  key={option.id}
                  onClick={() =>
                    setProfile({
                      ...profile,
                      budgetPreference: option.id as
                        | 'budget'
                        | 'moderate'
                        | 'premium',
                    })
                  }
                  className={`
                                        w-full flex items-center gap-3 p-3 rounded-xl transition-all border-2
                                        ${
                                          profile.budgetPreference === option.id
                                            ? 'border-[#81B29A] bg-[#81B29A]/5'
                                            : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                        }
                                    `}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="text-xl">{option.icon}</span>
                  <div className="text-left">
                    <span
                      className="text-sm font-medium text-[#2D3436] block"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {option.label}
                    </span>
                    <span
                      className="text-xs text-[#2D3436]/50"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {option.description}
                    </span>
                  </div>
                  {profile.budgetPreference === option.id && (
                    <Check className="w-5 h-5 text-[#81B29A] ml-auto" />
                  )}
                </motion.button>
              ))}
            </div>
          </section>
        </div>

        {/* AI Similarity Calculation */}
        <section className="bg-gradient-to-r from-[#81B29A]/10 to-[#3D5A80]/10 rounded-2xl p-6 border border-[#81B29A]/20">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#81B29A] to-[#3D5A80] rounded-xl flex items-center justify-center flex-shrink-0">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3
                className="text-lg font-semibold text-[#2D3436] mb-1"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Collaborative Filtering
              </h3>
              <p
                className="text-sm text-[#2D3436]/60 mb-4"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Find users with similar tastes to get better recommendations.
                This analyzes your order history to find "taste twins" who enjoy
                the same meals.
              </p>

              <motion.button
                onClick={handleCalculateSimilarities}
                disabled={isCalculatingSimilarities}
                className="flex items-center gap-2 px-4 py-2 bg-[#3D5A80] text-white rounded-xl text-sm font-medium disabled:opacity-50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.98 }}
              >
                {isCalculatingSimilarities ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    Find Similar Users
                  </>
                )}
              </motion.button>

              <AnimatePresence>
                {similarityMessage && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-3 text-sm text-[#81B29A] font-medium"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    ✓ {similarityMessage}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>

        {/* Save Button */}
        <motion.button
          onClick={handleSave}
          disabled={isSaving}
          className={`
                        w-full flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all
                        ${
                          saveSuccess
                            ? 'bg-[#81B29A] text-white'
                            : 'bg-[#2D3436] text-white hover:bg-[#1a1f20]'
                        }
                    `}
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          whileTap={{ scale: 0.98 }}
        >
          {isSaving ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Saving...
            </>
          ) : saveSuccess ? (
            <>
              <Check className="w-5 h-5" />
              Taste Profile Saved!
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              Save Taste Profile
            </>
          )}
        </motion.button>

        {/* AI Note */}
        <div className="p-4 bg-gradient-to-r from-[#81B29A]/10 to-[#3D5A80]/10 rounded-xl flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-[#81B29A] mt-0.5 flex-shrink-0" />
          <div>
            <p
              className="text-sm font-medium text-[#2D3436] mb-1"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Hybrid AI Recommendations
            </p>
            <p
              className="text-sm text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Your taste profile powers our hybrid recommendation engine,
              combining what you like (content-based) with what similar users
              enjoy (collaborative filtering) for the best suggestions.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
