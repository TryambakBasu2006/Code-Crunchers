import { useState, useEffect } from 'react'
import { motion } from 'motion/react'
import {
  Leaf,
  AlertTriangle,
  Target,
  Heart,
  ThumbsDown,
  Save,
  Check,
  Loader2,
  Sparkles,
  Info,
} from 'lucide-react'
import {
  getDietaryProfileFn,
  saveDietaryProfileFn,
} from '@/server/functions/recommendations'

const dietaryRestrictionOptions = [
  {
    id: 'vegetarian',
    label: 'Vegetarian',
    icon: '🥬',
    description: 'No meat or fish',
  },
  {
    id: 'vegan',
    label: 'Vegan',
    icon: '🌱',
    description: 'No animal products',
  },
  {
    id: 'pescatarian',
    label: 'Pescatarian',
    icon: '🐟',
    description: 'Fish but no meat',
  },
  { id: 'keto', label: 'Keto', icon: '🥑', description: 'Low carb, high fat' },
  { id: 'paleo', label: 'Paleo', icon: '🍖', description: 'Whole foods only' },
  {
    id: 'halal',
    label: 'Halal',
    icon: '☪️',
    description: 'Islamic dietary laws',
  },
  {
    id: 'kosher',
    label: 'Kosher',
    icon: '✡️',
    description: 'Jewish dietary laws',
  },
  {
    id: 'low-sodium',
    label: 'Low Sodium',
    icon: '🧂',
    description: 'Reduced salt',
  },
]

const allergenOptions = [
  { id: 'gluten', label: 'Gluten', icon: '🌾' },
  { id: 'dairy', label: 'Dairy', icon: '🥛' },
  { id: 'eggs', label: 'Eggs', icon: '🥚' },
  { id: 'nuts', label: 'Tree Nuts', icon: '🥜' },
  { id: 'peanuts', label: 'Peanuts', icon: '🥜' },
  { id: 'soy', label: 'Soy', icon: '🫘' },
  { id: 'fish', label: 'Fish', icon: '🐟' },
  { id: 'shellfish', label: 'Shellfish', icon: '🦐' },
  { id: 'sesame', label: 'Sesame', icon: '🌰' },
]

const preferenceOptions = [
  { id: 'high-protein', label: 'High Protein', icon: '💪' },
  { id: 'low-calorie', label: 'Low Calorie', icon: '🔥' },
  { id: 'organic', label: 'Organic', icon: '🌿' },
  { id: 'locally-sourced', label: 'Locally Sourced', icon: '📍' },
  { id: 'spicy', label: 'Spicy Food', icon: '🌶️' },
  { id: 'comfort-food', label: 'Comfort Food', icon: '🍲' },
  { id: 'quick-meals', label: 'Quick Meals', icon: '⚡' },
  { id: 'budget-friendly', label: 'Budget Friendly', icon: '💰' },
]

export function DietaryPreferences() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)

  const [profile, setProfile] = useState({
    dietaryRestrictions: [] as string[],
    allergens: [] as string[],
    dislikes: [] as string[],
    preferences: [] as string[],
    calorieGoal: null as number | null,
    proteinGoal: null as number | null,
  })

  const [dislikeInput, setDislikeInput] = useState('')

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const result = await getDietaryProfileFn()
        if (result.profile) {
          setProfile({
            dietaryRestrictions: result.profile.dietaryRestrictions || [],
            allergens: result.profile.allergens || [],
            dislikes: result.profile.dislikes || [],
            preferences: result.profile.preferences || [],
            calorieGoal: result.profile.calorieGoal,
            proteinGoal: result.profile.proteinGoal,
          })
        }
      } catch (error) {
        console.error('Failed to fetch profile:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchProfile()
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    setSaveSuccess(false)
    try {
      await saveDietaryProfileFn({
        data: {
          dietaryRestrictions:
            profile.dietaryRestrictions.length > 0
              ? profile.dietaryRestrictions
              : undefined,
          allergens:
            profile.allergens.length > 0 ? profile.allergens : undefined,
          dislikes: profile.dislikes.length > 0 ? profile.dislikes : undefined,
          preferences:
            profile.preferences.length > 0 ? profile.preferences : undefined,
          calorieGoal: profile.calorieGoal || undefined,
          proteinGoal: profile.proteinGoal || undefined,
        },
      })
      setSaveSuccess(true)
      setTimeout(() => setSaveSuccess(false), 3000)
    } catch (error) {
      console.error('Failed to save profile:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const toggleItem = (
    category: 'dietaryRestrictions' | 'allergens' | 'preferences',
    itemId: string,
  ) => {
    setProfile((prev) => ({
      ...prev,
      [category]: prev[category].includes(itemId)
        ? prev[category].filter((id) => id !== itemId)
        : [...prev[category], itemId],
    }))
  }

  const addDislike = () => {
    if (
      dislikeInput.trim() &&
      !profile.dislikes.includes(dislikeInput.trim())
    ) {
      setProfile((prev) => ({
        ...prev,
        dislikes: [...prev.dislikes, dislikeInput.trim()],
      }))
      setDislikeInput('')
    }
  }

  const removeDislike = (item: string) => {
    setProfile((prev) => ({
      ...prev,
      dislikes: prev.dislikes.filter((d) => d !== item),
    }))
  }

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Leaf className="w-8 h-8 text-[#81B29A]" />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1
          className="text-2xl md:text-3xl font-bold text-[#2D3436] mb-2"
          style={{ fontFamily: 'Fraunces, serif' }}
        >
          Dietary Preferences
        </h1>
        <p
          className="text-[#2D3436]/60"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          Help us personalize your meal recommendations by telling us about your
          dietary needs.
        </p>
      </div>

      <div className="space-y-8">
        {/* Dietary Restrictions */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#81B29A]/10 rounded-xl flex items-center justify-center">
              <Leaf className="w-5 h-5 text-[#81B29A]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Dietary Restrictions
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Select any diets you follow
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {dietaryRestrictionOptions.map((option) => (
              <motion.button
                key={option.id}
                onClick={() => toggleItem('dietaryRestrictions', option.id)}
                className={`
                                    relative p-3 rounded-xl text-left transition-all border-2
                                    ${
                                      profile.dietaryRestrictions.includes(
                                        option.id,
                                      )
                                        ? 'border-[#81B29A] bg-[#81B29A]/5'
                                        : 'border-transparent bg-[#F5F5F5] hover:bg-[#EBEBEB]'
                                    }
                                `}
                whileTap={{ scale: 0.95 }}
              >
                {profile.dietaryRestrictions.includes(option.id) && (
                  <div className="absolute top-2 right-2 w-5 h-5 bg-[#81B29A] rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
                <span className="text-xl block mb-1">{option.icon}</span>
                <span
                  className="text-sm font-medium text-[#2D3436] block"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {option.label}
                </span>
                <span
                  className="text-[10px] text-[#2D3436]/50 block"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {option.description}
                </span>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Allergens */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#E07A5F]/10 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-[#E07A5F]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Allergens
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                We'll warn you about meals containing these
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {allergenOptions.map((option) => (
              <motion.button
                key={option.id}
                onClick={() => toggleItem('allergens', option.id)}
                className={`
                                    flex items-center gap-2 px-4 py-2 rounded-full transition-all
                                    ${
                                      profile.allergens.includes(option.id)
                                        ? 'bg-[#E07A5F] text-white'
                                        : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB]'
                                    }
                                `}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <span>{option.icon}</span>
                <span className="text-sm font-medium">{option.label}</span>
              </motion.button>
            ))}
          </div>

          {profile.allergens.length > 0 && (
            <div className="mt-4 p-3 bg-[#FEF3C7] rounded-xl flex items-start gap-2">
              <Info className="w-4 h-4 text-[#92400E] mt-0.5 flex-shrink-0" />
              <p
                className="text-sm text-[#92400E]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Meals containing your allergens will be clearly marked. Always
                verify ingredients with staff if you have severe allergies.
              </p>
            </div>
          )}
        </section>

        {/* Preferences */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#F2CC8F]/20 rounded-xl flex items-center justify-center">
              <Heart className="w-5 h-5 text-[#D4A84B]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Food Preferences
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                What kind of meals do you enjoy?
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {preferenceOptions.map((option) => (
              <motion.button
                key={option.id}
                onClick={() => toggleItem('preferences', option.id)}
                className={`
                                    flex items-center gap-2 px-4 py-2 rounded-full transition-all
                                    ${
                                      profile.preferences.includes(option.id)
                                        ? 'bg-[#F2CC8F] text-[#2D3436]'
                                        : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB]'
                                    }
                                `}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <span>{option.icon}</span>
                <span className="text-sm font-medium">{option.label}</span>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Dislikes */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#2D3436]/5 rounded-xl flex items-center justify-center">
              <ThumbsDown className="w-5 h-5 text-[#2D3436]/60" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Foods You Dislike
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                We'll try to avoid recommending these
              </p>
            </div>
          </div>

          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={dislikeInput}
              onChange={(e) => setDislikeInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addDislike()}
              placeholder="e.g., cilantro, olives, mushrooms..."
              className="flex-1 px-4 py-2 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#2D3436]/10"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />
            <motion.button
              onClick={addDislike}
              className="px-4 py-2 bg-[#2D3436] text-white rounded-xl text-sm font-medium"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              whileTap={{ scale: 0.95 }}
            >
              Add
            </motion.button>
          </div>

          {profile.dislikes.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {profile.dislikes.map((item) => (
                <span
                  key={item}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#F5F5F5] rounded-full text-sm text-[#2D3436]/70"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  {item}
                  <button
                    onClick={() => removeDislike(item)}
                    className="ml-1 text-[#2D3436]/40 hover:text-[#E07A5F]"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </section>

        {/* Nutrition Goals */}
        <section className="bg-white rounded-2xl p-6 border border-[#2D3436]/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-xl flex items-center justify-center">
              <Target className="w-5 h-5 text-[#3D5A80]" />
            </div>
            <div>
              <h2
                className="text-lg font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Nutrition Goals
              </h2>
              <p
                className="text-sm text-[#2D3436]/50"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Optional daily targets for personalized recommendations
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                className="block text-sm font-medium text-[#2D3436] mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Daily Calorie Goal
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  max="5000"
                  value={profile.calorieGoal || ''}
                  onChange={(e) =>
                    setProfile({
                      ...profile,
                      calorieGoal: parseInt(e.target.value) || null,
                    })
                  }
                  placeholder="e.g., 2000"
                  className="w-full px-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#3D5A80]/30"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
                <span
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-[#2D3436]/40"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  cal/day
                </span>
              </div>
            </div>

            <div>
              <label
                className="block text-sm font-medium text-[#2D3436] mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Daily Protein Goal
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  max="500"
                  value={profile.proteinGoal || ''}
                  onChange={(e) =>
                    setProfile({
                      ...profile,
                      proteinGoal: parseInt(e.target.value) || null,
                    })
                  }
                  placeholder="e.g., 120"
                  className="w-full px-4 py-3 bg-[#F5F5F5] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#3D5A80]/30"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                />
                <span
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-[#2D3436]/40"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  g/day
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Save Button */}
        <motion.button
          onClick={handleSave}
          disabled={isSaving}
          className={`
                        w-full flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all
                        ${
                          saveSuccess
                            ? 'bg-[#81B29A] text-white'
                            : 'bg-[#2D3436] text-white hover:bg-[#1a1f20]'
                        }
                    `}
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          whileTap={{ scale: 0.98 }}
        >
          {isSaving ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Saving...
            </>
          ) : saveSuccess ? (
            <>
              <Check className="w-5 h-5" />
              Preferences Saved!
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              Save Preferences
            </>
          )}
        </motion.button>

        {/* AI Recommendation Note */}
        <div className="p-4 bg-gradient-to-r from-[#81B29A]/10 to-[#3D5A80]/10 rounded-xl flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-[#81B29A] mt-0.5 flex-shrink-0" />
          <div>
            <p
              className="text-sm font-medium text-[#2D3436] mb-1"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              AI-Powered Recommendations
            </p>
            <p
              className="text-sm text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Your preferences help our AI suggest meals you'll love. The more
              you tell us, the better your recommendations become!
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
