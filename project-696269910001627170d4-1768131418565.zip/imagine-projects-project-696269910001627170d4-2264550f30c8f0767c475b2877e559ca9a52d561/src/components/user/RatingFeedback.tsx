import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import {
  Star,
  MessageSquare,
  CheckCircle2,
  Loader2,
  ThumbsUp,
  ThumbsDown,
  X,
  Award,
} from 'lucide-react'
import {
  submitRatingFn,
  getPendingReviewsFn,
  getUserReviewsFn,
  SENTIMENT_TAGS,
} from '@/server/functions/ratings-feedback'
import type { Reviews } from '@/server/lib/appwrite.types'

interface RatingFeedbackProps {
  mealId?: string
  orderId?: string
  mealName?: string
  onComplete?: () => void
  compact?: boolean
}

export function RatingFeedback({
  mealId,
  orderId,
  mealName,
  onComplete,
  compact = false,
}: RatingFeedbackProps) {
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [comment, setComment] = useState('')
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const displayRating = hoveredRating || rating

  const handleSubmit = async () => {
    if (!mealId || rating === 0) return

    setIsSubmitting(true)
    setError(null)

    try {
      await submitRatingFn({
        data: {
          mealId,
          orderId,
          rating,
          comment: comment.trim() || undefined,
          tags: selectedTags.length > 0 ? selectedTags : undefined,
        },
      })
      setIsSubmitted(true)
      onComplete?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit rating')
    } finally {
      setIsSubmitting(false)
    }
  }

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag],
    )
  }

  const ratingLabels = ['', 'Poor', 'Fair', 'Good', 'Great', 'Excellent']

  if (isSubmitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`bg-gradient-to-br from-[#81B29A]/10 to-[#81B29A]/5 rounded-2xl p-6 text-center ${compact ? 'p-4' : ''}`}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring' }}
          className="w-16 h-16 bg-[#81B29A] rounded-full flex items-center justify-center mx-auto mb-4"
        >
          <CheckCircle2 className="w-8 h-8 text-white" />
        </motion.div>
        <h3
          className="text-lg font-bold text-[#2D3436] mb-2"
          style={{ fontFamily: 'Fraunces, serif' }}
        >
          Thank you for your feedback!
        </h3>
        <p
          className="text-sm text-[#2D3436]/60"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          Your review helps us improve and helps others discover great meals.
        </p>
      </motion.div>
    )
  }

  return (
    <div
      className={`bg-white rounded-2xl border border-[#2D3436]/5 overflow-hidden ${compact ? '' : 'shadow-lg'}`}
    >
      {/* Header */}
      <div className="p-4 border-b border-[#2D3436]/5 bg-gradient-to-r from-[#F2CC8F]/10 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#F2CC8F]/20 rounded-xl flex items-center justify-center">
            <Star className="w-5 h-5 text-[#D4A84B]" />
          </div>
          <div>
            <h3
              className="font-semibold text-[#2D3436]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Rate Your Meal
            </h3>
            {mealName && (
              <p
                className="text-sm text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {mealName}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Star Rating */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <motion.button
                key={star}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
                className="p-1 focus:outline-none"
              >
                <Star
                  className={`w-8 h-8 transition-colors ${
                    star <= displayRating
                      ? 'text-[#F2CC8F] fill-[#F2CC8F]'
                      : 'text-[#2D3436]/20'
                  }`}
                />
              </motion.button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            {displayRating > 0 && (
              <motion.p
                key={displayRating}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="text-sm font-medium text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                {ratingLabels[displayRating]}
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {/* Quick Tags */}
        {rating > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-3"
          >
            {/* Positive Tags */}
            {rating >= 3 && (
              <div>
                <p
                  className="text-xs text-[#2D3436]/50 mb-2 flex items-center gap-1"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  <ThumbsUp className="w-3 h-3" />
                  What did you like?
                </p>
                <div className="flex flex-wrap gap-2">
                  {SENTIMENT_TAGS.POSITIVE.slice(0, 6).map((tag) => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        selectedTags.includes(tag)
                          ? 'bg-[#81B29A] text-white'
                          : 'bg-[#81B29A]/10 text-[#81B29A] hover:bg-[#81B29A]/20'
                      }`}
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {tag.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Negative Tags */}
            {rating <= 3 && (
              <div>
                <p
                  className="text-xs text-[#2D3436]/50 mb-2 flex items-center gap-1"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  <ThumbsDown className="w-3 h-3" />
                  What could be improved?
                </p>
                <div className="flex flex-wrap gap-2">
                  {SENTIMENT_TAGS.NEGATIVE.slice(0, 6).map((tag) => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        selectedTags.includes(tag)
                          ? 'bg-[#E07A5F] text-white'
                          : 'bg-[#E07A5F]/10 text-[#E07A5F] hover:bg-[#E07A5F]/20'
                      }`}
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      {tag.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Comment */}
        {rating > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <label
              className="text-xs text-[#2D3436]/50 mb-1 block flex items-center gap-1"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              <MessageSquare className="w-3 h-3" />
              Add a comment (optional)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Tell us more about your experience..."
              rows={3}
              maxLength={1000}
              className="w-full px-4 py-3 bg-[#F5F5F5] rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-[#E07A5F]/30"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />
            <p
              className="text-xs text-[#2D3436]/40 text-right mt-1"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {comment.length}/1000
            </p>
          </motion.div>
        )}

        {/* Error */}
        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-3 bg-[#FEE2E2] rounded-xl text-sm text-[#EF4444]"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {error}
          </motion.div>
        )}

        {/* Submit Button */}
        <motion.button
          onClick={handleSubmit}
          disabled={rating === 0 || isSubmitting}
          className="w-full py-3 bg-[#E07A5F] text-white font-medium rounded-xl hover:bg-[#C4563D] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
          whileTap={{ scale: 0.98 }}
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              Submitting...
            </span>
          ) : (
            'Submit Review'
          )}
        </motion.button>
      </div>
    </div>
  )
}

// ============================================
// PENDING REVIEWS WIDGET
// ============================================

export function PendingReviewsWidget() {
  const [pendingReviews, setPendingReviews] = useState<
    Array<{ orderId: string; mealId: string; orderDate: string }>
  >([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedReview, setSelectedReview] = useState<{
    orderId: string
    mealId: string
  } | null>(null)

  useEffect(() => {
    const fetchPending = async () => {
      try {
        const result = await getPendingReviewsFn()
        setPendingReviews(result.pendingReviews.slice(0, 3))
      } catch (error) {
        console.error('Failed to fetch pending reviews:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchPending()
  }, [])

  if (isLoading || pendingReviews.length === 0) return null

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-[#F2CC8F]/20 to-[#F2CC8F]/5 rounded-2xl p-4 border border-[#F2CC8F]/30"
      >
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-[#F2CC8F]/30 rounded-xl flex items-center justify-center">
            <Award className="w-5 h-5 text-[#D4A84B]" />
          </div>
          <div>
            <h3
              className="font-semibold text-[#2D3436]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Rate Your Recent Meals
            </h3>
            <p
              className="text-xs text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {pendingReviews.length} meal{pendingReviews.length > 1 ? 's' : ''}{' '}
              awaiting your feedback
            </p>
          </div>
        </div>

        <div className="space-y-2">
          {pendingReviews.map((review) => (
            <motion.button
              key={`${review.orderId}-${review.mealId}`}
              onClick={() => setSelectedReview(review)}
              className="w-full p-3 bg-white rounded-xl flex items-center justify-between hover:bg-[#F5F5F5] transition-colors"
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-center gap-3">
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-[#2D3436]/20" />
                  ))}
                </div>
                <span
                  className="text-sm text-[#2D3436]/60"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Meal #{review.mealId.slice(-4)}
                </span>
              </div>
              <span
                className="text-xs text-[#E07A5F] font-medium"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Rate now →
              </span>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Rating Modal */}
      <AnimatePresence>
        {selectedReview && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedReview(null)}
            />
            <motion.div
              className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-md z-50"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="relative">
                <button
                  onClick={() => setSelectedReview(null)}
                  className="absolute -top-2 -right-2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center z-10"
                >
                  <X className="w-4 h-4 text-[#2D3436]/60" />
                </button>
                <RatingFeedback
                  mealId={selectedReview.mealId}
                  orderId={selectedReview.orderId}
                  onComplete={() => {
                    setSelectedReview(null)
                    setPendingReviews((prev) =>
                      prev.filter(
                        (r) =>
                          r.orderId !== selectedReview.orderId ||
                          r.mealId !== selectedReview.mealId,
                      ),
                    )
                  }}
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

// ============================================
// MEAL RATING DISPLAY
// ============================================

interface MealRatingDisplayProps {
  averageRating: number
  totalReviews: number
  size?: 'sm' | 'md' | 'lg'
  showCount?: boolean
}

export function MealRatingDisplay({
  averageRating,
  totalReviews,
  size = 'md',
  showCount = true,
}: MealRatingDisplayProps) {
  const sizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  }

  const textClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  }

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`${sizeClasses[size]} ${
              star <= Math.round(averageRating)
                ? 'text-[#F2CC8F] fill-[#F2CC8F]'
                : 'text-[#2D3436]/20'
            }`}
          />
        ))}
      </div>
      <span
        className={`font-medium text-[#2D3436] ${textClasses[size]}`}
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        {averageRating.toFixed(1)}
      </span>
      {showCount && (
        <span
          className={`text-[#2D3436]/50 ${textClasses[size]}`}
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          ({totalReviews})
        </span>
      )}
    </div>
  )
}

// ============================================
// USER REVIEWS LIST
// ============================================

export function UserReviewsList() {
  const [reviews, setReviews] = useState<Reviews[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const result = await getUserReviewsFn({ data: { limit: 20 } })
        setReviews(result.reviews)
      } catch (error) {
        console.error('Failed to fetch reviews:', error)
      } finally {
        setIsLoading(false)
      }
    }
    void fetchReviews()
  }, [])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-[#E07A5F] animate-spin" />
      </div>
    )
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-12">
        <Star className="w-12 h-12 text-[#2D3436]/20 mx-auto mb-4" />
        <p
          className="text-[#2D3436]/50"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          You haven't written any reviews yet
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <motion.div
          key={review.$id}
          layout
          className="bg-white rounded-xl border border-[#2D3436]/5 p-4"
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="flex gap-0.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= review.rating
                        ? 'text-[#F2CC8F] fill-[#F2CC8F]'
                        : 'text-[#2D3436]/20'
                    }`}
                  />
                ))}
              </div>
              {review.isVerifiedPurchase && (
                <span className="px-2 py-0.5 bg-[#81B29A]/10 text-[#81B29A] rounded text-xs font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Verified
                </span>
              )}
            </div>
            <span
              className="text-xs text-[#2D3436]/40"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {new Date(review.$createdAt).toLocaleDateString()}
            </span>
          </div>
          {review.comment && (
            <p
              className="text-sm text-[#2D3436]/70"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              {review.comment}
            </p>
          )}
          <p
            className="text-xs text-[#2D3436]/40 mt-2"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Meal #{review.mealId.slice(-6)}
          </p>
        </motion.div>
      ))}
    </div>
  )
}
