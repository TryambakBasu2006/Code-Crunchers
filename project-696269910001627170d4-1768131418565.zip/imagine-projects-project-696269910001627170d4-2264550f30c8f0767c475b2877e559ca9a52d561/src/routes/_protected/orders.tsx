import { createFileRoute } from '@tanstack/react-router'
import { OrderTracking } from '@/components/user/OrderTracking'

export const Route = createFileRoute('/_protected/orders')({
  component: OrdersPage,
})

function OrdersPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8 px-4">
      <OrderTracking />
    </div>
  )
}
