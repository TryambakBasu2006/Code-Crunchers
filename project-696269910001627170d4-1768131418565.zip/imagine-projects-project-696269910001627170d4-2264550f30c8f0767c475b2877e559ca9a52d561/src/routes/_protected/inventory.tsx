import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import { Package, Activity } from 'lucide-react'
import { InventoryManagement } from '@/components/admin/InventoryManagement'
import { RealTimeInventoryDashboard } from '@/components/admin/RealTimeInventoryDashboard'
import { authMiddleware } from '@/server/functions/auth'

export const Route = createFileRoute('/_protected/inventory')({
  loader: async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) {
      throw new Error('Unauthorized')
    }
    return {}
  },
  component: InventoryPage,
})

function InventoryPage() {
  const [activeTab, setActiveTab] = useState<'management' | 'realtime'>(
    'management',
  )

  const tabs = [
    { id: 'management', label: 'Inventory Management', icon: Package },
    { id: 'realtime', label: 'Real-Time Stock', icon: Activity },
  ] as const

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Tab Navigation */}
      <div className="bg-white border-b border-[#2D3436]/10 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-2 py-3">
            {tabs.map((tab) => (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-[#E07A5F] text-white'
                    : 'bg-[#F5F5F5] text-[#2D3436]/70 hover:bg-[#EBEBEB]'
                }`}
                style={{ fontFamily: 'DM Sans, sans-serif' }}
                whileTap={{ scale: 0.95 }}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'management' ? (
        <InventoryManagement />
      ) : (
        <div className="max-w-7xl mx-auto px-6 py-6">
          <RealTimeInventoryDashboard />
        </div>
      )}
    </div>
  )
}
