import { createFileRoute } from '@tanstack/react-router'
import { AdminSetupPage } from '@/components/admin/AdminSetupPage'

export const Route = createFileRoute('/_protected/admin-setup')({
  component: AdminSetupPage,
})
