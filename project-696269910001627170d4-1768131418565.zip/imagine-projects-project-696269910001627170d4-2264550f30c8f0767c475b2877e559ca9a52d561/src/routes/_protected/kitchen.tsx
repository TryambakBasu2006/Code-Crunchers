import { createFileRoute } from '@tanstack/react-router'
import { KitchenDashboard } from '@/components/admin/KitchenDashboard'

export const Route = createFileRoute('/_protected/kitchen')({
  component: KitchenPage,
})

function KitchenPage() {
  return <KitchenDashboard />
}
