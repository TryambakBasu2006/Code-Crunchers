import { createFileRoute } from '@tanstack/react-router'
import { DietaryPreferences } from '@/components/user/DietaryPreferences'

export const Route = createFileRoute('/_protected/preferences')({
  component: PreferencesPage,
})

function PreferencesPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8 px-4">
      <DietaryPreferences />
    </div>
  )
}
