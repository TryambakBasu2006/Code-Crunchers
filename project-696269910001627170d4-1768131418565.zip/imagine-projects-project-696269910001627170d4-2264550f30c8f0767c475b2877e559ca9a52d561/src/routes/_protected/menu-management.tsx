import { createFileRoute } from '@tanstack/react-router'
import { MenuManagement } from '@/components/admin/MenuManagement'

export const Route = createFileRoute('/_protected/menu-management')({
  component: MenuManagementPage,
})

function MenuManagementPage() {
  return <MenuManagement />
}
