import { createFileRoute } from '@tanstack/react-router'
import { TasteProfile } from '@/components/user/TasteProfile'

export const Route = createFileRoute('/_protected/taste-profile')({
  component: TasteProfilePage,
})

function TasteProfilePage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8 px-4">
      <TasteProfile />
    </div>
  )
}
