import { createFileRoute } from '@tanstack/react-router'
import { UserProfile } from '@/components/user/UserProfile'

export const Route = createFileRoute('/_protected/settings')({
  component: SettingsPage,
})

function SettingsPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8 px-4">
      <UserProfile />
    </div>
  )
}
