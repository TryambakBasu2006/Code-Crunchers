import { createFileRoute } from '@tanstack/react-router'
import { ContextualOffersManager } from '@/components/admin/ContextualOffersManager'

export const Route = createFileRoute('/_protected/offers')({
  component: OffersPage,
})

function OffersPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8 px-4">
      <ContextualOffersManager />
    </div>
  )
}
