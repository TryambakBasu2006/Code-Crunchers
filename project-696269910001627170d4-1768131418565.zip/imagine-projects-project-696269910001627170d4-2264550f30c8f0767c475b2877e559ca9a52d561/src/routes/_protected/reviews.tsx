import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import { Star, Award, TrendingUp } from 'lucide-react'
import {
  PendingReviewsWidget,
  UserReviewsList,
} from '@/components/user/RatingFeedback'
import { getTopRatedMealsFn } from '@/server/functions/ratings-feedback'
import { authMiddleware } from '@/server/functions/auth'
import type { MealRatingAggregates } from '@/server/lib/appwrite.types'

// Type for enriched rating aggregates with meal info
type TopRatedItem = MealRatingAggregates & {
  meal?: { $id: string; name: string; category: string | null }
}

export const Route = createFileRoute('/_protected/reviews')({
  loader: async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) {
      throw new Error('Unauthorized')
    }

    try {
      const topRated = await getTopRatedMealsFn({ data: { limit: 5 } })
      return { topRated: topRated.topRated }
    } catch {
      return { topRated: [] }
    }
  },
  component: ReviewsPage,
})

function ReviewsPage() {
  const { topRated } = Route.useLoaderData()

  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1
            className="text-2xl md:text-3xl font-bold text-[#2D3436] mb-2"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Ratings & Reviews
          </h1>
          <p
            className="text-[#2D3436]/60"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Share your feedback and discover top-rated meals
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Pending Reviews */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <PendingReviewsWidget />
            </motion.div>

            {/* Your Reviews */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl border border-[#2D3436]/5 overflow-hidden"
            >
              <div className="p-4 border-b border-[#2D3436]/5">
                <h2
                  className="font-semibold text-[#2D3436] flex items-center gap-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  <Star className="w-5 h-5 text-[#F2CC8F]" />
                  Your Reviews
                </h2>
              </div>
              <div className="p-4">
                <UserReviewsList />
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Top Rated Meals */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-2xl border border-[#2D3436]/5 overflow-hidden"
            >
              <div className="p-4 border-b border-[#2D3436]/5 bg-gradient-to-r from-[#F2CC8F]/10 to-transparent">
                <h3
                  className="font-semibold text-[#2D3436] flex items-center gap-2"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  <TrendingUp className="w-5 h-5 text-[#D4A84B]" />
                  Top Rated
                </h3>
              </div>
              <div className="p-4">
                {topRated.length > 0 ? (
                  <div className="space-y-3">
                    {topRated.map((item: TopRatedItem, index: number) => (
                      <div key={item.$id} className="flex items-center gap-3">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            index === 0
                              ? 'bg-[#F2CC8F] text-white'
                              : index === 1
                                ? 'bg-[#C0C0C0] text-white'
                                : index === 2
                                  ? 'bg-[#CD7F32] text-white'
                                  : 'bg-[#F5F5F5] text-[#2D3436]/60'
                          }`}
                        >
                          {index + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p
                            className="text-sm font-medium text-[#2D3436] truncate"
                            style={{ fontFamily: 'DM Sans, sans-serif' }}
                          >
                            {item.meal?.name ||
                              `Meal #${item.mealId.slice(-6)}`}
                          </p>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-[#F2CC8F] fill-[#F2CC8F]" />
                            <span
                              className="text-xs text-[#2D3436]/60"
                              style={{ fontFamily: 'DM Sans, sans-serif' }}
                            >
                              {item.averageRating.toFixed(1)} (
                              {item.totalReviews})
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p
                    className="text-sm text-[#2D3436]/50 text-center py-4"
                    style={{ fontFamily: 'DM Sans, sans-serif' }}
                  >
                    No ratings yet
                  </p>
                )}
              </div>
            </motion.div>

            {/* Rating Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-gradient-to-br from-[#3D5A80] to-[#2D4A70] rounded-2xl p-6 text-white"
            >
              <Award className="w-10 h-10 mb-4 opacity-80" />
              <h3
                className="font-semibold text-lg mb-2"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Your Feedback Matters
              </h3>
              <p
                className="text-sm text-white/70"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Your reviews help us improve our menu and help other diners
                discover great meals.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}
