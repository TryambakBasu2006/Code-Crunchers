import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import { Calendar, Clock, Info } from 'lucide-react'
import { ScheduledOrdersList } from '@/components/user/ScheduledOrders'
import { authMiddleware } from '@/server/functions/auth'

export const Route = createFileRoute('/_protected/scheduled')({
  loader: async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) {
      throw new Error('Unauthorized')
    }
    return {}
  },
  component: ScheduledOrdersPage,
})

function ScheduledOrdersPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8] py-8">
      <div className="max-w-3xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1
            className="text-2xl md:text-3xl font-bold text-[#2D3436] mb-2"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            Scheduled Orders
          </h1>
          <p
            className="text-[#2D3436]/60"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            Pre-order your meals for later pickup
          </p>
        </motion.div>

        {/* Info Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-r from-[#3D5A80]/10 to-[#3D5A80]/5 rounded-2xl p-4 mb-6 border border-[#3D5A80]/20"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-[#3D5A80]/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Info className="w-5 h-5 text-[#3D5A80]" />
            </div>
            <div>
              <h3
                className="font-semibold text-[#2D3436] mb-1"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                How Scheduled Orders Work
              </h3>
              <ul
                className="text-sm text-[#2D3436]/70 space-y-1"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                <li className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#3D5A80]" />
                  Order at least 30 minutes in advance
                </li>
                <li className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#3D5A80]" />
                  Available pickup times: 7 AM - 9 PM
                </li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Scheduled Orders List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <ScheduledOrdersList />
        </motion.div>

        {/* Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <div className="bg-white rounded-xl p-4 border border-[#2D3436]/5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 bg-[#81B29A]/10 rounded-lg flex items-center justify-center">
                <span className="text-lg">⏰</span>
              </div>
              <h4
                className="font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Beat the Rush
              </h4>
            </div>
            <p
              className="text-sm text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Schedule your lunch order in the morning to skip the queue during
              peak hours.
            </p>
          </div>

          <div className="bg-white rounded-xl p-4 border border-[#2D3436]/5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 bg-[#F2CC8F]/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">🔔</span>
              </div>
              <h4
                className="font-semibold text-[#2D3436]"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Get Notified
              </h4>
            </div>
            <p
              className="text-sm text-[#2D3436]/60"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              We'll notify you when your order is being prepared and when it's
              ready for pickup.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
