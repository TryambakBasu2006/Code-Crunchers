import { createFileRoute } from '@tanstack/react-router'
import { Hero } from '@/components/canteen/Hero'
import { Navbar } from '@/components/canteen/Navbar'
import { CategoryNav } from '@/components/canteen/CategoryNav'
import { FeaturedMeals } from '@/components/canteen/FeaturedMeals'
import { HowItWorks } from '@/components/canteen/HowItWorks'
import { Footer } from '@/components/canteen/Footer'

export const Route = createFileRoute('/_public/')({
  component: HomePage,
})

function HomePage() {
  return (
    <main className="bg-white">
      <Navbar />
      <div className="pt-16">
        <Hero />
        <CategoryNav />
        <FeaturedMeals />
        <HowItWorks />
        <Footer />
      </div>
    </main>
  )
}
