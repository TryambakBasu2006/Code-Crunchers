import { createFileRoute } from '@tanstack/react-router'
import { MenuPage } from '@/components/canteen/MenuPage'

export const Route = createFileRoute('/_public/menu')({
  component: MenuPage,
})
