import { createFileRoute, Link } from '@tanstack/react-router'
import { Shield, ArrowLeft, Mail, MapPin, Clock } from 'lucide-react'

export const Route = createFileRoute('/_public/privacy')({
  component: PrivacyPolicyPage,
})

function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#2D3436]/10">
        <div className="max-w-4xl mx-auto px-6 py-6">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-[#2D3436]/60 hover:text-[#2D3436] transition-colors mb-4"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#3D5A80] to-[#2D4A70] rounded-2xl flex items-center justify-center">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1
                className="text-3xl font-bold text-[#2D3436]"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                Privacy Policy
              </h1>
              <p
                className="text-[#2D3436]/60"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              >
                Last updated: January 2025
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-white rounded-2xl border border-[#2D3436]/5 p-8 md:p-12">
          <div
            className="prose prose-lg max-w-none"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            {/* Introduction */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                1. Introduction
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed">
                Canteen Companion ("we," "our," or "us") is committed to
                protecting your privacy. This Privacy Policy explains how we
                collect, use, disclose, and safeguard your information when you
                use our mobile application and website (collectively, the
                "Service").
              </p>
              <p className="text-[#2D3436]/70 leading-relaxed mt-4">
                We comply with the General Data Protection Regulation (GDPR) for
                users in the European Economic Area and the California Consumer
                Privacy Act (CCPA) for California residents.
              </p>
            </section>

            {/* Information We Collect */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                2. Information We Collect
              </h2>

              <h3 className="text-lg font-semibold text-[#2D3436] mt-6 mb-3">
                Personal Information
              </h3>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>Name and email address (for account creation)</li>
                <li>Phone number (optional, for SMS notifications)</li>
                <li>Dietary preferences and allergen information</li>
                <li>Order history and preferences</li>
                <li>Payment information (processed securely via Stripe)</li>
              </ul>

              <h3 className="text-lg font-semibold text-[#2D3436] mt-6 mb-3">
                Automatically Collected Information
              </h3>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>Device information (type, operating system)</li>
                <li>Usage data (pages visited, features used)</li>
                <li>IP address and approximate location</li>
                <li>Cookies and similar tracking technologies</li>
              </ul>
            </section>

            {/* How We Use Your Information */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                3. How We Use Your Information
              </h2>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>Process and fulfill your food orders</li>
                <li>Send order confirmations and status updates</li>
                <li>Provide personalized meal recommendations</li>
                <li>Improve our Service and user experience</li>
                <li>Communicate about promotions and updates (with consent)</li>
                <li>Ensure food safety by tracking allergen information</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            {/* Legal Basis for Processing */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                4. Legal Basis for Processing (GDPR)
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed mb-4">
                We process your personal data based on the following legal
                grounds:
              </p>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>
                  <strong>Contract:</strong> Processing necessary to fulfill
                  your orders
                </li>
                <li>
                  <strong>Consent:</strong> Marketing communications and
                  personalized recommendations
                </li>
                <li>
                  <strong>Legitimate Interest:</strong> Improving our services
                  and fraud prevention
                </li>
                <li>
                  <strong>Legal Obligation:</strong> Tax records and food safety
                  compliance
                </li>
              </ul>
            </section>

            {/* Your Rights */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                5. Your Rights
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed mb-4">
                Under GDPR and CCPA, you have the following rights:
              </p>

              <div className="grid md:grid-cols-2 gap-4 mt-6">
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Access
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Request a copy of all personal data we hold about you.
                  </p>
                </div>
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Rectification
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Correct any inaccurate or incomplete data.
                  </p>
                </div>
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Erasure
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Request deletion of your personal data ("right to be
                    forgotten").
                  </p>
                </div>
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Portability
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Receive your data in a machine-readable format.
                  </p>
                </div>
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Object
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Object to processing based on legitimate interests.
                  </p>
                </div>
                <div className="p-4 bg-[#F5F5F5] rounded-xl">
                  <h4 className="font-semibold text-[#2D3436] mb-2">
                    Right to Withdraw Consent
                  </h4>
                  <p className="text-sm text-[#2D3436]/60">
                    Withdraw consent at any time for consent-based processing.
                  </p>
                </div>
              </div>

              <div className="mt-6 p-4 bg-[#81B29A]/10 rounded-xl border border-[#81B29A]/20">
                <p className="text-sm text-[#2D3436]">
                  <strong>Exercise Your Rights:</strong> You can manage your
                  data directly in the app under Settings → Privacy & Data, or
                  contact us at privacy@canteencompanion.com
                </p>
              </div>
            </section>

            {/* Data Retention */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                6. Data Retention
              </h2>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>
                  <strong>Account data:</strong> Retained until account deletion
                </li>
                <li>
                  <strong>Order history:</strong> 7 years (legal/tax
                  requirements)
                </li>
                <li>
                  <strong>Payment records:</strong> 7 years (financial
                  regulations)
                </li>
                <li>
                  <strong>Marketing preferences:</strong> Until consent is
                  withdrawn
                </li>
                <li>
                  <strong>Usage analytics:</strong> 26 months (anonymized after)
                </li>
              </ul>
            </section>

            {/* Data Security */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                7. Data Security
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed">
                We implement industry-standard security measures to protect your
                data:
              </p>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2 mt-4">
                <li>End-to-end encryption for data in transit (TLS 1.3)</li>
                <li>Encryption at rest for stored data (AES-256)</li>
                <li>PCI-DSS compliant payment processing via Stripe</li>
                <li>Regular security audits and penetration testing</li>
                <li>Access controls and employee training</li>
              </ul>
            </section>

            {/* Third-Party Services */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                8. Third-Party Services
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed mb-4">
                We use the following third-party services:
              </p>
              <ul className="list-disc pl-6 text-[#2D3436]/70 space-y-2">
                <li>
                  <strong>Appwrite:</strong> Authentication and database (EU
                  servers)
                </li>
                <li>
                  <strong>Stripe:</strong> Payment processing (PCI-DSS
                  compliant)
                </li>
                <li>
                  <strong>Firebase:</strong> Push notifications (optional)
                </li>
                <li>
                  <strong>SendGrid:</strong> Email notifications (optional)
                </li>
              </ul>
            </section>

            {/* Cookies */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                9. Cookies
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed">
                We use essential cookies for authentication and session
                management. Analytics cookies are only used with your consent.
                You can manage cookie preferences in your browser settings.
              </p>
            </section>

            {/* Children's Privacy */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                10. Children's Privacy
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed">
                Our Service is not intended for children under 16. We do not
                knowingly collect personal information from children. If you
                believe we have collected data from a child, please contact us
                immediately.
              </p>
            </section>

            {/* Changes to Policy */}
            <section className="mb-10">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                11. Changes to This Policy
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed">
                We may update this Privacy Policy from time to time. We will
                notify you of any material changes via email or in-app
                notification. Continued use of the Service after changes
                constitutes acceptance of the updated policy.
              </p>
            </section>

            {/* Contact */}
            <section className="mb-6">
              <h2
                className="text-xl font-bold text-[#2D3436] mb-4"
                style={{ fontFamily: 'Fraunces, serif' }}
              >
                12. Contact Us
              </h2>
              <p className="text-[#2D3436]/70 leading-relaxed mb-6">
                If you have questions about this Privacy Policy or wish to
                exercise your rights:
              </p>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="flex items-start gap-3 p-4 bg-[#F5F5F5] rounded-xl">
                  <Mail className="w-5 h-5 text-[#E07A5F] mt-0.5" />
                  <div>
                    <p className="font-medium text-[#2D3436]">Email</p>
                    <p className="text-sm text-[#2D3436]/60">
                      privacy@canteencompanion.com
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 bg-[#F5F5F5] rounded-xl">
                  <MapPin className="w-5 h-5 text-[#E07A5F] mt-0.5" />
                  <div>
                    <p className="font-medium text-[#2D3436]">Address</p>
                    <p className="text-sm text-[#2D3436]/60">
                      Data Protection Officer
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 bg-[#F5F5F5] rounded-xl">
                  <Clock className="w-5 h-5 text-[#E07A5F] mt-0.5" />
                  <div>
                    <p className="font-medium text-[#2D3436]">Response Time</p>
                    <p className="text-sm text-[#2D3436]/60">Within 30 days</p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p
            className="text-sm text-[#2D3436]/50"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
          >
            © 2025 Canteen Companion. All rights reserved.
          </p>
        </div>
      </main>
    </div>
  )
}
