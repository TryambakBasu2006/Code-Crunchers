import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { Meals, AddOns } from '../lib/appwrite.types'

// ============================================
// PUBLIC MEAL FUNCTIONS
// ============================================

// Get all available meals
export const getMealsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        category: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
        offset: z.number().min(0).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const queries = [
      Query.equal('isAvailable', [true]),
      Query.limit(data?.limit || 50),
    ]

    if (data?.offset) {
      queries.push(Query.offset(data.offset))
    }

    if (data?.category) {
      queries.push(Query.equal('category', [data.category]))
    }

    if (data?.search) {
      queries.push(Query.search('name', data.search))
    }

    const meals = await db.meals.list(queries)
    return { meals: meals.rows, total: meals.total }
  })

// Get single meal
export const getMealFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const meal = await db.meals.get(data.mealId)
    return { meal }
  })

// Get meal categories
export const getMealCategoriesFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const meals = await db.meals.list([Query.equal('isAvailable', [true])])

    const categories = [
      ...new Set(meals.rows.map((m) => m.category).filter(Boolean)),
    ]

    return { categories }
  },
)

// Get today's specials
export const getDailySpecialsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const now = new Date().toISOString()

    const specials = await db.dailySpecials.list([
      Query.lessThanEqual('validFrom', now),
      Query.greaterThanEqual('validUntil', now),
    ])

    // Get the meal details for each special
    const specialsWithMeals = await Promise.all(
      specials.rows.map(async (special) => {
        try {
          const meal = await db.meals.get(special.mealId)
          return {
            ...special,
            meal,
            finalPrice:
              special.specialPrice ||
              meal.price * (1 - (special.discountPercent || 0) / 100),
          }
        } catch {
          return null
        }
      }),
    )

    return {
      specials: specialsWithMeals.filter(Boolean),
    }
  },
)

// Get available add-ons
export const getAddOnsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        mealCategory: z.string().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const queries = [Query.equal('isAvailable', [true])]

    const addOns = await db.addOns.list(queries)

    // Filter by applicable categories if specified
    let filteredAddOns = addOns.rows
    if (data?.mealCategory) {
      const mealCategory = data.mealCategory
      filteredAddOns = addOns.rows.filter(
        (addOn) =>
          !addOn.applicableMealCategories ||
          addOn.applicableMealCategories.length === 0 ||
          addOn.applicableMealCategories.includes(mealCategory),
      )
    }

    return { addOns: filteredAddOns }
  })

// ============================================
// ADMIN MEAL MANAGEMENT FUNCTIONS
// ============================================

const createMealSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(1000).optional(),
  price: z.number().positive(),
  category: z.string().optional(),
  calories: z.number().positive().optional(),
  allergens: z.array(z.string()).optional(),
  isAvailable: z.boolean().default(true),
  imageId: z.string().optional(),
})

// Create a new meal (admin)
export const createMealFn = createServerFn({ method: 'POST' })
  .inputValidator(createMealSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    const meal = await db.meals.create({
      createdBy: currentUser.$id,
      name: data.name.trim(),
      description: data.description?.trim() || null,
      price: data.price,
      category: data.category || null,
      calories: data.calories || null,
      allergens: data.allergens || null,
      isAvailable: data.isAvailable,
      imageId: data.imageId || null,
    })

    return { meal }
  })

// Update a meal (admin)
export const updateMealFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      updates: createMealSchema.partial(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    const updates: Partial<
      Omit<Meals, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.updates.name !== undefined) updates.name = data.updates.name.trim()
    if (data.updates.description !== undefined)
      updates.description = data.updates.description?.trim() || null
    if (data.updates.price !== undefined) updates.price = data.updates.price
    if (data.updates.category !== undefined)
      updates.category = data.updates.category || null
    if (data.updates.calories !== undefined)
      updates.calories = data.updates.calories || null
    if (data.updates.allergens !== undefined)
      updates.allergens = data.updates.allergens || null
    if (data.updates.isAvailable !== undefined)
      updates.isAvailable = data.updates.isAvailable
    if (data.updates.imageId !== undefined)
      updates.imageId = data.updates.imageId || null

    const meal = await db.meals.update(data.mealId, updates)

    return { meal }
  })

// Toggle meal availability (quick action)
export const toggleMealAvailabilityFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const meal = await db.meals.get(data.mealId)
    const updatedMeal = await db.meals.update(data.mealId, {
      isAvailable: !meal.isAvailable,
    })

    return { meal: updatedMeal }
  })

// Delete a meal (admin)
export const deleteMealFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    await db.meals.delete(data.mealId)

    return { success: true }
  })

// ============================================
// DAILY SPECIALS MANAGEMENT
// ============================================

const createSpecialSchema = z.object({
  mealId: z.string(),
  discountPercent: z.number().min(0).max(100).optional(),
  specialPrice: z.number().positive().optional(),
  validFrom: z.string(), // ISO datetime
  validUntil: z.string(), // ISO datetime
  maxQuantity: z.number().positive().optional(),
})

// Create a daily special
export const createDailySpecialFn = createServerFn({ method: 'POST' })
  .inputValidator(createSpecialSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const special = await db.dailySpecials.create({
      createdBy: currentUser.$id,
      mealId: data.mealId,
      discountPercent: data.discountPercent || null,
      specialPrice: data.specialPrice || null,
      validFrom: data.validFrom,
      validUntil: data.validUntil,
      maxQuantity: data.maxQuantity || null,
      soldCount: 0,
    })

    return { special }
  })

// Delete a daily special
export const deleteDailySpecialFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ specialId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.dailySpecials.delete(data.specialId)

    return { success: true }
  })

// ============================================
// ADD-ONS MANAGEMENT
// ============================================

const createAddOnSchema = z.object({
  name: z.string().min(1).max(100),
  price: z.number().min(0),
  calories: z.number().min(0).optional(),
  category: z.string().optional(),
  allergens: z.array(z.string()).optional(),
  isAvailable: z.boolean().default(true),
  applicableMealCategories: z.array(z.string()).optional(),
})

// Create an add-on
export const createAddOnFn = createServerFn({ method: 'POST' })
  .inputValidator(createAddOnSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const addOn = await db.addOns.create({
      createdBy: currentUser.$id,
      name: data.name.trim(),
      price: data.price,
      calories: data.calories || null,
      category: data.category || null,
      allergens: data.allergens || null,
      isAvailable: data.isAvailable,
      applicableMealCategories: data.applicableMealCategories || null,
    })

    return { addOn }
  })

// Update an add-on
export const updateAddOnFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      addOnId: z.string(),
      updates: createAddOnSchema.partial(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Partial<
      Omit<AddOns, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.updates.name !== undefined) updates.name = data.updates.name.trim()
    if (data.updates.price !== undefined) updates.price = data.updates.price
    if (data.updates.calories !== undefined)
      updates.calories = data.updates.calories || null
    if (data.updates.category !== undefined)
      updates.category = data.updates.category || null
    if (data.updates.allergens !== undefined)
      updates.allergens = data.updates.allergens || null
    if (data.updates.isAvailable !== undefined)
      updates.isAvailable = data.updates.isAvailable
    if (data.updates.applicableMealCategories !== undefined) {
      updates.applicableMealCategories =
        data.updates.applicableMealCategories || null
    }

    const addOn = await db.addOns.update(data.addOnId, updates)

    return { addOn }
  })

// Delete an add-on
export const deleteAddOnFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ addOnId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.addOns.delete(data.addOnId)

    return { success: true }
  })
