import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'

/**
 * Admin Setup Functions
 *
 * These functions help set up initial admin users and manage staff roles.
 * In production, you would typically:
 * 1. Create the first admin through a secure setup process
 * 2. Use environment variables for initial admin credentials
 * 3. Implement proper role-based access control
 */

// Promote current user to admin (for initial setup - should be secured in production)
export const promoteToAdminFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      secretKey: z.string(), // Simple protection - use env var in production
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Simple secret key check - in production, use environment variable
    const ADMIN_SETUP_KEY =
      process.env.ADMIN_SETUP_KEY || 'canteen-admin-setup-2024'
    if (data.secretKey !== ADMIN_SETUP_KEY) {
      throw new Error('Invalid setup key')
    }

    // Check if user already has a profile
    const profiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (profiles.rows.length === 0) {
      // Create new profile with admin privileges
      const profile = await db.userProfiles.create({
        createdBy: currentUser.$id,
        displayName: currentUser.name || 'Admin',
        phoneNumber: null,
        avatarFileId: null,
        ssoProvider: null,
        notifyByPush: true,
        notifyBySms: false,
        notifyByEmail: true,
        preferredPickupLocation: null,
        defaultPaymentMethod: null,
        stripeCustomerId: null,
        isStaff: true,
        isAdmin: true,
        gdprConsentAt: new Date().toISOString(),
        marketingConsentAt: null,
      })

      return {
        success: true,
        message: 'Admin profile created successfully',
        profile,
      }
    }

    // Update existing profile to admin
    const profile = await db.userProfiles.update(profiles.rows[0].$id, {
      isStaff: true,
      isAdmin: true,
    })

    return {
      success: true,
      message: 'User promoted to admin successfully',
      profile,
    }
  })

// Promote a user to staff (admin only)
export const promoteToStaffFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      targetUserId: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if current user is admin
    const adminProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (adminProfiles.rows.length === 0 || !adminProfiles.rows[0].isAdmin) {
      throw new Error('Forbidden: Admin access required')
    }

    // Find target user's profile
    const targetProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [data.targetUserId]),
      Query.limit(1),
    ])

    if (targetProfiles.rows.length === 0) {
      throw new Error('User profile not found')
    }

    // Update to staff
    const profile = await db.userProfiles.update(targetProfiles.rows[0].$id, {
      isStaff: true,
    })

    return {
      success: true,
      message: 'User promoted to staff successfully',
      profile,
    }
  })

// Get all staff members (admin only)
export const getStaffMembersFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if current user is admin
    const adminProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (adminProfiles.rows.length === 0 || !adminProfiles.rows[0].isAdmin) {
      throw new Error('Forbidden: Admin access required')
    }

    // Get all staff and admin users
    const staffProfiles = await db.userProfiles.list([
      Query.equal('isStaff', [true]),
    ])

    return {
      staff: staffProfiles.rows,
      total: staffProfiles.total,
    }
  },
)

// Revoke staff access (admin only)
export const revokeStaffAccessFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      targetUserId: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if current user is admin
    const adminProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (adminProfiles.rows.length === 0 || !adminProfiles.rows[0].isAdmin) {
      throw new Error('Forbidden: Admin access required')
    }

    // Prevent self-demotion
    if (data.targetUserId === currentUser.$id) {
      throw new Error('Cannot revoke your own access')
    }

    // Find target user's profile
    const targetProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [data.targetUserId]),
      Query.limit(1),
    ])

    if (targetProfiles.rows.length === 0) {
      throw new Error('User profile not found')
    }

    // Revoke staff and admin access
    const profile = await db.userProfiles.update(targetProfiles.rows[0].$id, {
      isStaff: false,
      isAdmin: false,
    })

    return {
      success: true,
      message: 'Staff access revoked successfully',
      profile,
    }
  })
