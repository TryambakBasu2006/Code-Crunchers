import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { Orders } from '../lib/appwrite.types'

// ============================================
// SCHEDULED ORDER QUEUE SYSTEM
// ============================================

// Queue statuses for scheduled orders
export const QUEUE_STATUSES = {
  SCHEDULED: 'scheduled', // Order is scheduled for future
  PENDING_RELEASE: 'pending_release', // Ready to be released to kitchen
  RELEASED: 'released', // Sent to kitchen queue
  FAILED: 'failed', // Failed to process
  CANCELLED: 'cancelled', // User cancelled
} as const

export type ScheduledQueueStatus =
  (typeof QUEUE_STATUSES)[keyof typeof QUEUE_STATUSES]

// Default prep time in minutes if not specified
const DEFAULT_PREP_TIME = 15

// How many minutes before pickup to release to kitchen
const RELEASE_BUFFER_MINUTES = 20

// ============================================
// CREATE SCHEDULED ORDER
// ============================================

const createScheduledOrderSchema = z.object({
  items: z.array(
    z.object({
      mealId: z.string(),
      quantity: z.number().min(1).max(20),
      unitPrice: z.number().positive(),
      portionSize: z.enum(['small', 'regular', 'large', 'family']).optional(),
      spiceLevel: z.number().min(0).max(4).optional(),
      addOns: z.array(z.string()).optional(),
      addOnPrices: z.array(z.number()).optional(),
      dietaryPreferences: z.array(z.string()).optional(),
      specialInstructions: z.string().max(500).optional(),
    }),
  ),
  scheduledPickupTime: z.string(), // ISO datetime
  notes: z.string().max(500).optional(),
  estimatedPrepTime: z.number().min(5).max(120).optional(), // minutes
})

export const createScheduledOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(createScheduledOrderSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const { items, scheduledPickupTime, notes, estimatedPrepTime } = data

    // Validate pickup time is in the future
    const pickupDate = new Date(scheduledPickupTime)
    const now = new Date()
    const minPickupTime = new Date(now.getTime() + 30 * 60000) // At least 30 mins from now

    if (pickupDate < minPickupTime) {
      throw new Error('Pickup time must be at least 30 minutes from now')
    }

    // Validate pickup time is within operating hours (e.g., 7 AM - 9 PM)
    const pickupHour = pickupDate.getHours()
    if (pickupHour < 7 || pickupHour >= 21) {
      throw new Error('Pickup time must be between 7:00 AM and 9:00 PM')
    }

    // Calculate totals
    const mealIds: string[] = []
    const quantities: number[] = []
    let totalPrice = 0

    for (const item of items) {
      mealIds.push(item.mealId)
      quantities.push(item.quantity)

      const addOnsTotal = item.addOnPrices?.reduce((sum, p) => sum + p, 0) || 0
      const itemTotal = (item.unitPrice + addOnsTotal) * item.quantity
      totalPrice += itemTotal
    }

    // Create the order with pending status
    const order = await db.orders.create({
      createdBy: currentUser.$id,
      mealIds,
      quantities,
      totalPrice,
      status: 'pending',
      notes: notes?.trim() || null,
      pickupTime: scheduledPickupTime,
    })

    // Create order items
    for (const item of items) {
      const addOnsTotal = item.addOnPrices?.reduce((sum, p) => sum + p, 0) || 0
      const itemTotalPrice = (item.unitPrice + addOnsTotal) * item.quantity

      await db.orderItems.create({
        createdBy: currentUser.$id,
        orderId: order.$id,
        mealId: item.mealId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: itemTotalPrice,
        portionSize: item.portionSize || 'regular',
        spiceLevel: item.spiceLevel?.toString() || '1',
        addOns: item.addOns || null,
        addOnPrices: item.addOnPrices || null,
        dietaryPreferences: item.dietaryPreferences || null,
        specialInstructions: item.specialInstructions?.trim() || null,
      })
    }

    // Calculate when to release to kitchen
    const prepTime = estimatedPrepTime || DEFAULT_PREP_TIME
    const releaseTime = new Date(
      pickupDate.getTime() - (prepTime + RELEASE_BUFFER_MINUTES) * 60000,
    )

    // Create scheduled order entry
    const scheduledOrder = await db.scheduledOrders.create({
      createdBy: currentUser.$id,
      orderId: order.$id,
      scheduledPickupTime,
      releaseToKitchenAt: releaseTime.toISOString(),
      queueStatus: QUEUE_STATUSES.SCHEDULED,
      estimatedPrepTime: prepTime,
      priority: calculatePriority(pickupDate),
      releasedAt: null,
      failureReason: null,
      retryCount: 0,
      maxRetries: 3,
    })

    // Create order history entry
    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: order.$id,
      previousStatus: null,
      newStatus: 'pending',
      changedBy: currentUser.$id,
      notes: `Scheduled order for pickup at ${pickupDate.toLocaleTimeString()}`,
    })

    return { order, scheduledOrder }
  })

// ============================================
// GET SCHEDULED ORDERS
// ============================================

export const getScheduledOrdersFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        status: z.string().optional(),
        upcoming: z.boolean().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries: string[] = [
      Query.equal('createdBy', [currentUser.$id]),
      Query.orderAsc('scheduledPickupTime'),
      Query.limit(data?.limit || 20),
    ]

    if (data?.status) {
      queries.push(Query.equal('queueStatus', [data.status]))
    }

    if (data?.upcoming) {
      queries.push(
        Query.greaterThanEqual('scheduledPickupTime', new Date().toISOString()),
      )
    }

    const scheduledOrders = await db.scheduledOrders.list(queries)

    // Get associated orders
    const orderIds = scheduledOrders.rows.map((so) => so.orderId)
    let orders: Orders[] = []

    if (orderIds.length > 0) {
      const ordersResult = await db.orders.list([Query.equal('$id', orderIds)])
      orders = ordersResult.rows
    }

    // Combine data
    const enrichedOrders = scheduledOrders.rows.map((so) => ({
      ...so,
      order: orders.find((o) => o.$id === so.orderId),
    }))

    return { scheduledOrders: enrichedOrders, total: scheduledOrders.total }
  })

// ============================================
// ADMIN: GET ALL PENDING RELEASES
// ============================================

export const getPendingReleasesFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const now = new Date().toISOString()

    // Get orders that should be released to kitchen
    const pendingReleases = await db.scheduledOrders.list([
      Query.equal('queueStatus', [QUEUE_STATUSES.SCHEDULED]),
      Query.lessThanEqual('releaseToKitchenAt', now),
      Query.orderAsc('releaseToKitchenAt'),
      Query.limit(data?.limit || 50),
    ])

    return {
      pendingReleases: pendingReleases.rows,
      total: pendingReleases.total,
    }
  })

// ============================================
// PROCESS SCHEDULED ORDER QUEUE
// ============================================

export const processScheduledQueueFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const { currentUser } = await authMiddleware()
  if (!currentUser) throw new Error('Unauthorized')

  const now = new Date().toISOString()

  // Get orders ready to be released
  const pendingReleases = await db.scheduledOrders.list([
    Query.equal('queueStatus', [QUEUE_STATUSES.SCHEDULED]),
    Query.lessThanEqual('releaseToKitchenAt', now),
    Query.orderAsc('priority'),
    Query.limit(20),
  ])

  const results: Array<{
    orderId: string
    success: boolean
    error?: string
  }> = []

  for (const scheduled of pendingReleases.rows) {
    try {
      // Update order status to confirmed
      await db.orders.update(scheduled.orderId, {
        status: 'confirmed',
      })

      // Update scheduled order status
      await db.scheduledOrders.update(scheduled.$id, {
        queueStatus: QUEUE_STATUSES.RELEASED,
        releasedAt: now,
      })

      // Add to kitchen queue
      await db.kitchenQueue.create({
        createdBy: currentUser.$id,
        orderId: scheduled.orderId,
        orderItemId: null,
        station: null,
        status: 'pending',
        priority: scheduled.priority,
        assignedTo: null,
        estimatedPrepTime: scheduled.estimatedPrepTime,
        startedAt: null,
        completedAt: null,
        displayPosition: null,
      })

      // Create order history entry
      await db.orderHistory.create({
        createdBy: currentUser.$id,
        orderId: scheduled.orderId,
        previousStatus: 'pending',
        newStatus: 'confirmed',
        changedBy: 'system',
        notes: 'Scheduled order released to kitchen',
      })

      // Create notification for user
      await db.notifications.create({
        createdBy: scheduled.createdBy,
        orderId: scheduled.orderId,
        type: 'order_confirmed',
        title: '🍳 Your order is being prepared!',
        message: `Your scheduled order is now being prepared for pickup at ${new Date(scheduled.scheduledPickupTime).toLocaleTimeString()}.`,
        isRead: false,
        channel: 'in_app',
        sentAt: now,
      })

      results.push({ orderId: scheduled.orderId, success: true })
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error'

      // Update retry count
      const retryCount = (scheduled.retryCount || 0) + 1
      const maxRetries = scheduled.maxRetries || 3

      if (retryCount >= maxRetries) {
        await db.scheduledOrders.update(scheduled.$id, {
          queueStatus: QUEUE_STATUSES.FAILED,
          failureReason: errorMessage,
          retryCount,
        })
      } else {
        await db.scheduledOrders.update(scheduled.$id, {
          retryCount,
          failureReason: errorMessage,
        })
      }

      results.push({
        orderId: scheduled.orderId,
        success: false,
        error: errorMessage,
      })
    }
  }

  return {
    processed: results.length,
    successful: results.filter((r) => r.success).length,
    failed: results.filter((r) => !r.success).length,
    results,
  }
})

// ============================================
// CANCEL SCHEDULED ORDER
// ============================================

export const cancelScheduledOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      scheduledOrderId: z.string(),
      reason: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const scheduled = await db.scheduledOrders.get(data.scheduledOrderId)

    // Verify ownership
    if (scheduled.createdBy !== currentUser.$id) {
      throw new Error('Scheduled order not found')
    }

    // Can only cancel if not yet released
    if (scheduled.queueStatus === QUEUE_STATUSES.RELEASED) {
      throw new Error(
        'Cannot cancel order that has already been sent to kitchen',
      )
    }

    // Update scheduled order
    await db.scheduledOrders.update(data.scheduledOrderId, {
      queueStatus: QUEUE_STATUSES.CANCELLED,
    })

    // Update order status
    await db.orders.update(scheduled.orderId, {
      status: 'cancelled',
    })

    // Create order history entry
    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: scheduled.orderId,
      previousStatus: 'pending',
      newStatus: 'cancelled',
      changedBy: currentUser.$id,
      notes: data.reason || 'Scheduled order cancelled by user',
    })

    return { success: true }
  })

// ============================================
// UPDATE SCHEDULED ORDER TIME
// ============================================

export const updateScheduledTimeFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      scheduledOrderId: z.string(),
      newPickupTime: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const scheduled = await db.scheduledOrders.get(data.scheduledOrderId)

    // Verify ownership
    if (scheduled.createdBy !== currentUser.$id) {
      throw new Error('Scheduled order not found')
    }

    // Can only update if not yet released
    if (scheduled.queueStatus !== QUEUE_STATUSES.SCHEDULED) {
      throw new Error('Cannot update order that has already been processed')
    }

    // Validate new pickup time
    const newPickupDate = new Date(data.newPickupTime)
    const now = new Date()
    const minPickupTime = new Date(now.getTime() + 30 * 60000)

    if (newPickupDate < minPickupTime) {
      throw new Error('Pickup time must be at least 30 minutes from now')
    }

    // Calculate new release time
    const prepTime = scheduled.estimatedPrepTime || DEFAULT_PREP_TIME
    const newReleaseTime = new Date(
      newPickupDate.getTime() - (prepTime + RELEASE_BUFFER_MINUTES) * 60000,
    )

    // Update scheduled order
    const updated = await db.scheduledOrders.update(data.scheduledOrderId, {
      scheduledPickupTime: data.newPickupTime,
      releaseToKitchenAt: newReleaseTime.toISOString(),
      priority: calculatePriority(newPickupDate),
    })

    // Update order pickup time
    await db.orders.update(scheduled.orderId, {
      pickupTime: data.newPickupTime,
    })

    return { scheduledOrder: updated }
  })

// ============================================
// GET AVAILABLE PICKUP SLOTS
// ============================================

export const getAvailablePickupSlotsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        date: z.string().optional(), // ISO date string
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const targetDate = data?.date ? new Date(data.date) : new Date()
    targetDate.setHours(0, 0, 0, 0)

    const slots: Array<{
      time: string
      available: boolean
      ordersCount: number
      maxOrders: number
    }> = []

    // Generate 15-minute slots from 7 AM to 9 PM
    const startHour = 7
    const endHour = 21
    const slotDuration = 15 // minutes
    const maxOrdersPerSlot = 10

    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += slotDuration) {
        const slotTime = new Date(targetDate)
        slotTime.setHours(hour, minute, 0, 0)

        // Skip past slots for today
        if (slotTime < new Date()) continue

        const slotEnd = new Date(slotTime.getTime() + slotDuration * 60000)

        // Count existing orders in this slot
        const existingOrders = await db.scheduledOrders.list([
          Query.greaterThanEqual('scheduledPickupTime', slotTime.toISOString()),
          Query.lessThan('scheduledPickupTime', slotEnd.toISOString()),
          Query.notEqual('queueStatus', [QUEUE_STATUSES.CANCELLED]),
        ])

        slots.push({
          time: slotTime.toISOString(),
          available: existingOrders.total < maxOrdersPerSlot,
          ordersCount: existingOrders.total,
          maxOrders: maxOrdersPerSlot,
        })
      }
    }

    return { slots, date: targetDate.toISOString() }
  })

// ============================================
// HELPER FUNCTIONS
// ============================================

function calculatePriority(pickupTime: Date): number {
  // Higher priority (lower number) for sooner pickups
  const now = new Date()
  const minutesUntilPickup = (pickupTime.getTime() - now.getTime()) / 60000

  if (minutesUntilPickup <= 30) return 1
  if (minutesUntilPickup <= 60) return 2
  if (minutesUntilPickup <= 120) return 3
  return 5
}
