import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type {
  Meals,
  Orders,
  DietaryProfiles,
  UserTasteProfile,
  MealEmbeddings,
  UserSimilarity,
  AddOns,
} from '../lib/appwrite.types'

// ============================================
// HYBRID RECOMMENDATION ENGINE
// Combines Collaborative Filtering + Content-Based Filtering
// ============================================

export const RECOMMENDATION_STRATEGIES = {
  COLLABORATIVE: 'collaborative', // What similar users order
  CONTENT_BASED: 'content_based', // Based on user's past meals & preferences
  HYBRID: 'hybrid', // Combined approach
  TIME_CONTEXTUAL: 'time_contextual', // Time-of-day based
  INVENTORY_AWARE: 'inventory_aware', // Based on available stock
  TRENDING: 'trending', // Currently popular items
  PERSONALIZED_PAIRING: 'personalized_pairing', // Smart add-on suggestions
} as const

export type RecommendationStrategy =
  (typeof RECOMMENDATION_STRATEGIES)[keyof typeof RECOMMENDATION_STRATEGIES]

interface ScoredMeal {
  meal: Meals
  score: number
  reason: string
  reasonType: string
  strategy: RecommendationStrategy
  confidence: number
}

interface RecommendationContext {
  currentMealId?: string
  cartMealIds?: string[]
  currentTime: Date
  dayOfWeek: number
  isLunchRush: boolean
  isAfternoonSlump: boolean
}

// ============================================
// MAIN HYBRID RECOMMENDATION FUNCTION
// ============================================

export const getHybridRecommendationsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        limit: z.number().min(1).max(30).optional(),
        strategy: z
          .enum([
            'collaborative',
            'content_based',
            'hybrid',
            'time_contextual',
            'inventory_aware',
            'trending',
          ])
          .optional(),
        contextMealId: z.string().optional(), // For pairing suggestions
        cartMealIds: z.array(z.string()).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    const limit = data?.limit || 8
    const strategy = data?.strategy || 'hybrid'

    // Build recommendation context
    const now = new Date()
    const context: RecommendationContext = {
      currentMealId: data?.contextMealId,
      cartMealIds: data?.cartMealIds,
      currentTime: now,
      dayOfWeek: now.getDay(),
      isLunchRush: now.getHours() >= 11 && now.getHours() <= 14,
      isAfternoonSlump: now.getHours() >= 14 && now.getHours() <= 17,
    }

    // Get all available meals
    const allMeals = await db.meals.list([Query.equal('isAvailable', [true])])
    if (allMeals.rows.length === 0) {
      return {
        recommendations: [],
        strategy,
        context: { time: now.toISOString() },
      }
    }

    let scoredMeals: ScoredMeal[] = []

    if (currentUser) {
      // Authenticated user - full personalization
      const [
        dietaryProfile,
        tasteProfile,
        orderHistory,
        userSimilarities,
        mealEmbeddings,
      ] = await Promise.all([
        getDietaryProfile(currentUser.$id),
        getTasteProfile(currentUser.$id),
        getOrderHistory(currentUser.$id),
        getUserSimilarities(currentUser.$id),
        getMealEmbeddings(),
      ])

      switch (strategy) {
        case 'collaborative':
          scoredMeals = await collaborativeFiltering(
            allMeals.rows,
            userSimilarities,
            dietaryProfile,
          )
          break
        case 'content_based':
          scoredMeals = contentBasedFiltering(
            allMeals.rows,
            tasteProfile,
            orderHistory,
            mealEmbeddings,
            dietaryProfile,
            context,
          )
          break
        case 'hybrid':
        default:
          scoredMeals = await hybridFiltering(
            allMeals.rows,
            tasteProfile,
            orderHistory,
            userSimilarities,
            mealEmbeddings,
            dietaryProfile,
            context,
          )
          break
      }
    } else {
      // Anonymous user - popularity and time-based
      scoredMeals = await anonymousRecommendations(allMeals.rows, context)
    }

    // Filter out meals in cart
    if (context.cartMealIds && context.cartMealIds.length > 0) {
      scoredMeals = scoredMeals.filter(
        (sm) => !context.cartMealIds!.includes(sm.meal.$id),
      )
    }

    // Sort by score and limit
    const recommendations = scoredMeals
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map((sm) => ({
        meal: sm.meal,
        reason: sm.reason,
        reasonType: sm.reasonType,
        score: Math.round(sm.score * 100) / 100,
        confidence: Math.round(sm.confidence * 100),
        strategy: sm.strategy,
      }))

    return {
      recommendations,
      strategy,
      context: {
        time: now.toISOString(),
        isLunchRush: context.isLunchRush,
        isAfternoonSlump: context.isAfternoonSlump,
      },
    }
  })

// ============================================
// COLLABORATIVE FILTERING
// "Users who ordered X also ordered Y"
// ============================================

async function collaborativeFiltering(
  meals: Meals[],
  similarities: UserSimilarity[],
  dietaryProfile: DietaryProfiles | null,
): Promise<ScoredMeal[]> {
  const scoredMeals: ScoredMeal[] = []

  if (similarities.length === 0) {
    // No similar users found - fall back to popularity
    return meals.slice(0, 10).map((meal, idx) => ({
      meal,
      score: 0.5 - idx * 0.02,
      reason: 'Popular with other diners',
      reasonType: 'popular',
      strategy: RECOMMENDATION_STRATEGIES.COLLABORATIVE,
      confidence: 0.4,
    }))
  }

  // Get orders from similar users
  const similarUserIds = similarities
    .sort((a, b) => b.similarityScore - a.similarityScore)
    .slice(0, 10)
    .map((s) => s.similarUserId)

  const similarUserOrders = await db.orders.list([
    Query.equal('createdBy', similarUserIds),
    Query.orderDesc('$createdAt'),
    Query.limit(100),
  ])

  // Count meal frequencies from similar users
  const mealFrequency: Record<
    string,
    { count: number; avgSimilarity: number }
  > = {}

  for (const order of similarUserOrders.rows) {
    const similarity = similarities.find(
      (s) => s.similarUserId === order.createdBy,
    )
    const simScore = similarity?.similarityScore || 0.5

    for (const mealId of order.mealIds) {
      if (!mealFrequency[mealId]) {
        mealFrequency[mealId] = { count: 0, avgSimilarity: 0 }
      }
      mealFrequency[mealId].count++
      mealFrequency[mealId].avgSimilarity =
        (mealFrequency[mealId].avgSimilarity *
          (mealFrequency[mealId].count - 1) +
          simScore) /
        mealFrequency[mealId].count
    }
  }

  // Score meals based on similar user preferences
  for (const meal of meals) {
    if (!passesAllergenFilter(meal, dietaryProfile)) continue

    const freq = mealFrequency[meal.$id]
    if (freq) {
      const popularityScore = Math.min(freq.count / 10, 1) * 0.4
      const similarityBoost = freq.avgSimilarity * 0.6
      const score = popularityScore + similarityBoost

      scoredMeals.push({
        meal,
        score,
        reason: `Loved by ${freq.count} similar diners`,
        reasonType: 'similar_users',
        strategy: RECOMMENDATION_STRATEGIES.COLLABORATIVE,
        confidence: Math.min(freq.avgSimilarity + 0.2, 1),
      })
    }
  }

  return scoredMeals
}

// ============================================
// CONTENT-BASED FILTERING
// Based on user's past meals and stated preferences
// ============================================

function contentBasedFiltering(
  meals: Meals[],
  tasteProfile: UserTasteProfile | null,
  orderHistory: Orders[],
  embeddings: MealEmbeddings[],
  dietaryProfile: DietaryProfiles | null,
  context: RecommendationContext,
): ScoredMeal[] {
  const scoredMeals: ScoredMeal[] = []

  // Build user preference vector from order history
  const orderedMealIds = new Set(orderHistory.flatMap((o) => o.mealIds))
  const orderedMeals = meals.filter((m) => orderedMealIds.has(m.$id))

  // Extract preference patterns
  const categoryPreferences: Record<string, number> = {}
  const priceRange = { min: Infinity, max: 0, avg: 0 }
  const calorieRange = { min: Infinity, max: 0, avg: 0 }

  for (const meal of orderedMeals) {
    if (meal.category) {
      categoryPreferences[meal.category] =
        (categoryPreferences[meal.category] || 0) + 1
    }
    priceRange.min = Math.min(priceRange.min, meal.price)
    priceRange.max = Math.max(priceRange.max, meal.price)
    priceRange.avg += meal.price
    if (meal.calories) {
      calorieRange.min = Math.min(calorieRange.min, meal.calories)
      calorieRange.max = Math.max(calorieRange.max, meal.calories)
      calorieRange.avg += meal.calories
    }
  }

  if (orderedMeals.length > 0) {
    priceRange.avg /= orderedMeals.length
    calorieRange.avg /= orderedMeals.length
  }

  // Score each meal
  for (const meal of meals) {
    if (!passesAllergenFilter(meal, dietaryProfile)) continue
    if (!passesDietaryFilter(meal, dietaryProfile)) continue
    if (!passesDislikesFilter(meal, dietaryProfile)) continue

    let score = 0
    let reason = ''
    let confidence = 0.5

    // Category match
    if (meal.category && categoryPreferences[meal.category]) {
      const categoryScore =
        Math.min(categoryPreferences[meal.category] / 5, 1) * 0.3
      score += categoryScore
      reason = `You often enjoy ${meal.category}`
      confidence += 0.1
    }

    // Taste profile match
    if (tasteProfile) {
      const tasteScore = calculateTasteMatch(meal, tasteProfile, embeddings)
      score += tasteScore * 0.4
      if (tasteScore > 0.6) {
        reason = reason || 'Matches your taste profile'
        confidence += 0.2
      }
    }

    // Price preference match
    if (
      orderedMeals.length > 0 &&
      meal.price >= priceRange.min * 0.8 &&
      meal.price <= priceRange.max * 1.2
    ) {
      score += 0.1
    }

    // Time-based boost
    const timeScore = getTimeBasedScore(meal, context)
    score += timeScore * 0.2
    if (timeScore > 0.7) {
      reason = reason || getTimeBasedReason(context.currentTime.getHours())
    }

    // Novelty bonus for unordered meals
    if (!orderedMealIds.has(meal.$id)) {
      score += 0.05
      if (!reason) reason = 'Something new to try'
    }

    if (score > 0.1) {
      scoredMeals.push({
        meal,
        score,
        reason: reason || 'Based on your preferences',
        reasonType: 'content_based',
        strategy: RECOMMENDATION_STRATEGIES.CONTENT_BASED,
        confidence: Math.min(confidence, 1),
      })
    }
  }

  return scoredMeals
}

// ============================================
// HYBRID FILTERING
// Combines collaborative + content-based + contextual
// ============================================

async function hybridFiltering(
  meals: Meals[],
  tasteProfile: UserTasteProfile | null,
  orderHistory: Orders[],
  similarities: UserSimilarity[],
  embeddings: MealEmbeddings[],
  dietaryProfile: DietaryProfiles | null,
  context: RecommendationContext,
): Promise<ScoredMeal[]> {
  // Get scores from both methods
  const collaborativeScores = await collaborativeFiltering(
    meals,
    similarities,
    dietaryProfile,
  )
  const contentScores = contentBasedFiltering(
    meals,
    tasteProfile,
    orderHistory,
    embeddings,
    dietaryProfile,
    context,
  )

  // Merge scores with weights
  const COLLABORATIVE_WEIGHT = 0.4
  const CONTENT_WEIGHT = 0.4
  const CONTEXTUAL_WEIGHT = 0.2

  const mealScores: Record<string, ScoredMeal> = {}

  // Add collaborative scores
  for (const sm of collaborativeScores) {
    mealScores[sm.meal.$id] = {
      ...sm,
      score: sm.score * COLLABORATIVE_WEIGHT,
    }
  }

  // Merge content-based scores
  for (const sm of contentScores) {
    if (mealScores[sm.meal.$id]) {
      mealScores[sm.meal.$id].score += sm.score * CONTENT_WEIGHT
      // Keep the more specific reason
      if (sm.confidence > mealScores[sm.meal.$id].confidence) {
        mealScores[sm.meal.$id].reason = sm.reason
        mealScores[sm.meal.$id].confidence = sm.confidence
      }
    } else {
      mealScores[sm.meal.$id] = {
        ...sm,
        score: sm.score * CONTENT_WEIGHT,
      }
    }
  }

  // Add contextual boosts
  for (const mealId of Object.keys(mealScores)) {
    const meal = mealScores[mealId].meal
    const contextScore = getContextualScore(meal, context)
    mealScores[mealId].score += contextScore * CONTEXTUAL_WEIGHT
    mealScores[mealId].strategy = RECOMMENDATION_STRATEGIES.HYBRID
  }

  // Add reorder suggestions with high priority
  const reorderSuggestions = getReorderSuggestions(
    meals,
    orderHistory,
    dietaryProfile,
  )
  for (const sm of reorderSuggestions) {
    if (mealScores[sm.meal.$id]) {
      mealScores[sm.meal.$id].score += 0.3 // Boost for past orders
      if (sm.score > 0.8) {
        mealScores[sm.meal.$id].reason = sm.reason
      }
    } else {
      mealScores[sm.meal.$id] = sm
    }
  }

  return Object.values(mealScores)
}

// ============================================
// CONTEXTUAL OFFERS ENGINE
// Smart add-on suggestions and time-based deals
// ============================================

export const getContextualOffersFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z.object({
      currentMealId: z.string().optional(),
      cartMealIds: z.array(z.string()).optional(),
      cartTotal: z.number().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    const now = new Date()
    const hour = now.getHours()
    const dayOfWeek = now.getDay()

    const offers: Array<{
      type: 'pairing' | 'addon' | 'time_deal' | 'upsell' | 'bundle'
      title: string
      description: string
      item?: Meals | AddOns
      discount?: { type: string; value: number }
      reason: string
      priority: number
      expiresAt?: string
    }> = []

    // Get active contextual offers
    const activeOffers = await db.contextualOffers.list([
      Query.equal('isActive', [true]),
      Query.lessThanEqual('validFrom', now.toISOString()),
      Query.greaterThanEqual('validUntil', now.toISOString()),
    ])

    // Get user's order history for personalization
    let orderHistory: Orders[] = []
    let tasteProfile: UserTasteProfile | null = null

    if (currentUser) {
      const [ordersResult, profileResult] = await Promise.all([
        db.orders.list([
          Query.equal('createdBy', [currentUser.$id]),
          Query.orderDesc('$createdAt'),
          Query.limit(50),
        ]),
        getTasteProfile(currentUser.$id),
      ])
      orderHistory = ordersResult.rows
      tasteProfile = profileResult
    }

    // 1. MEAL PAIRING SUGGESTIONS
    if (
      data.currentMealId ||
      (data.cartMealIds && data.cartMealIds.length > 0)
    ) {
      const mealIds = data.currentMealId
        ? [data.currentMealId]
        : data.cartMealIds || []

      for (const mealId of mealIds) {
        const pairings = await getMealPairings(
          mealId,
          orderHistory,
          currentUser?.$id,
        )
        for (const pairing of pairings.slice(0, 2)) {
          offers.push({
            type: 'pairing',
            title: `Perfect with ${pairing.item.name}`,
            description: pairing.reason,
            item: pairing.item,
            reason: pairing.reason,
            priority: pairing.score * 10,
          })
        }
      }
    }

    // 2. TIME-BASED DEALS
    const timeDeals = activeOffers.rows.filter((offer) => {
      if (offer.triggerType !== 'time') return false
      if (offer.triggerTimeStart && offer.triggerTimeEnd) {
        const startHour = parseInt(offer.triggerTimeStart.split(':')[0])
        const endHour = parseInt(offer.triggerTimeEnd.split(':')[0])
        return hour >= startHour && hour <= endHour
      }
      if (offer.triggerDaysOfWeek && offer.triggerDaysOfWeek.length > 0) {
        return offer.triggerDaysOfWeek.includes(dayOfWeek.toString())
      }
      return true
    })

    for (const deal of timeDeals.slice(0, 3)) {
      let item: Meals | AddOns | undefined
      if (deal.suggestedMealId) {
        try {
          item = await db.meals.get(deal.suggestedMealId)
        } catch {
          // Meal not found
        }
      } else if (deal.suggestedAddOnId) {
        try {
          item = await db.addOns.get(deal.suggestedAddOnId)
        } catch {
          // Add-on not found
        }
      }

      offers.push({
        type: 'time_deal',
        title: deal.title,
        description: deal.description || '',
        item,
        discount:
          deal.discountType && deal.discountValue
            ? { type: deal.discountType, value: deal.discountValue }
            : undefined,
        reason: getTimeDealReason(hour),
        priority: deal.priority || 5,
        expiresAt: deal.validUntil || undefined,
      })
    }

    // 3. PERSONALIZED ADD-ON SUGGESTIONS
    if (currentUser && orderHistory.length > 0) {
      const personalizedAddOns = await getPersonalizedAddOns(
        orderHistory,
        data.cartMealIds || [],
        tasteProfile,
      )

      for (const addon of personalizedAddOns.slice(0, 2)) {
        offers.push({
          type: 'addon',
          title: `Add ${addon.item.name}?`,
          description: addon.reason,
          item: addon.item,
          reason: addon.reason,
          priority: addon.score * 8,
        })
      }
    }

    // 4. INVENTORY-AWARE PROMOTIONS
    // Promote items with high stock that need to move
    const inventoryDeals = await getInventoryBasedDeals()
    for (const deal of inventoryDeals.slice(0, 2)) {
      offers.push({
        type: 'time_deal',
        title: `Today's Special: ${deal.meal.name}`,
        description: 'Fresh and ready!',
        item: deal.meal,
        discount: deal.discount,
        reason: 'Fresh stock available',
        priority: 6,
      })
    }

    // 5. UPSELL SUGGESTIONS
    if (data.cartTotal && data.cartTotal > 0) {
      const upsells = await getUpsellSuggestions(
        data.cartTotal,
        data.cartMealIds || [],
      )
      for (const upsell of upsells.slice(0, 1)) {
        offers.push({
          type: 'upsell',
          title: upsell.title,
          description: upsell.description,
          item: upsell.item,
          reason: upsell.reason,
          priority: 4,
        })
      }
    }

    // Sort by priority and return
    const sortedOffers = offers
      .sort((a, b) => b.priority - a.priority)
      .slice(0, 6)

    return {
      offers: sortedOffers,
      context: {
        time: now.toISOString(),
        hour,
        dayOfWeek,
      },
    }
  })

// ============================================
// USER TASTE PROFILE MANAGEMENT
// ============================================

export const getUserTasteProfileFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const profile = await getTasteProfile(currentUser.$id)
    return { profile }
  },
)

export const updateUserTasteProfileFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      preferredCuisines: z.array(z.string()).optional(),
      avoidedCuisines: z.array(z.string()).optional(),
      flavorPreferences: z.array(z.string()).optional(),
      spiceTolerance: z.number().min(0).max(5).optional(),
      preferredProteins: z.array(z.string()).optional(),
      avoidedIngredients: z.array(z.string()).optional(),
      preferredMealTimes: z.array(z.string()).optional(),
      preferredPortionSize: z.enum(['small', 'regular', 'large']).optional(),
      budgetPreference: z.enum(['budget', 'moderate', 'premium']).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if profile exists
    const existing = await db.userTasteProfile.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    const profileData = {
      preferredCuisines: data.preferredCuisines || null,
      avoidedCuisines: data.avoidedCuisines || null,
      flavorPreferences: data.flavorPreferences || null,
      spiceTolerance: data.spiceTolerance ?? null,
      preferredProteins: data.preferredProteins || null,
      avoidedIngredients: data.avoidedIngredients || null,
      preferredMealTimes: data.preferredMealTimes || null,
      preferredPortionSize: data.preferredPortionSize || null,
      budgetPreference: data.budgetPreference || null,
      lastUpdatedAt: new Date().toISOString(),
    }

    if (existing.rows.length > 0) {
      const profile = await db.userTasteProfile.update(
        existing.rows[0].$id,
        profileData,
      )
      return { profile }
    } else {
      const profile = await db.userTasteProfile.create({
        createdBy: currentUser.$id,
        ...profileData,
        avgOrderFrequency: null,
        tasteVector: null,
      })
      return { profile }
    }
  })

// ============================================
// SIMILARITY CALCULATION (for Collaborative Filtering)
// ============================================

export const calculateUserSimilaritiesFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const { currentUser } = await authMiddleware()
  if (!currentUser) throw new Error('Unauthorized')

  // Get current user's orders
  const userOrders = await db.orders.list([
    Query.equal('createdBy', [currentUser.$id]),
    Query.limit(100),
  ])

  if (userOrders.rows.length < 3) {
    return {
      message: 'Need more order history to calculate similarities',
      similarities: [],
    }
  }

  const userMealSet = new Set(userOrders.rows.flatMap((o) => o.mealIds))

  // Get other users' orders (in production, this would be batched/cached)
  const allOrders = await db.orders.list([
    Query.notEqual('createdBy', [currentUser.$id]),
    Query.limit(500),
  ])

  // Group orders by user
  const userOrderMap: Record<string, Set<string>> = {}
  for (const order of allOrders.rows) {
    if (!userOrderMap[order.createdBy]) {
      userOrderMap[order.createdBy] = new Set()
    }
    for (const mealId of order.mealIds) {
      userOrderMap[order.createdBy].add(mealId)
    }
  }

  // Calculate Jaccard similarity
  const similarities: Array<{
    userId: string
    score: number
    sharedCount: number
  }> = []

  for (const [otherUserId, otherMeals] of Object.entries(userOrderMap)) {
    const intersection = new Set(
      [...userMealSet].filter((m) => otherMeals.has(m)),
    )
    const union = new Set([...userMealSet, ...otherMeals])

    if (intersection.size >= 2) {
      const jaccardScore = intersection.size / union.size
      similarities.push({
        userId: otherUserId,
        score: jaccardScore,
        sharedCount: intersection.size,
      })
    }
  }

  // Sort and keep top 20
  const topSimilarities = similarities
    .sort((a, b) => b.score - a.score)
    .slice(0, 20)

  // Store similarities
  // First, delete old similarities
  const oldSimilarities = await db.userSimilarity.list([
    Query.equal('createdBy', [currentUser.$id]),
  ])
  await Promise.all(
    oldSimilarities.rows.map((s) => db.userSimilarity.delete(s.$id)),
  )

  // Create new similarities
  await Promise.all(
    topSimilarities.map((sim) =>
      db.userSimilarity.create({
        createdBy: currentUser.$id,
        similarUserId: sim.userId,
        similarityScore: sim.score,
        algorithmVersion: 'jaccard_v1',
        sharedMealCount: sim.sharedCount,
        calculatedAt: new Date().toISOString(),
      }),
    ),
  )

  return {
    message: `Calculated ${topSimilarities.length} similar users`,
    similarities: topSimilarities,
  }
})

// ============================================
// RECORD OFFER IMPRESSION
// ============================================

export const recordOfferImpressionFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      offerId: z.string(),
      impressionType: z.enum(['shown', 'clicked', 'dismissed']),
      wasAccepted: z.boolean(),
      wasDismissed: z.boolean(),
      contextMealId: z.string().optional(),
      resultingOrderId: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const impression = await db.offerImpressions.create({
      createdBy: currentUser.$id,
      offerId: data.offerId,
      impressionType: data.impressionType,
      wasAccepted: data.wasAccepted,
      wasDismissed: data.wasDismissed,
      resultingOrderId: data.resultingOrderId || null,
      contextMealId: data.contextMealId || null,
      displayedAt: new Date().toISOString(),
      respondedAt:
        data.wasAccepted || data.wasDismissed ? new Date().toISOString() : null,
    })

    return { impression }
  })

// ============================================
// HELPER FUNCTIONS
// ============================================

async function getDietaryProfile(
  userId: string,
): Promise<DietaryProfiles | null> {
  try {
    const profiles = await db.dietaryProfiles.list([
      Query.equal('createdBy', [userId]),
      Query.limit(1),
    ])
    return profiles.rows[0] || null
  } catch {
    return null
  }
}

async function getTasteProfile(
  userId: string,
): Promise<UserTasteProfile | null> {
  try {
    const profiles = await db.userTasteProfile.list([
      Query.equal('createdBy', [userId]),
      Query.limit(1),
    ])
    return profiles.rows[0] || null
  } catch {
    return null
  }
}

async function getOrderHistory(userId: string): Promise<Orders[]> {
  try {
    const orders = await db.orders.list([
      Query.equal('createdBy', [userId]),
      Query.orderDesc('$createdAt'),
      Query.limit(50),
    ])
    return orders.rows
  } catch {
    return []
  }
}

async function getUserSimilarities(userId: string): Promise<UserSimilarity[]> {
  try {
    const similarities = await db.userSimilarity.list([
      Query.equal('createdBy', [userId]),
      Query.orderDesc('similarityScore'),
      Query.limit(20),
    ])
    return similarities.rows
  } catch {
    return []
  }
}

async function getMealEmbeddings(): Promise<MealEmbeddings[]> {
  try {
    const embeddings = await db.mealEmbeddings.list([Query.limit(200)])
    return embeddings.rows
  } catch {
    return []
  }
}

function passesAllergenFilter(
  meal: Meals,
  profile: DietaryProfiles | null,
): boolean {
  if (!profile?.allergens || profile.allergens.length === 0) return true
  if (!meal.allergens) return true

  return !profile.allergens.some((allergen) =>
    meal.allergens?.some((ma) =>
      ma.toLowerCase().includes(allergen.toLowerCase()),
    ),
  )
}

function passesDietaryFilter(
  _meal: Meals,
  profile: DietaryProfiles | null,
): boolean {
  if (!profile?.dietaryRestrictions || profile.dietaryRestrictions.length === 0)
    return true
  // In production, this would check meal tags/ingredients against restrictions
  return true
}

function passesDislikesFilter(
  meal: Meals,
  profile: DietaryProfiles | null,
): boolean {
  if (!profile?.dislikes || profile.dislikes.length === 0) return true

  const mealText = `${meal.name} ${meal.description || ''}`.toLowerCase()
  return !profile.dislikes.some((dislike) =>
    mealText.includes(dislike.toLowerCase()),
  )
}

function calculateTasteMatch(
  _meal: Meals,
  tasteProfile: UserTasteProfile,
  embeddings: MealEmbeddings[],
): number {
  let score = 0
  const embedding = embeddings.find((e) => e.mealId === _meal.$id)

  // Cuisine match
  if (tasteProfile.preferredCuisines && embedding?.cuisineType) {
    if (tasteProfile.preferredCuisines.includes(embedding.cuisineType)) {
      score += 0.3
    }
  }

  // Avoided cuisines
  if (tasteProfile.avoidedCuisines && embedding?.cuisineType) {
    if (tasteProfile.avoidedCuisines.includes(embedding.cuisineType)) {
      return 0 // Exclude entirely
    }
  }

  // Spice tolerance
  if (
    tasteProfile.spiceTolerance !== null &&
    embedding?.spiceLevel !== null &&
    embedding
  ) {
    const spiceDiff = Math.abs(
      (tasteProfile.spiceTolerance || 2) - (embedding.spiceLevel || 2),
    )
    score += Math.max(0, 0.2 - spiceDiff * 0.05)
  }

  // Flavor profile match
  if (tasteProfile.flavorPreferences && embedding?.flavorProfile) {
    const matches = tasteProfile.flavorPreferences.filter((f) =>
      embedding.flavorProfile?.includes(f),
    ).length
    score += Math.min(matches * 0.1, 0.3)
  }

  // Budget preference
  if (tasteProfile.budgetPreference) {
    const priceThresholds = { budget: 10, moderate: 20, premium: Infinity }
    const threshold =
      priceThresholds[
        tasteProfile.budgetPreference as keyof typeof priceThresholds
      ]
    if (_meal.price <= threshold) {
      score += 0.1
    }
  }

  return Math.min(score, 1)
}

function getTimeBasedScore(
  meal: Meals,
  context: RecommendationContext,
): number {
  const hour = context.currentTime.getHours()
  const category = meal.category?.toLowerCase() || ''
  const calories = meal.calories || 500

  // Morning (6-11)
  if (hour >= 6 && hour < 11) {
    if (category.includes('breakfast') || category.includes('coffee'))
      return 0.9
    if (calories < 400) return 0.6
    return 0.3
  }

  // Lunch (11-14)
  if (hour >= 11 && hour < 14) {
    if (
      category.includes('main') ||
      category.includes('bowl') ||
      category.includes('sandwich')
    )
      return 0.9
    if (calories >= 400 && calories <= 800) return 0.7
    return 0.4
  }

  // Afternoon (14-17)
  if (hour >= 14 && hour < 17) {
    if (
      category.includes('snack') ||
      category.includes('drink') ||
      category.includes('dessert')
    )
      return 0.9
    if (calories < 300) return 0.7
    return 0.3
  }

  // Dinner (17-21)
  if (hour >= 17 && hour < 21) {
    if (category.includes('main') || category.includes('dinner')) return 0.9
    if (calories >= 500) return 0.7
    return 0.4
  }

  // Late night
  if (calories < 400) return 0.7
  return 0.4
}

function getTimeBasedReason(hour: number): string {
  if (hour >= 6 && hour < 11) return 'Perfect for breakfast'
  if (hour >= 11 && hour < 14) return 'Great lunch option'
  if (hour >= 14 && hour < 17) return 'Afternoon pick-me-up'
  if (hour >= 17 && hour < 21) return 'Ideal for dinner'
  return 'Light late-night option'
}

function getContextualScore(
  meal: Meals,
  context: RecommendationContext,
): number {
  let score = getTimeBasedScore(meal, context)

  // Lunch rush boost for quick meals
  if (context.isLunchRush && meal.category?.toLowerCase().includes('quick')) {
    score += 0.1
  }

  // Afternoon slump - boost energizing items
  if (context.isAfternoonSlump) {
    if (
      meal.category?.toLowerCase().includes('coffee') ||
      meal.category?.toLowerCase().includes('snack')
    ) {
      score += 0.15
    }
  }

  return Math.min(score, 1)
}

function getReorderSuggestions(
  meals: Meals[],
  orderHistory: Orders[],
  dietaryProfile: DietaryProfiles | null,
): ScoredMeal[] {
  const mealOrderCount: Record<string, number> = {}
  const recentMealIds = new Set<string>()

  // Count meal frequencies and track recent orders
  for (let i = 0; i < orderHistory.length; i++) {
    const order = orderHistory[i]
    for (const mealId of order.mealIds) {
      mealOrderCount[mealId] = (mealOrderCount[mealId] || 0) + 1
      if (i < 5) recentMealIds.add(mealId) // Last 5 orders
    }
  }

  const suggestions: ScoredMeal[] = []

  for (const meal of meals) {
    if (!passesAllergenFilter(meal, dietaryProfile)) continue

    const orderCount = mealOrderCount[meal.$id] || 0
    if (orderCount >= 2) {
      const isRecent = recentMealIds.has(meal.$id)
      suggestions.push({
        meal,
        score: Math.min(orderCount / 5, 1) * (isRecent ? 0.9 : 0.7),
        reason: isRecent
          ? 'One of your recent favorites'
          : `You've ordered this ${orderCount} times`,
        reasonType: 'reorder',
        strategy: RECOMMENDATION_STRATEGIES.CONTENT_BASED,
        confidence: Math.min(0.5 + orderCount * 0.1, 0.95),
      })
    }
  }

  return suggestions
}

async function anonymousRecommendations(
  meals: Meals[],
  context: RecommendationContext,
): Promise<ScoredMeal[]> {
  // For anonymous users, use time-based and popularity
  return meals.map((meal, idx) => {
    const timeScore = getTimeBasedScore(meal, context)
    const popularityScore = Math.max(0, 1 - idx * 0.05) // Assume meals are somewhat ordered by popularity

    return {
      meal,
      score: timeScore * 0.6 + popularityScore * 0.4,
      reason: getTimeBasedReason(context.currentTime.getHours()),
      reasonType: 'time_based',
      strategy: RECOMMENDATION_STRATEGIES.TIME_CONTEXTUAL,
      confidence: 0.5,
    }
  })
}

async function getMealPairings(
  mealId: string,
  orderHistory: Orders[],
  userId?: string,
): Promise<Array<{ item: Meals | AddOns; reason: string; score: number }>> {
  const pairings: Array<{
    item: Meals | AddOns
    reason: string
    score: number
  }> = []

  // Get stored pairing rules
  const rules = await db.mealPairingRules.list([
    Query.equal('primaryMealId', [mealId]),
    Query.orderDesc('pairingScore'),
    Query.limit(10),
  ])

  for (const rule of rules.rows) {
    try {
      if (rule.pairedItemType === 'meal') {
        const meal = await db.meals.get(rule.pairedItemId)
        if (meal.isAvailable) {
          pairings.push({
            item: meal,
            reason: rule.pairingReason || 'Great combination',
            score: rule.pairingScore || 0.7,
          })
        }
      } else if (rule.pairedItemType === 'addon') {
        const addon = await db.addOns.get(rule.pairedItemId)
        if (addon.isAvailable) {
          pairings.push({
            item: addon,
            reason: rule.pairingReason || 'Popular add-on',
            score: rule.pairingScore || 0.6,
          })
        }
      }
    } catch {
      // Item not found
    }
  }

  // Add personalized pairings from order history
  if (userId && orderHistory.length > 0) {
    const ordersWithMeal = orderHistory.filter((o) =>
      o.mealIds.includes(mealId),
    )
    const coOrderedMeals: Record<string, number> = {}

    for (const order of ordersWithMeal) {
      for (const otherMealId of order.mealIds) {
        if (otherMealId !== mealId) {
          coOrderedMeals[otherMealId] = (coOrderedMeals[otherMealId] || 0) + 1
        }
      }
    }

    for (const [otherMealId, count] of Object.entries(coOrderedMeals)) {
      if (
        count >= 2 &&
        !pairings.find((p) => 'mealId' in p.item && p.item.$id === otherMealId)
      ) {
        try {
          const meal = await db.meals.get(otherMealId)
          if (meal.isAvailable) {
            pairings.push({
              item: meal,
              reason: `You've paired these ${count} times before`,
              score: Math.min(count / 5 + 0.5, 0.9),
            })
          }
        } catch {
          // Meal not found
        }
      }
    }
  }

  return pairings.sort((a, b) => b.score - a.score)
}

async function getPersonalizedAddOns(
  orderHistory: Orders[],
  _cartMealIds: string[],
  tasteProfile: UserTasteProfile | null,
): Promise<Array<{ item: AddOns; reason: string; score: number }>> {
  const addOns = await db.addOns.list([Query.equal('isAvailable', [true])])
  const suggestions: Array<{ item: AddOns; reason: string; score: number }> = []

  // Get order items to see past add-on usage
  const orderIds = orderHistory.slice(0, 20).map((o) => o.$id)
  let orderItems: Array<{ addOns: string[] | null }> = []

  if (orderIds.length > 0) {
    const itemsResult = await db.orderItems.list([
      Query.equal('orderId', orderIds),
    ])
    orderItems = itemsResult.rows
  }

  // Count add-on usage
  const addOnUsage: Record<string, number> = {}
  for (const item of orderItems) {
    if (item.addOns) {
      for (const addOnId of item.addOns) {
        addOnUsage[addOnId] = (addOnUsage[addOnId] || 0) + 1
      }
    }
  }

  for (const addOn of addOns.rows) {
    const usageCount = addOnUsage[addOn.$id] || 0
    let score = 0
    let reason = ''

    if (usageCount >= 3) {
      score = Math.min(usageCount / 10 + 0.5, 0.9)
      reason = `You've added this ${usageCount} times`
    } else if (usageCount > 0) {
      score = 0.4
      reason = 'You might like this'
    } else {
      // Check if it matches taste profile
      if (tasteProfile?.flavorPreferences) {
        // Simple matching - in production would use embeddings
        score = 0.3
        reason = 'Matches your taste'
      }
    }

    if (score > 0.2) {
      suggestions.push({ item: addOn, reason, score })
    }
  }

  return suggestions.sort((a, b) => b.score - a.score)
}

async function getInventoryBasedDeals(): Promise<
  Array<{ meal: Meals; discount: { type: string; value: number } }>
> {
  // Get meals with high inventory that should be promoted
  const deals: Array<{
    meal: Meals
    discount: { type: string; value: number }
  }> = []

  try {
    // Get inventory items with high stock
    const inventory = await db.inventory.list([
      Query.greaterThan('quantityInStock', [50]),
      Query.limit(10),
    ])

    // Get meal ingredients to find which meals use these ingredients
    for (const inv of inventory.rows) {
      const mealIngredients = await db.mealIngredients.list([
        Query.equal('ingredientId', [inv.ingredientId]),
        Query.limit(5),
      ])

      for (const mi of mealIngredients.rows) {
        try {
          const meal = await db.meals.get(mi.mealId)
          if (meal.isAvailable && !deals.find((d) => d.meal.$id === meal.$id)) {
            deals.push({
              meal,
              discount: { type: 'percentage', value: 10 },
            })
          }
        } catch {
          // Meal not found
        }
      }
    }
  } catch {
    // Inventory query failed
  }

  return deals.slice(0, 3)
}

async function getUpsellSuggestions(
  cartTotal: number,
  _cartMealIds: string[],
): Promise<
  Array<{ title: string; description: string; item: Meals; reason: string }>
> {
  const suggestions: Array<{
    title: string
    description: string
    item: Meals
    reason: string
  }> = []

  // Suggest items to reach free delivery threshold (example: $25)
  const freeDeliveryThreshold = 25
  if (cartTotal < freeDeliveryThreshold) {
    const remaining = freeDeliveryThreshold - cartTotal
    const meals = await db.meals.list([
      Query.equal('isAvailable', [true]),
      Query.lessThanEqual('price', [remaining + 5]),
      Query.greaterThanEqual('price', [remaining - 2]),
      Query.limit(5),
    ])

    for (const meal of meals.rows) {
      if (!_cartMealIds.includes(meal.$id)) {
        suggestions.push({
          title: `Add ${meal.name} for free delivery!`,
          description: `Just $${remaining.toFixed(2)} away from free delivery`,
          item: meal,
          reason: 'Reach free delivery threshold',
        })
        break
      }
    }
  }

  return suggestions
}

function getTimeDealReason(hour: number): string {
  if (hour >= 14 && hour < 17) return '☕ Afternoon special'
  if (hour >= 17 && hour < 19) return '🌅 Happy hour deal'
  if (hour >= 11 && hour < 14) return '🍽️ Lunch rush special'
  return '⭐ Limited time offer'
}
