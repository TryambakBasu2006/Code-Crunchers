import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'

// ============================================
// USER NOTIFICATION FUNCTIONS
// ============================================

// Get user's notifications
export const getNotificationsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        unreadOnly: z.boolean().optional(),
        limit: z.number().min(1).max(50).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [
      Query.equal('createdBy', [currentUser.$id]),
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 20),
    ]

    if (data?.unreadOnly) {
      queries.push(Query.equal('isRead', [false]))
    }

    const notifications = await db.notifications.list(queries)

    return {
      notifications: notifications.rows,
      total: notifications.total,
      unreadCount: notifications.rows.filter((n) => !n.isRead).length,
    }
  })

// Mark notification as read
export const markNotificationReadFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ notificationId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const notification = await db.notifications.get(data.notificationId)

    if (notification.createdBy !== currentUser.$id) {
      throw new Error('Notification not found')
    }

    await db.notifications.update(data.notificationId, {
      isRead: true,
    })

    return { success: true }
  })

// Mark all notifications as read
export const markAllNotificationsReadFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const { currentUser } = await authMiddleware()
  if (!currentUser) throw new Error('Unauthorized')

  const unreadNotifications = await db.notifications.list([
    Query.equal('createdBy', [currentUser.$id]),
    Query.equal('isRead', [false]),
  ])

  await Promise.all(
    unreadNotifications.rows.map((n) =>
      db.notifications.update(n.$id, { isRead: true }),
    ),
  )

  return { success: true, count: unreadNotifications.rows.length }
})

// Delete a notification
export const deleteNotificationFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ notificationId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const notification = await db.notifications.get(data.notificationId)

    if (notification.createdBy !== currentUser.$id) {
      throw new Error('Notification not found')
    }

    await db.notifications.delete(data.notificationId)

    return { success: true }
  })

// ============================================
// ADMIN NOTIFICATION FUNCTIONS
// ============================================

// Send notification to a user (admin)
export const sendNotificationFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      userId: z.string(),
      type: z.string(),
      title: z.string().max(200),
      message: z.string().max(1000),
      orderId: z.string().optional(),
      channel: z.enum(['in_app', 'push', 'email', 'sms']).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    const notification = await db.notifications.create({
      createdBy: data.userId,
      orderId: data.orderId || null,
      type: data.type,
      title: data.title,
      message: data.message,
      isRead: false,
      channel: data.channel || 'in_app',
      sentAt: new Date().toISOString(),
    })

    // TODO: If channel is 'push', 'email', or 'sms', trigger external service
    // This would require integration with:
    // - Firebase Cloud Messaging for push notifications
    // - SendGrid/Mailgun for email
    // - Twilio for SMS

    return { notification }
  })

// Broadcast notification to all users (admin)
export const broadcastNotificationFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      type: z.string(),
      title: z.string().max(200),
      message: z.string().max(1000),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check
    // TODO: Get all user IDs and create notifications for each
    // This is a simplified version - in production, use a queue

    // For now, just create a system notification
    const notification = await db.notifications.create({
      createdBy: 'system',
      orderId: null,
      type: data.type,
      title: data.title,
      message: data.message,
      isRead: false,
      channel: 'in_app',
      sentAt: new Date().toISOString(),
    })

    return { notification }
  })

// ============================================
// NOTIFICATION TYPES
// ============================================

export const NOTIFICATION_TYPES = {
  ORDER_CONFIRMED: 'order_confirmed',
  ORDER_PREPARING: 'order_preparing',
  ORDER_READY: 'order_ready',
  ORDER_CANCELLED: 'order_cancelled',
  PROMOTION: 'promotion',
  DAILY_SPECIAL: 'daily_special',
  SYSTEM: 'system',
} as const
