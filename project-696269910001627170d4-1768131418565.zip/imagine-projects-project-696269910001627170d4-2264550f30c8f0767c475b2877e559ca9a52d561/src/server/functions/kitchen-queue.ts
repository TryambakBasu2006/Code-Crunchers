import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { KitchenQueue, OrderItems, Orders } from '../lib/appwrite.types'

// ============================================
// KITCHEN QUEUE MANAGEMENT
// ============================================

// Queue status types
export const QUEUE_STATUSES = {
  QUEUED: 'queued',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  ON_HOLD: 'on_hold',
} as const

export type QueueStatus = (typeof QUEUE_STATUSES)[keyof typeof QUEUE_STATUSES]

// Kitchen stations
export const KITCHEN_STATIONS = {
  GRILL: 'grill',
  FRY: 'fry',
  SALAD: 'salad',
  DRINKS: 'drinks',
  DESSERT: 'dessert',
  ASSEMBLY: 'assembly',
} as const

// Get kitchen queue
export const getKitchenQueueFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        station: z.string().optional(),
        status: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [
      Query.orderAsc('displayPosition'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.station) {
      queries.push(Query.equal('station', [data.station]))
    }

    if (data?.status) {
      queries.push(Query.equal('status', [data.status]))
    } else {
      // By default, show non-completed items
      queries.push(Query.notEqual('status', ['completed']))
    }

    const queue = await db.kitchenQueue.list(queries)

    // Get order details for each queue item
    const orderIds = [...new Set(queue.rows.map((q) => q.orderId))]
    let orders: Orders[] = []
    if (orderIds.length > 0) {
      const ordersResult = await db.orders.list([Query.equal('$id', orderIds)])
      orders = ordersResult.rows
    }

    // Get order items
    const orderItemIds = queue.rows
      .map((q) => q.orderItemId)
      .filter(Boolean) as string[]
    let orderItems: OrderItems[] = []
    if (orderItemIds.length > 0) {
      const itemsResult = await db.orderItems.list([
        Query.equal('$id', orderItemIds),
      ])
      orderItems = itemsResult.rows
    }

    // Enrich queue items
    const enrichedQueue = queue.rows.map((queueItem) => ({
      ...queueItem,
      order: orders.find((o) => o.$id === queueItem.orderId),
      orderItem: orderItems.find((i) => i.$id === queueItem.orderItemId),
    }))

    return { queue: enrichedQueue, total: queue.total }
  })

// Add order to kitchen queue
export const addToKitchenQueueFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      orderId: z.string(),
      orderItemId: z.string().optional(),
      station: z.string().optional(),
      priority: z.number().min(1).max(10).optional(),
      estimatedPrepTime: z.number().positive().optional(), // in minutes
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get current max display position
    const existingQueue = await db.kitchenQueue.list([
      Query.orderDesc('displayPosition'),
      Query.limit(1),
    ])

    const nextPosition =
      existingQueue.rows.length > 0
        ? (existingQueue.rows[0].displayPosition || 0) + 1
        : 1

    const queueItem = await db.kitchenQueue.create({
      createdBy: currentUser.$id,
      orderId: data.orderId,
      orderItemId: data.orderItemId || null,
      station: data.station || null,
      status: QUEUE_STATUSES.QUEUED,
      priority: data.priority || 5,
      assignedTo: null,
      estimatedPrepTime: data.estimatedPrepTime || null,
      startedAt: null,
      completedAt: null,
      displayPosition: nextPosition,
    })

    return { queueItem }
  })

// Update queue item status
export const updateQueueStatusFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      queueItemId: z.string(),
      status: z.enum(['queued', 'in_progress', 'completed', 'on_hold']),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Partial<
      Omit<KitchenQueue, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {
      status: data.status,
    }

    if (data.status === QUEUE_STATUSES.IN_PROGRESS) {
      updates.startedAt = new Date().toISOString()
      updates.assignedTo = currentUser.$id
    }

    if (data.status === QUEUE_STATUSES.COMPLETED) {
      updates.completedAt = new Date().toISOString()
    }

    const queueItem = await db.kitchenQueue.update(data.queueItemId, updates)

    return { queueItem }
  })

// Assign queue item to staff
export const assignQueueItemFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      queueItemId: z.string(),
      assignedTo: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queueItem = await db.kitchenQueue.update(data.queueItemId, {
      assignedTo: data.assignedTo,
    })

    return { queueItem }
  })

// Reorder queue items (drag and drop)
export const reorderQueueFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      queueItemId: z.string(),
      newPosition: z.number().positive(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get the item being moved
    const item = await db.kitchenQueue.get(data.queueItemId)
    const oldPosition = item.displayPosition || 0

    // Get all items that need to be shifted
    const allItems = await db.kitchenQueue.list([
      Query.notEqual('status', ['completed']),
      Query.orderAsc('displayPosition'),
    ])

    // Update positions
    for (const queueItem of allItems.rows) {
      const currentPos = queueItem.displayPosition || 0
      let newPos = currentPos

      if (queueItem.$id === data.queueItemId) {
        newPos = data.newPosition
      } else if (oldPosition < data.newPosition) {
        // Moving down: shift items up
        if (currentPos > oldPosition && currentPos <= data.newPosition) {
          newPos = currentPos - 1
        }
      } else if (oldPosition > data.newPosition) {
        // Moving up: shift items down
        if (currentPos >= data.newPosition && currentPos < oldPosition) {
          newPos = currentPos + 1
        }
      }

      if (newPos !== currentPos) {
        await db.kitchenQueue.update(queueItem.$id, {
          displayPosition: newPos,
        })
      }
    }

    return { success: true }
  })

// Update priority
export const updateQueuePriorityFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      queueItemId: z.string(),
      priority: z.number().min(1).max(10),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queueItem = await db.kitchenQueue.update(data.queueItemId, {
      priority: data.priority,
    })

    return { queueItem }
  })

// Move to different station
export const changeQueueStationFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      queueItemId: z.string(),
      station: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queueItem = await db.kitchenQueue.update(data.queueItemId, {
      station: data.station,
    })

    return { queueItem }
  })

// Remove from queue
export const removeFromQueueFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ queueItemId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.kitchenQueue.delete(data.queueItemId)

    return { success: true }
  })

// Get queue statistics
export const getQueueStatsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const allItems = await db.kitchenQueue.list([])

    const stats = {
      total: allItems.total,
      queued: allItems.rows.filter((i) => i.status === QUEUE_STATUSES.QUEUED)
        .length,
      inProgress: allItems.rows.filter(
        (i) => i.status === QUEUE_STATUSES.IN_PROGRESS,
      ).length,
      completed: allItems.rows.filter(
        (i) => i.status === QUEUE_STATUSES.COMPLETED,
      ).length,
      onHold: allItems.rows.filter((i) => i.status === QUEUE_STATUSES.ON_HOLD)
        .length,
      byStation: {} as Record<string, number>,
      avgPrepTime: 0,
    }

    // Count by station
    for (const item of allItems.rows) {
      if (item.station) {
        stats.byStation[item.station] = (stats.byStation[item.station] || 0) + 1
      }
    }

    // Calculate average prep time for completed items
    const completedItems = allItems.rows.filter(
      (i) =>
        i.status === QUEUE_STATUSES.COMPLETED && i.startedAt && i.completedAt,
    )

    if (completedItems.length > 0) {
      const totalPrepTime = completedItems.reduce((sum, item) => {
        const start = new Date(item.startedAt!).getTime()
        const end = new Date(item.completedAt!).getTime()
        return sum + (end - start)
      }, 0)
      stats.avgPrepTime = Math.round(
        totalPrepTime / completedItems.length / 60000,
      ) // in minutes
    }

    return { stats }
  },
)

// Auto-queue order items when order is confirmed
export const autoQueueOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ orderId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get order items
    const orderItems = await db.orderItems.list([
      Query.equal('orderId', [data.orderId]),
    ])

    // Get current max position
    const existingQueue = await db.kitchenQueue.list([
      Query.orderDesc('displayPosition'),
      Query.limit(1),
    ])

    let nextPosition =
      existingQueue.rows.length > 0
        ? (existingQueue.rows[0].displayPosition || 0) + 1
        : 1

    // Create queue items for each order item
    const queueItems = []
    for (const item of orderItems.rows) {
      const queueItem = await db.kitchenQueue.create({
        createdBy: currentUser.$id,
        orderId: data.orderId,
        orderItemId: item.$id,
        station: null, // Can be assigned later based on meal type
        status: QUEUE_STATUSES.QUEUED,
        priority: 5,
        assignedTo: null,
        estimatedPrepTime: null,
        startedAt: null,
        completedAt: null,
        displayPosition: nextPosition++,
      })
      queueItems.push(queueItem)
    }

    return { queueItems }
  })
