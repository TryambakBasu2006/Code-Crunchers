import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'

// ============================================
// REAL-TIME INVENTORY TRACKING
// ============================================

// Alert types for inventory events
export const ALERT_TYPES = {
  LOW_STOCK: 'low_stock',
  OUT_OF_STOCK: 'out_of_stock',
  RESTOCKED: 'restocked',
  EXPIRING_SOON: 'expiring_soon',
} as const

export type AlertType = (typeof ALERT_TYPES)[keyof typeof ALERT_TYPES]

// Get real-time availability for all meals
export const getMealAvailabilityFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        mealIds: z.array(z.string()).optional(),
        includeUnavailable: z.boolean().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const queries: string[] = []

    if (data?.mealIds && data.mealIds.length > 0) {
      queries.push(Query.equal('mealId', data.mealIds))
    }

    if (!data?.includeUnavailable) {
      queries.push(Query.equal('isAvailable', [true]))
    }

    const availability = await db.mealAvailability.list(queries)

    return {
      availability: availability.rows,
      total: availability.total,
    }
  })

// Check and update meal availability based on current inventory
export const syncMealAvailabilityFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get meal ingredients
    const mealIngredients = await db.mealIngredients.list([
      Query.equal('mealId', [data.mealId]),
    ])

    if (mealIngredients.rows.length === 0) {
      // No ingredients defined, assume available
      return await upsertMealAvailability(currentUser.$id, data.mealId, {
        isAvailable: true,
        availableQuantity: null,
        unavailableReason: null,
        missingIngredients: null,
      })
    }

    // Get inventory for all required ingredients
    const ingredientIds = mealIngredients.rows.map((mi) => mi.ingredientId)
    const inventory = await db.inventory.list([
      Query.equal('ingredientId', ingredientIds),
    ])

    // Check each required ingredient
    const missingIngredients: string[] = []
    let minServings = Infinity

    for (const mi of mealIngredients.rows) {
      if (mi.isOptional) continue

      const inv = inventory.rows.find((i) => i.ingredientId === mi.ingredientId)
      const available = inv?.quantityInStock || 0

      if (available < mi.quantityRequired) {
        missingIngredients.push(mi.ingredientId)
      } else {
        // Calculate how many servings we can make
        const servings = Math.floor(available / mi.quantityRequired)
        minServings = Math.min(minServings, servings)
      }
    }

    const isAvailable = missingIngredients.length === 0
    const availableQuantity =
      isAvailable && minServings !== Infinity ? minServings : 0

    const result = await upsertMealAvailability(currentUser.$id, data.mealId, {
      isAvailable,
      availableQuantity,
      unavailableReason: !isAvailable ? 'Missing required ingredients' : null,
      missingIngredients:
        missingIngredients.length > 0 ? missingIngredients : null,
    })

    // Create alert if meal became unavailable
    if (!isAvailable) {
      await createInventoryAlert(currentUser.$id, {
        ingredientId: missingIngredients[0],
        mealId: data.mealId,
        alertType: ALERT_TYPES.OUT_OF_STOCK,
        currentQuantity: 0,
      })
    }

    return result
  })

// Sync all meals availability (batch operation)
export const syncAllMealsAvailabilityFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const { currentUser } = await authMiddleware()
  if (!currentUser) throw new Error('Unauthorized')

  // Get all available meals
  const meals = await db.meals.list([Query.equal('isAvailable', [true])])

  const results: Array<{ mealId: string; isAvailable: boolean }> = []

  for (const meal of meals.rows) {
    try {
      const result = await syncMealAvailabilityFn({
        data: { mealId: meal.$id },
      })
      results.push({
        mealId: meal.$id,
        isAvailable: result.availability.isAvailable,
      })
    } catch (error) {
      console.error(`Failed to sync availability for meal ${meal.$id}:`, error)
    }
  }

  const unavailableCount = results.filter((r) => !r.isAvailable).length

  return {
    synced: results.length,
    unavailable: unavailableCount,
    results,
  }
})

// Get inventory alerts
export const getInventoryAlertsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        unresolvedOnly: z.boolean().optional(),
        alertType: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries: string[] = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.unresolvedOnly) {
      queries.push(Query.equal('isResolved', [false]))
    }

    if (data?.alertType) {
      queries.push(Query.equal('alertType', [data.alertType]))
    }

    const alerts = await db.inventoryAlerts.list(queries)

    return { alerts: alerts.rows, total: alerts.total }
  })

// Resolve an inventory alert
export const resolveInventoryAlertFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ alertId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const alert = await db.inventoryAlerts.update(data.alertId, {
      isResolved: true,
      resolvedAt: new Date().toISOString(),
      resolvedBy: currentUser.$id,
    })

    return { alert }
  })

// ============================================
// THROTTLING & RATE LIMITING
// ============================================

// In-memory rate limiting store (in production, use Redis)
const rateLimitStore = new Map<string, { count: number; resetAt: number }>()

// Rate limit configuration
const RATE_LIMITS = {
  orders: { maxRequests: 10, windowMs: 60000 }, // 10 orders per minute
  availability: { maxRequests: 100, windowMs: 60000 }, // 100 checks per minute
  default: { maxRequests: 50, windowMs: 60000 },
}

export const checkRateLimitFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      action: z.enum(['orders', 'availability', 'default']),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const key = `${currentUser.$id}:${data.action}`
    const limit = RATE_LIMITS[data.action]
    const now = Date.now()

    const current = rateLimitStore.get(key)

    if (!current || now > current.resetAt) {
      // Reset window
      rateLimitStore.set(key, { count: 1, resetAt: now + limit.windowMs })
      return { allowed: true, remaining: limit.maxRequests - 1 }
    }

    if (current.count >= limit.maxRequests) {
      return {
        allowed: false,
        remaining: 0,
        retryAfter: Math.ceil((current.resetAt - now) / 1000),
      }
    }

    current.count++
    rateLimitStore.set(key, current)

    return { allowed: true, remaining: limit.maxRequests - current.count }
  })

// ============================================
// INVENTORY-AWARE ORDER VALIDATION
// ============================================

export const validateOrderInventoryFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      items: z.array(
        z.object({
          mealId: z.string(),
          quantity: z.number().positive(),
        }),
      ),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const validationResults: Array<{
      mealId: string
      isAvailable: boolean
      requestedQuantity: number
      availableQuantity: number | null
      reason?: string
    }> = []

    for (const item of data.items) {
      // Check meal availability
      const availability = await db.mealAvailability.list([
        Query.equal('mealId', [item.mealId]),
        Query.limit(1),
      ])

      if (availability.rows.length === 0) {
        // No availability record, check ingredients directly
        const mealIngredients = await db.mealIngredients.list([
          Query.equal('mealId', [item.mealId]),
        ])

        if (mealIngredients.rows.length === 0) {
          validationResults.push({
            mealId: item.mealId,
            isAvailable: true,
            requestedQuantity: item.quantity,
            availableQuantity: null,
          })
          continue
        }

        // Check each ingredient
        let canFulfill = true
        for (const mi of mealIngredients.rows) {
          if (mi.isOptional) continue

          const inventory = await db.inventory.list([
            Query.equal('ingredientId', [mi.ingredientId]),
            Query.limit(1),
          ])

          const available = inventory.rows[0]?.quantityInStock || 0
          const required = mi.quantityRequired * item.quantity

          if (available < required) {
            canFulfill = false
            break
          }
        }

        validationResults.push({
          mealId: item.mealId,
          isAvailable: canFulfill,
          requestedQuantity: item.quantity,
          availableQuantity: null,
          reason: !canFulfill ? 'Insufficient ingredients' : undefined,
        })
      } else {
        const avail = availability.rows[0]
        const canFulfill =
          avail.isAvailable &&
          (avail.availableQuantity === null ||
            avail.availableQuantity >= item.quantity)

        validationResults.push({
          mealId: item.mealId,
          isAvailable: canFulfill,
          requestedQuantity: item.quantity,
          availableQuantity: avail.availableQuantity,
          reason: !canFulfill
            ? avail.unavailableReason || 'Insufficient quantity'
            : undefined,
        })
      }
    }

    const allAvailable = validationResults.every((r) => r.isAvailable)

    return {
      valid: allAvailable,
      results: validationResults,
    }
  })

// ============================================
// HELPER FUNCTIONS
// ============================================

async function upsertMealAvailability(
  userId: string,
  mealId: string,
  data: {
    isAvailable: boolean
    availableQuantity: number | null
    unavailableReason: string | null
    missingIngredients: string[] | null
  },
) {
  const existing = await db.mealAvailability.list([
    Query.equal('mealId', [mealId]),
    Query.limit(1),
  ])

  if (existing.rows.length > 0) {
    const updated = await db.mealAvailability.update(existing.rows[0].$id, {
      ...data,
      lastCheckedAt: new Date().toISOString(),
    })
    return { availability: updated, created: false }
  }

  const created = await db.mealAvailability.create({
    createdBy: userId,
    mealId,
    ...data,
    estimatedRestockAt: null,
    lastCheckedAt: new Date().toISOString(),
  })

  return { availability: created, created: true }
}

async function createInventoryAlert(
  userId: string,
  data: {
    ingredientId: string
    mealId: string | null
    alertType: AlertType
    currentQuantity: number
    previousQuantity?: number
    thresholdTriggered?: number
  },
) {
  // Check if similar unresolved alert exists
  const existing = await db.inventoryAlerts.list([
    Query.equal('ingredientId', [data.ingredientId]),
    Query.equal('alertType', [data.alertType]),
    Query.equal('isResolved', [false]),
    Query.limit(1),
  ])

  if (existing.rows.length > 0) {
    // Update existing alert
    return await db.inventoryAlerts.update(existing.rows[0].$id, {
      currentQuantity: data.currentQuantity,
    })
  }

  // Create new alert
  return await db.inventoryAlerts.create({
    createdBy: userId,
    ingredientId: data.ingredientId,
    mealId: data.mealId,
    alertType: data.alertType,
    previousQuantity: data.previousQuantity || null,
    currentQuantity: data.currentQuantity,
    thresholdTriggered: data.thresholdTriggered || null,
    isResolved: false,
    resolvedAt: null,
    resolvedBy: null,
  })
}
