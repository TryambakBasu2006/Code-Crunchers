// Authentication
export {
  signUpFn,
  signInFn,
  signOutFn,
  authMiddleware,
  getCurrentUser,
} from './auth'

// Orders
export {
  createOrderFn,
  getUserOrdersFn,
  getOrderDetailsFn,
  cancelOrderFn,
  getKitchenOrdersFn,
  updateOrderStatusFn,
  getOrderStatsFn,
  ORDER_STATUSES,
  type OrderStatus,
} from './orders'

// Meals
export {
  getMealsFn,
  getMealFn,
  getMealCategoriesFn,
  getDailySpecialsFn,
  getAddOnsFn,
  createMealFn,
  updateMealFn,
  deleteMealFn,
  toggleMealAvailabilityFn,
  createDailySpecialFn,
  deleteDailySpecialFn,
  createAddOnFn,
  updateAddOnFn,
  deleteAddOnFn,
} from './meals'

// Notifications
export {
  getNotificationsFn,
  markNotificationReadFn,
  markAllNotificationsReadFn,
  deleteNotificationFn,
  sendNotificationFn,
  broadcastNotificationFn,
  NOTIFICATION_TYPES,
} from './notifications'

// Recommendations & User Preferences (Legacy)
export {
  getRecommendationsFn,
  getDietaryProfileFn,
  saveDietaryProfileFn,
  getFavoritesFn,
  toggleFavoriteFn,
  submitReviewFn,
  RECOMMENDATION_REASONS,
} from './recommendations'

// AI-Powered Hybrid Recommendation Engine
export {
  getHybridRecommendationsFn,
  getContextualOffersFn,
  getUserTasteProfileFn,
  updateUserTasteProfileFn,
  calculateUserSimilaritiesFn,
  recordOfferImpressionFn,
  RECOMMENDATION_STRATEGIES,
  type RecommendationStrategy,
} from './ai-recommendations'

// Contextual Offers Management (Admin)
export {
  createContextualOfferFn,
  getContextualOffersListFn,
  updateContextualOfferFn,
  toggleContextualOfferFn,
  deleteContextualOfferFn,
  createMealPairingRuleFn,
  getMealPairingRulesFn,
  updatePairingRuleStatsFn,
  deleteMealPairingRuleFn,
  getOfferAnalyticsFn,
  createQuickOfferFn,
} from './contextual-offers'

// Payments
export {
  createPaymentIntentFn,
  confirmPaymentFn,
  getPaymentStatusFn,
  getOrderPaymentsFn,
  requestRefundFn,
  getAllPaymentsFn,
  getPaymentStatsFn,
  PAYMENT_STATUSES,
  type PaymentStatus,
} from './payments'

// User Profiles & GDPR
export {
  getUserProfileFn,
  updateUserProfileFn,
  recordGdprConsentFn,
  exportUserDataFn,
  deleteUserDataFn,
  checkAdminStatusFn,
  setUserRoleFn,
} from './user-profiles'

// Inventory Management
export {
  getIngredientsFn,
  createIngredientFn,
  updateIngredientFn,
  deleteIngredientFn,
  getInventoryFn,
  updateInventoryFn,
  setInventoryThresholdFn,
  restockInventoryFn,
  getMealIngredientsFn,
  addMealIngredientFn,
  removeMealIngredientFn,
  checkMealAvailabilityFn,
  deductInventoryForOrderFn,
} from './inventory'

// Promo Codes
export {
  validatePromoCodeFn,
  redeemPromoCodeFn,
  getPromoCodesFn,
  createPromoCodeFn,
  updatePromoCodeFn,
  deletePromoCodeFn,
  togglePromoCodeStatusFn,
  getPromoCodeStatsFn,
} from './promo-codes'

// Kitchen Queue
export {
  getKitchenQueueFn,
  addToKitchenQueueFn,
  updateQueueStatusFn,
  assignQueueItemFn,
  reorderQueueFn,
  updateQueuePriorityFn,
  changeQueueStationFn,
  removeFromQueueFn,
  getQueueStatsFn,
  autoQueueOrderFn,
  QUEUE_STATUSES,
  KITCHEN_STATIONS,
  type QueueStatus,
} from './kitchen-queue'

// Real-Time Inventory & Throttling
export {
  getMealAvailabilityFn,
  syncMealAvailabilityFn,
  syncAllMealsAvailabilityFn,
  getInventoryAlertsFn,
  resolveInventoryAlertFn,
  checkRateLimitFn,
  validateOrderInventoryFn,
  ALERT_TYPES,
  type AlertType,
} from './realtime-inventory'

// Scheduled Orders & Future Order Queue
export {
  createScheduledOrderFn,
  getScheduledOrdersFn,
  getPendingReleasesFn,
  processScheduledQueueFn,
  cancelScheduledOrderFn,
  updateScheduledTimeFn,
  getAvailablePickupSlotsFn,
  QUEUE_STATUSES as SCHEDULED_QUEUE_STATUSES,
  type ScheduledQueueStatus,
} from './scheduled-orders'

// Ratings & Feedback System
export {
  submitRatingFn,
  getMealReviewsFn,
  getUserReviewsFn,
  getMealRatingAggregateFn,
  getTopRatedMealsFn,
  updateReviewFn,
  deleteReviewFn,
  getPendingReviewsFn,
  getAIFeedbackDataFn,
  SENTIMENT_TAGS,
} from './ratings-feedback'

// Admin Setup & Staff Management
export {
  promoteToAdminFn,
  promoteToStaffFn,
  getStaffMembersFn,
  revokeStaffAccessFn,
} from './admin-setup'
