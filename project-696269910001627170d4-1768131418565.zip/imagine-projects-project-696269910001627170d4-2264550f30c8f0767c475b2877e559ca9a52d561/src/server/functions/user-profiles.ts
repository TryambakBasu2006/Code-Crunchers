import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { UserProfiles, OrderItems } from '../lib/appwrite.types'

// ============================================
// USER PROFILE MANAGEMENT
// ============================================

// Get current user's profile
export const getUserProfileFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    try {
      const profiles = await db.userProfiles.list([
        Query.equal('createdBy', [currentUser.$id]),
        Query.limit(1),
      ])

      if (profiles.rows.length === 0) {
        // Create default profile if none exists
        const newProfile = await db.userProfiles.create({
          createdBy: currentUser.$id,
          displayName: currentUser.name || null,
          phoneNumber: null,
          avatarFileId: null,
          ssoProvider: null,
          notifyByPush: true,
          notifyBySms: false,
          notifyByEmail: true,
          preferredPickupLocation: null,
          defaultPaymentMethod: null,
          stripeCustomerId: null,
          isStaff: false,
          isAdmin: false,
          gdprConsentAt: null,
          marketingConsentAt: null,
        })
        return { profile: newProfile, isNew: true }
      }

      return { profile: profiles.rows[0], isNew: false }
    } catch (error) {
      console.error('Failed to get user profile:', error)
      throw error
    }
  },
)

// Update user profile
export const updateUserProfileFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      displayName: z.string().max(100).optional(),
      phoneNumber: z.string().max(20).optional(),
      preferredPickupLocation: z.string().max(200).optional(),
      defaultPaymentMethod: z.string().optional(),
      notifyByPush: z.boolean().optional(),
      notifyBySms: z.boolean().optional(),
      notifyByEmail: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const profiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (profiles.rows.length === 0) {
      throw new Error('Profile not found')
    }

    const updates: Partial<
      Omit<UserProfiles, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.displayName !== undefined)
      updates.displayName = data.displayName?.trim() || null
    if (data.phoneNumber !== undefined)
      updates.phoneNumber = data.phoneNumber?.trim() || null
    if (data.preferredPickupLocation !== undefined)
      updates.preferredPickupLocation =
        data.preferredPickupLocation?.trim() || null
    if (data.defaultPaymentMethod !== undefined)
      updates.defaultPaymentMethod = data.defaultPaymentMethod || null
    if (data.notifyByPush !== undefined)
      updates.notifyByPush = data.notifyByPush
    if (data.notifyBySms !== undefined) updates.notifyBySms = data.notifyBySms
    if (data.notifyByEmail !== undefined)
      updates.notifyByEmail = data.notifyByEmail

    const profile = await db.userProfiles.update(profiles.rows[0].$id, updates)

    return { profile }
  })

// ============================================
// GDPR/CCPA COMPLIANCE
// ============================================

// Record GDPR consent
export const recordGdprConsentFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      gdprConsent: z.boolean(),
      marketingConsent: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const profiles = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (profiles.rows.length === 0) {
      throw new Error('Profile not found')
    }

    const now = new Date().toISOString()
    const updates: Partial<
      Omit<UserProfiles, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.gdprConsent) {
      updates.gdprConsentAt = now
    }

    if (data.marketingConsent) {
      updates.marketingConsentAt = now
    }

    const profile = await db.userProfiles.update(profiles.rows[0].$id, updates)

    return { profile }
  })

// Export user data (GDPR right to data portability)
export const exportUserDataFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Gather all user data
    const [
      profileResult,
      ordersResult,
      dietaryResult,
      favoritesResult,
      reviewsResult,
      notificationsResult,
    ] = await Promise.all([
      db.userProfiles.list([Query.equal('createdBy', [currentUser.$id])]),
      db.orders.list([Query.equal('createdBy', [currentUser.$id])]),
      db.dietaryProfiles.list([Query.equal('createdBy', [currentUser.$id])]),
      db.favorites.list([Query.equal('createdBy', [currentUser.$id])]),
      db.reviews.list([Query.equal('createdBy', [currentUser.$id])]),
      db.notifications.list([Query.equal('createdBy', [currentUser.$id])]),
    ])

    // Get order items for each order
    const orderIds = ordersResult.rows.map((o) => o.$id)
    let orderItems: OrderItems[] = []
    if (orderIds.length > 0) {
      const itemsResult = await db.orderItems.list([
        Query.equal('orderId', orderIds),
      ])
      orderItems = itemsResult.rows
    }

    const exportData = {
      exportedAt: new Date().toISOString(),
      user: {
        id: currentUser.$id,
        email: currentUser.email,
        name: currentUser.name,
        createdAt: currentUser.$createdAt,
      },
      profile: profileResult.rows[0] || null,
      dietaryProfile: dietaryResult.rows[0] || null,
      orders: ordersResult.rows.map((order) => ({
        ...order,
        items: orderItems.filter((item) => item.orderId === order.$id),
      })),
      favorites: favoritesResult.rows,
      reviews: reviewsResult.rows,
      notifications: notificationsResult.rows,
    }

    return { data: exportData }
  },
)

// Delete user data (GDPR right to erasure)
export const deleteUserDataFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      confirmEmail: z.string().email(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Verify email matches
    if (data.confirmEmail !== currentUser.email) {
      throw new Error('Email confirmation does not match')
    }

    // Delete all user data (in order of dependencies)
    const [
      orderItems,
      orders,
      favorites,
      reviews,
      notifications,
      dietaryProfiles,
      userProfiles,
      recommendations,
      payments,
      orderHistory,
    ] = await Promise.all([
      db.orderItems.list([Query.equal('createdBy', [currentUser.$id])]),
      db.orders.list([Query.equal('createdBy', [currentUser.$id])]),
      db.favorites.list([Query.equal('createdBy', [currentUser.$id])]),
      db.reviews.list([Query.equal('createdBy', [currentUser.$id])]),
      db.notifications.list([Query.equal('createdBy', [currentUser.$id])]),
      db.dietaryProfiles.list([Query.equal('createdBy', [currentUser.$id])]),
      db.userProfiles.list([Query.equal('createdBy', [currentUser.$id])]),
      db.recommendations.list([Query.equal('createdBy', [currentUser.$id])]),
      db.payments.list([Query.equal('createdBy', [currentUser.$id])]),
      db.orderHistory.list([Query.equal('createdBy', [currentUser.$id])]),
    ])

    // Delete all records
    await Promise.all([
      ...orderItems.rows.map((r) => db.orderItems.delete(r.$id)),
      ...orderHistory.rows.map((r) => db.orderHistory.delete(r.$id)),
      ...payments.rows.map((r) => db.payments.delete(r.$id)),
      ...orders.rows.map((r) => db.orders.delete(r.$id)),
      ...favorites.rows.map((r) => db.favorites.delete(r.$id)),
      ...reviews.rows.map((r) => db.reviews.delete(r.$id)),
      ...notifications.rows.map((r) => db.notifications.delete(r.$id)),
      ...dietaryProfiles.rows.map((r) => db.dietaryProfiles.delete(r.$id)),
      ...userProfiles.rows.map((r) => db.userProfiles.delete(r.$id)),
      ...recommendations.rows.map((r) => db.recommendations.delete(r.$id)),
    ])

    // Note: The actual Appwrite user account deletion would need to be done
    // through the Appwrite console or a separate admin function

    return {
      success: true,
      message:
        'All user data has been deleted. Your account will be fully removed within 30 days.',
      deletedRecords: {
        orders: orders.rows.length,
        orderItems: orderItems.rows.length,
        favorites: favorites.rows.length,
        reviews: reviews.rows.length,
        notifications: notifications.rows.length,
      },
    }
  })

// ============================================
// ADMIN FUNCTIONS
// ============================================

// Check if user is admin
export const checkAdminStatusFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) return { isAdmin: false, isStaff: false }

    try {
      const profiles = await db.userProfiles.list([
        Query.equal('createdBy', [currentUser.$id]),
        Query.limit(1),
      ])

      if (profiles.rows.length === 0) {
        return { isAdmin: false, isStaff: false }
      }

      return {
        isAdmin: profiles.rows[0].isAdmin,
        isStaff: profiles.rows[0].isStaff,
      }
    } catch {
      return { isAdmin: false, isStaff: false }
    }
  },
)

// Set user as staff/admin (admin only)
export const setUserRoleFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      userId: z.string(),
      isStaff: z.boolean().optional(),
      isAdmin: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if current user is admin
    const adminCheck = await db.userProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (adminCheck.rows.length === 0 || !adminCheck.rows[0].isAdmin) {
      throw new Error('Forbidden: Admin access required')
    }

    // Find target user's profile
    const targetProfiles = await db.userProfiles.list([
      Query.equal('createdBy', [data.userId]),
      Query.limit(1),
    ])

    if (targetProfiles.rows.length === 0) {
      throw new Error('User profile not found')
    }

    const updates: Partial<
      Omit<UserProfiles, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}
    if (data.isStaff !== undefined) updates.isStaff = data.isStaff
    if (data.isAdmin !== undefined) updates.isAdmin = data.isAdmin

    const profile = await db.userProfiles.update(
      targetProfiles.rows[0].$id,
      updates,
    )

    return { profile }
  })
