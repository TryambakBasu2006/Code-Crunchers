import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { Meals, Orders, DietaryProfiles } from '../lib/appwrite.types'

// ============================================
// AI RECOMMENDATION ENGINE
// ============================================

// Recommendation reason types
export const RECOMMENDATION_REASONS = {
  TIME_BASED: 'time_based',
  PREFERENCE_MATCH: 'preference_match',
  POPULAR: 'popular',
  REORDER: 'reorder',
  SIMILAR_USERS: 'similar_users',
  DIETARY_MATCH: 'dietary_match',
  NEW_ITEM: 'new_item',
  SPECIAL_OFFER: 'special_offer',
} as const

// Get personalized recommendations
export const getRecommendationsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        limit: z.number().min(1).max(20).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()

    const limit = data?.limit || 6
    const recommendations: Array<{
      meal: Meals
      reason: string
      reasonType: string
      score: number
    }> = []

    // Get all available meals
    const allMeals = await db.meals.list([Query.equal('isAvailable', [true])])

    if (allMeals.rows.length === 0) {
      return { recommendations: [] }
    }

    // If user is logged in, get personalized recommendations
    if (currentUser) {
      // Get user's dietary profile
      let dietaryProfile: DietaryProfiles | null = null
      try {
        const profiles = await db.dietaryProfiles.list([
          Query.equal('createdBy', [currentUser.$id]),
          Query.limit(1),
        ])
        dietaryProfile = profiles.rows[0] || null
      } catch {
        // No profile found
      }

      // Get user's order history
      let orderHistory: Orders[] = []
      try {
        const orders = await db.orders.list([
          Query.equal('createdBy', [currentUser.$id]),
          Query.orderDesc('$createdAt'),
          Query.limit(20),
        ])
        orderHistory = orders.rows
      } catch {
        // No orders found
      }

      // Get user's favorites
      try {
        await db.favorites.list([Query.equal('createdBy', [currentUser.$id])])
        // Favorites fetched for potential future use in recommendations
      } catch {
        // No favorites found
      }

      // 1. TIME-BASED RECOMMENDATIONS
      const hour = new Date().getHours()
      const timeBasedMeals = getTimeBasedMeals(allMeals.rows, hour)
      timeBasedMeals.slice(0, 2).forEach((meal) => {
        recommendations.push({
          meal,
          reason: getTimeBasedReason(hour),
          reasonType: RECOMMENDATION_REASONS.TIME_BASED,
          score: 0.9,
        })
      })

      // 2. REORDER SUGGESTIONS (from order history)
      if (orderHistory.length > 0) {
        const orderedMealIds = new Set(orderHistory.flatMap((o) => o.mealIds))
        const reorderMeals = allMeals.rows.filter((m) =>
          orderedMealIds.has(m.$id),
        )
        reorderMeals.slice(0, 2).forEach((meal) => {
          if (!recommendations.find((r) => r.meal.$id === meal.$id)) {
            recommendations.push({
              meal,
              reason: 'You enjoyed this before',
              reasonType: RECOMMENDATION_REASONS.REORDER,
              score: 0.85,
            })
          }
        })
      }

      // 3. DIETARY PREFERENCE MATCH
      if (dietaryProfile) {
        const dietaryMeals = filterByDietaryPreferences(
          allMeals.rows,
          dietaryProfile,
        )
        dietaryMeals.slice(0, 2).forEach((meal) => {
          if (!recommendations.find((r) => r.meal.$id === meal.$id)) {
            recommendations.push({
              meal,
              reason: 'Matches your dietary preferences',
              reasonType: RECOMMENDATION_REASONS.DIETARY_MATCH,
              score: 0.8,
            })
          }
        })
      }

      // 4. CALORIE GOAL MATCH
      if (dietaryProfile?.calorieGoal) {
        const targetCalories = dietaryProfile.calorieGoal / 3 // Assume 3 meals per day
        const calorieMeals = allMeals.rows
          .filter(
            (m) => m.calories && Math.abs(m.calories - targetCalories) < 150,
          )
          .slice(0, 2)

        calorieMeals.forEach((meal) => {
          if (!recommendations.find((r) => r.meal.$id === meal.$id)) {
            recommendations.push({
              meal,
              reason: `Fits your ${dietaryProfile.calorieGoal} cal/day goal`,
              reasonType: RECOMMENDATION_REASONS.PREFERENCE_MATCH,
              score: 0.75,
            })
          }
        })
      }
    }

    // 5. POPULAR ITEMS (for all users)
    // In production, this would be based on actual order counts
    const popularMeals = allMeals.rows.slice(0, 3)
    popularMeals.forEach((meal) => {
      if (!recommendations.find((r) => r.meal.$id === meal.$id)) {
        recommendations.push({
          meal,
          reason: 'Popular choice today',
          reasonType: RECOMMENDATION_REASONS.POPULAR,
          score: 0.7,
        })
      }
    })

    // Sort by score and limit
    const sortedRecommendations = recommendations
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)

    return { recommendations: sortedRecommendations }
  })

// Get time-based meal suggestions
function getTimeBasedMeals(meals: Meals[], hour: number): Meals[] {
  // Morning (6-11): Breakfast items, coffee, light meals
  if (hour >= 6 && hour < 11) {
    return meals.filter(
      (m) =>
        m.category?.toLowerCase().includes('breakfast') ||
        m.category?.toLowerCase().includes('coffee') ||
        m.category?.toLowerCase().includes('pastry') ||
        (m.calories && m.calories < 400),
    )
  }

  // Lunch (11-14): Main courses, bowls, sandwiches
  if (hour >= 11 && hour < 14) {
    return meals.filter(
      (m) =>
        m.category?.toLowerCase().includes('main') ||
        m.category?.toLowerCase().includes('bowl') ||
        m.category?.toLowerCase().includes('sandwich') ||
        m.category?.toLowerCase().includes('lunch'),
    )
  }

  // Afternoon (14-17): Light snacks, drinks
  if (hour >= 14 && hour < 17) {
    return meals.filter(
      (m) =>
        m.category?.toLowerCase().includes('snack') ||
        m.category?.toLowerCase().includes('drink') ||
        m.category?.toLowerCase().includes('dessert') ||
        (m.calories && m.calories < 300),
    )
  }

  // Dinner (17-21): Full meals
  if (hour >= 17 && hour < 21) {
    return meals.filter(
      (m) =>
        m.category?.toLowerCase().includes('main') ||
        m.category?.toLowerCase().includes('dinner') ||
        (m.calories && m.calories > 400),
    )
  }

  // Late night: Light options
  return meals.filter((m) => m.calories && m.calories < 500)
}

function getTimeBasedReason(hour: number): string {
  if (hour >= 6 && hour < 11) return 'Perfect for breakfast'
  if (hour >= 11 && hour < 14) return 'Great lunch option'
  if (hour >= 14 && hour < 17) return 'Afternoon pick-me-up'
  if (hour >= 17 && hour < 21) return 'Ideal for dinner'
  return 'Light late-night option'
}

function filterByDietaryPreferences(
  meals: Meals[],
  profile: DietaryProfiles,
): Meals[] {
  return meals.filter((meal) => {
    // Check allergens
    if (profile.allergens && profile.allergens.length > 0 && meal.allergens) {
      const hasAllergen = profile.allergens.some((a) =>
        meal.allergens?.includes(a),
      )
      if (hasAllergen) return false
    }

    // Check dietary restrictions
    if (profile.dietaryRestrictions && profile.dietaryRestrictions.length > 0) {
      // This would need more sophisticated matching in production
      // For now, we just check if the meal category matches any restriction
    }

    return true
  })
}

// ============================================
// USER PREFERENCES MANAGEMENT
// ============================================

// Get user's dietary profile
export const getDietaryProfileFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const profiles = await db.dietaryProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    return { profile: profiles.rows[0] || null }
  },
)

// Create or update dietary profile
export const saveDietaryProfileFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      dietaryRestrictions: z.array(z.string()).optional(),
      allergens: z.array(z.string()).optional(),
      dislikes: z.array(z.string()).optional(),
      preferences: z.array(z.string()).optional(),
      calorieGoal: z.number().positive().optional(),
      proteinGoal: z.number().positive().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if profile exists
    const existing = await db.dietaryProfiles.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.limit(1),
    ])

    if (existing.rows.length > 0) {
      // Update existing
      const profile = await db.dietaryProfiles.update(existing.rows[0].$id, {
        dietaryRestrictions: data.dietaryRestrictions || null,
        allergens: data.allergens || null,
        dislikes: data.dislikes || null,
        preferences: data.preferences || null,
        calorieGoal: data.calorieGoal || null,
        proteinGoal: data.proteinGoal || null,
      })
      return { profile }
    } else {
      // Create new
      const profile = await db.dietaryProfiles.create({
        createdBy: currentUser.$id,
        dietaryRestrictions: data.dietaryRestrictions || null,
        allergens: data.allergens || null,
        dislikes: data.dislikes || null,
        preferences: data.preferences || null,
        calorieGoal: data.calorieGoal || null,
        proteinGoal: data.proteinGoal || null,
      })
      return { profile }
    }
  })

// ============================================
// FAVORITES MANAGEMENT
// ============================================

// Get user's favorites
export const getFavoritesFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const favorites = await db.favorites.list([
      Query.equal('createdBy', [currentUser.$id]),
    ])

    // Get meal details for each favorite
    const favoritesWithMeals = await Promise.all(
      favorites.rows.map(async (fav) => {
        try {
          const meal = await db.meals.get(fav.mealId)
          return { ...fav, meal }
        } catch {
          return null
        }
      }),
    )

    return {
      favorites: favoritesWithMeals.filter(Boolean),
    }
  },
)

// Toggle favorite
export const toggleFavoriteFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if already favorited
    const existing = await db.favorites.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.equal('mealId', [data.mealId]),
    ])

    if (existing.rows.length > 0) {
      // Remove favorite
      await db.favorites.delete(existing.rows[0].$id)
      return { isFavorite: false }
    } else {
      // Add favorite
      await db.favorites.create({
        createdBy: currentUser.$id,
        mealId: data.mealId,
      })
      return { isFavorite: true }
    }
  })

// ============================================
// REVIEWS
// ============================================

// Submit a review
export const submitReviewFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      orderId: z.string().optional(),
      rating: z.number().min(1).max(5),
      comment: z.string().max(1000).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if this is a verified purchase
    let isVerifiedPurchase = false
    if (data.orderId) {
      try {
        const order = await db.orders.get(data.orderId)
        isVerifiedPurchase =
          order.createdBy === currentUser.$id &&
          order.mealIds.includes(data.mealId)
      } catch {
        // Order not found
      }
    }

    const review = await db.reviews.create({
      createdBy: currentUser.$id,
      mealId: data.mealId,
      orderId: data.orderId || null,
      rating: data.rating,
      comment: data.comment?.trim() || null,
      isVerifiedPurchase,
    })

    return { review }
  })

// Get reviews for a meal
export const getMealReviewsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      limit: z.number().min(1).max(50).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const reviews = await db.reviews.list([
      Query.equal('mealId', [data.mealId]),
      Query.orderDesc('$createdAt'),
      Query.limit(data.limit || 20),
    ])

    // Calculate average rating
    const avgRating =
      reviews.rows.length > 0
        ? reviews.rows.reduce((sum, r) => sum + r.rating, 0) /
          reviews.rows.length
        : 0

    return {
      reviews: reviews.rows,
      total: reviews.total,
      averageRating: Math.round(avgRating * 10) / 10,
    }
  })
