import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import { ORDER_STATUSES } from './orders'

// ============================================
// PAYMENT GATEWAY INTEGRATION
// ============================================
//
// This module provides the scaffold for payment processing.
// To enable real payments, you need to:
// 1. Set up a Stripe account at https://stripe.com
// 2. Add STRIPE_SECRET_KEY to environment variables
// 3. Add VITE_PUBLIC_STRIPE_PUBLISHABLE_KEY for frontend
// 4. Uncomment the Stripe SDK integration below
//
// For other payment providers (PayPal, Square, etc.),
// the same pattern applies - create payment intent on server,
// confirm on client, then verify on server.
// ============================================

// Payment status types
export const PAYMENT_STATUSES = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  SUCCEEDED: 'succeeded',
  FAILED: 'failed',
  REFUNDED: 'refunded',
  CANCELLED: 'cancelled',
} as const

export type PaymentStatus =
  (typeof PAYMENT_STATUSES)[keyof typeof PAYMENT_STATUSES]

// Create a payment intent (Stripe pattern)
export const createPaymentIntentFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      orderId: z.string(),
      amount: z.number().positive(),
      currency: z.string().default('usd'),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Verify order belongs to user
    const order = await db.orders.get(data.orderId)
    if (order.createdBy !== currentUser.$id) {
      throw new Error('Order not found')
    }

    // Verify amount matches order total
    if (Math.abs(order.totalPrice - data.amount) > 0.01) {
      throw new Error('Amount mismatch')
    }

    // ============================================
    // STRIPE INTEGRATION (uncomment when ready)
    // ============================================
    //
    // import Stripe from 'stripe'
    // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)
    //
    // const paymentIntent = await stripe.paymentIntents.create({
    //     amount: Math.round(data.amount * 100), // Stripe uses cents
    //     currency: data.currency,
    //     metadata: {
    //         orderId: data.orderId,
    //         userId: currentUser.$id,
    //     },
    // })
    //
    // // Create payment record
    // const payment = await db.payments.create({
    //     createdBy: currentUser.$id,
    //     orderId: data.orderId,
    //     amount: data.amount,
    //     currency: data.currency,
    //     status: PAYMENT_STATUSES.PENDING,
    //     paymentMethod: null,
    //     transactionId: paymentIntent.id,
    //     gatewayResponse: null,
    //     paidAt: null,
    //     refundedAt: null,
    // })
    //
    // return {
    //     clientSecret: paymentIntent.client_secret,
    //     paymentId: payment.$id,
    // }
    // ============================================

    // DEMO MODE: Create a mock payment record
    const payment = await db.payments.create({
      createdBy: currentUser.$id,
      orderId: data.orderId,
      amount: data.amount,
      currency: data.currency,
      status: PAYMENT_STATUSES.PENDING,
      paymentMethod: 'demo',
      transactionId: `demo_${Date.now()}`,
      gatewayResponse: null,
      paidAt: null,
      refundedAt: null,
    })

    return {
      clientSecret: 'demo_mode',
      paymentId: payment.$id,
      demoMode: true,
    }
  })

// Confirm payment (called after client-side payment completion)
export const confirmPaymentFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      paymentId: z.string(),
      transactionId: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const payment = await db.payments.get(data.paymentId)

    if (payment.createdBy !== currentUser.$id) {
      throw new Error('Payment not found')
    }

    // ============================================
    // STRIPE VERIFICATION (uncomment when ready)
    // ============================================
    //
    // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)
    // const paymentIntent = await stripe.paymentIntents.retrieve(payment.transactionId!)
    //
    // if (paymentIntent.status !== 'succeeded') {
    //     await db.payments.update(data.paymentId, {
    //         status: PAYMENT_STATUSES.FAILED,
    //         gatewayResponse: JSON.stringify(paymentIntent),
    //     })
    //     throw new Error('Payment failed')
    // }
    // ============================================

    // Update payment status
    await db.payments.update(data.paymentId, {
      status: PAYMENT_STATUSES.SUCCEEDED,
      paidAt: new Date().toISOString(),
      gatewayResponse: JSON.stringify({ demo: true }),
    })

    // Update order status to confirmed
    await db.orders.update(payment.orderId, {
      status: ORDER_STATUSES.CONFIRMED,
    })

    // Create order history entry
    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: payment.orderId,
      previousStatus: ORDER_STATUSES.PENDING,
      newStatus: ORDER_STATUSES.CONFIRMED,
      changedBy: 'system',
      notes: 'Payment confirmed',
    })

    // Create notification
    await db.notifications.create({
      createdBy: currentUser.$id,
      orderId: payment.orderId,
      type: 'order_confirmed',
      title: '✅ Order Confirmed',
      message: "Your payment was successful. We're preparing your order!",
      isRead: false,
      channel: 'in_app',
      sentAt: new Date().toISOString(),
    })

    return { success: true }
  })

// Get payment status
export const getPaymentStatusFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ paymentId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const payment = await db.payments.get(data.paymentId)

    if (payment.createdBy !== currentUser.$id) {
      throw new Error('Payment not found')
    }

    return { payment }
  })

// Get payments for an order
export const getOrderPaymentsFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ orderId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const order = await db.orders.get(data.orderId)

    if (order.createdBy !== currentUser.$id) {
      throw new Error('Order not found')
    }

    const payments = await db.payments.list([
      Query.equal('orderId', [data.orderId]),
      Query.orderDesc('$createdAt'),
    ])

    return { payments: payments.rows }
  })

// Request refund
export const requestRefundFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      paymentId: z.string(),
      reason: z.string().max(500).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const payment = await db.payments.get(data.paymentId)

    if (payment.createdBy !== currentUser.$id) {
      throw new Error('Payment not found')
    }

    if (payment.status !== PAYMENT_STATUSES.SUCCEEDED) {
      throw new Error('Only successful payments can be refunded')
    }

    // ============================================
    // STRIPE REFUND (uncomment when ready)
    // ============================================
    //
    // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)
    // const refund = await stripe.refunds.create({
    //     payment_intent: payment.transactionId!,
    //     reason: 'requested_by_customer',
    // })
    // ============================================

    // Update payment status
    await db.payments.update(data.paymentId, {
      status: PAYMENT_STATUSES.REFUNDED,
      refundedAt: new Date().toISOString(),
    })

    // Update order status
    await db.orders.update(payment.orderId, {
      status: ORDER_STATUSES.CANCELLED,
    })

    // Create notification
    await db.notifications.create({
      createdBy: currentUser.$id,
      orderId: payment.orderId,
      type: 'refund_processed',
      title: '💰 Refund Processed',
      message:
        'Your refund has been processed. It may take 5-10 business days to appear.',
      isRead: false,
      channel: 'in_app',
      sentAt: new Date().toISOString(),
    })

    return { success: true }
  })

// ============================================
// ADMIN PAYMENT FUNCTIONS
// ============================================

// Get all payments (admin)
export const getAllPaymentsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        status: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    const queries = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.status) {
      queries.push(Query.equal('status', [data.status]))
    }

    const payments = await db.payments.list(queries)

    return { payments: payments.rows, total: payments.total }
  })

// Get payment statistics
export const getPaymentStatsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const todayPayments = await db.payments.list([
      Query.greaterThanEqual('$createdAt', today.toISOString()),
    ])

    const stats = {
      totalToday: todayPayments.total,
      successfulToday: todayPayments.rows.filter(
        (p) => p.status === PAYMENT_STATUSES.SUCCEEDED,
      ).length,
      failedToday: todayPayments.rows.filter(
        (p) => p.status === PAYMENT_STATUSES.FAILED,
      ).length,
      refundedToday: todayPayments.rows.filter(
        (p) => p.status === PAYMENT_STATUSES.REFUNDED,
      ).length,
      revenueToday: todayPayments.rows
        .filter((p) => p.status === PAYMENT_STATUSES.SUCCEEDED)
        .reduce((sum, p) => sum + p.amount, 0),
    }

    return { stats }
  },
)
