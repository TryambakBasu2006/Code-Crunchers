import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { Reviews, MealRatingAggregates } from '../lib/appwrite.types'

// ============================================
// RATING & FEEDBACK SYSTEM
// ============================================

// Sentiment tags for feedback analysis
export const SENTIMENT_TAGS = {
  POSITIVE: [
    'delicious',
    'fresh',
    'hot',
    'generous_portion',
    'great_value',
    'quick_service',
    'well_seasoned',
    'authentic',
    'would_recommend',
    'perfect',
  ],
  NEGATIVE: [
    'cold',
    'bland',
    'small_portion',
    'overpriced',
    'slow_service',
    'undercooked',
    'overcooked',
    'stale',
    'disappointing',
    'not_as_described',
  ],
} as const

// ============================================
// SUBMIT RATING & REVIEW
// ============================================

const submitRatingSchema = z.object({
  mealId: z.string(),
  orderId: z.string().optional(),
  rating: z.number().min(1).max(5),
  comment: z.string().max(1000).optional(),
  tags: z.array(z.string()).optional(), // Sentiment tags
})

export const submitRatingFn = createServerFn({ method: 'POST' })
  .inputValidator(submitRatingSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const { mealId, orderId, rating, comment, tags } = data

    // Check if user has already reviewed this meal for this order
    if (orderId) {
      const existingReview = await db.reviews.list([
        Query.equal('createdBy', [currentUser.$id]),
        Query.equal('mealId', [mealId]),
        Query.equal('orderId', [orderId]),
        Query.limit(1),
      ])

      if (existingReview.rows.length > 0) {
        throw new Error('You have already reviewed this meal for this order')
      }
    }

    // Verify purchase if orderId provided
    let isVerifiedPurchase = false
    if (orderId) {
      try {
        const order = await db.orders.get(orderId)
        if (
          order.createdBy === currentUser.$id &&
          order.mealIds.includes(mealId) &&
          order.status === 'picked_up'
        ) {
          isVerifiedPurchase = true
        }
      } catch {
        // Order not found or not accessible
      }
    }

    // Create the review
    const review = await db.reviews.create({
      createdBy: currentUser.$id,
      mealId,
      orderId: orderId || null,
      rating,
      comment: comment?.trim() || null,
      isVerifiedPurchase,
    })

    // Update meal rating aggregates
    await updateMealRatingAggregates(currentUser.$id, mealId, rating, tags)

    // Create notification for kitchen/admin about feedback
    if (rating <= 2 || (comment && comment.length > 50)) {
      await db.notifications.create({
        createdBy: 'system',
        orderId: orderId || null,
        type: 'feedback_received',
        title: rating <= 2 ? '⚠️ Low Rating Received' : '📝 New Feedback',
        message: `${rating}★ rating for meal. ${comment ? `Comment: "${comment.substring(0, 100)}..."` : ''}`,
        isRead: false,
        channel: 'in_app',
        sentAt: new Date().toISOString(),
      })
    }

    return { review, isVerifiedPurchase }
  })

// ============================================
// GET MEAL REVIEWS
// ============================================

export const getMealReviewsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      verifiedOnly: z.boolean().optional(),
      minRating: z.number().min(1).max(5).optional(),
      limit: z.number().min(1).max(50).optional(),
      offset: z.number().min(0).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const queries: string[] = [
      Query.equal('mealId', [data.mealId]),
      Query.orderDesc('$createdAt'),
      Query.limit(data.limit || 20),
    ]

    if (data.offset) {
      queries.push(Query.offset(data.offset))
    }

    if (data.verifiedOnly) {
      queries.push(Query.equal('isVerifiedPurchase', [true]))
    }

    if (data.minRating) {
      queries.push(Query.greaterThanEqual('rating', data.minRating))
    }

    const reviews = await db.reviews.list(queries)

    return { reviews: reviews.rows, total: reviews.total }
  })

// ============================================
// GET USER'S REVIEWS
// ============================================

export const getUserReviewsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        limit: z.number().min(1).max(50).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const reviews = await db.reviews.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 20),
    ])

    return { reviews: reviews.rows, total: reviews.total }
  })

// ============================================
// GET MEAL RATING AGGREGATES
// ============================================

export const getMealRatingAggregateFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const aggregates = await db.mealRatingAggregates.list([
      Query.equal('mealId', [data.mealId]),
      Query.limit(1),
    ])

    if (aggregates.rows.length === 0) {
      return {
        aggregate: null,
        hasRatings: false,
      }
    }

    return {
      aggregate: aggregates.rows[0],
      hasRatings: true,
    }
  })

// ============================================
// GET TOP RATED MEALS
// ============================================

export const getTopRatedMealsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        minReviews: z.number().min(1).optional(),
        limit: z.number().min(1).max(20).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const minReviews = data?.minReviews || 3
    const limit = data?.limit || 10

    const aggregates = await db.mealRatingAggregates.list([
      Query.greaterThanEqual('totalReviews', minReviews),
      Query.orderDesc('averageRating'),
      Query.limit(limit),
    ])

    // Get meal details
    const mealIds = aggregates.rows.map((a) => a.mealId)
    let meals: Array<{ $id: string; name: string; category: string | null }> =
      []

    if (mealIds.length > 0) {
      const mealsResult = await db.meals.list([Query.equal('$id', mealIds)])
      meals = mealsResult.rows
    }

    const enrichedAggregates = aggregates.rows.map((agg) => ({
      ...agg,
      meal: meals.find((m) => m.$id === agg.mealId),
    }))

    return { topRated: enrichedAggregates }
  })

// ============================================
// UPDATE REVIEW (User can edit their own)
// ============================================

export const updateReviewFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      reviewId: z.string(),
      rating: z.number().min(1).max(5).optional(),
      comment: z.string().max(1000).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const review = await db.reviews.get(data.reviewId)

    if (review.createdBy !== currentUser.$id) {
      throw new Error('Review not found')
    }

    const updates: Partial<
      Omit<Reviews, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.rating !== undefined) updates.rating = data.rating
    if (data.comment !== undefined)
      updates.comment = data.comment?.trim() || null

    const updatedReview = await db.reviews.update(data.reviewId, updates)

    // Recalculate aggregates if rating changed
    if (data.rating !== undefined && data.rating !== review.rating) {
      await recalculateMealAggregates(currentUser.$id, review.mealId)
    }

    return { review: updatedReview }
  })

// ============================================
// DELETE REVIEW
// ============================================

export const deleteReviewFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ reviewId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const review = await db.reviews.get(data.reviewId)

    if (review.createdBy !== currentUser.$id) {
      throw new Error('Review not found')
    }

    await db.reviews.delete(data.reviewId)

    // Recalculate aggregates
    await recalculateMealAggregates(currentUser.$id, review.mealId)

    return { success: true }
  })

// ============================================
// GET PENDING REVIEWS (Orders without reviews)
// ============================================

export const getPendingReviewsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get completed orders
    const completedOrders = await db.orders.list([
      Query.equal('createdBy', [currentUser.$id]),
      Query.equal('status', ['picked_up']),
      Query.orderDesc('$createdAt'),
      Query.limit(20),
    ])

    // Get existing reviews
    const orderIds = completedOrders.rows.map((o) => o.$id)
    let existingReviews: Reviews[] = []

    if (orderIds.length > 0) {
      const reviewsResult = await db.reviews.list([
        Query.equal('createdBy', [currentUser.$id]),
        Query.equal('orderId', orderIds),
      ])
      existingReviews = reviewsResult.rows
    }

    // Find orders with meals that haven't been reviewed
    const pendingReviews: Array<{
      orderId: string
      mealId: string
      orderDate: string
    }> = []

    for (const order of completedOrders.rows) {
      for (const mealId of order.mealIds) {
        const hasReview = existingReviews.some(
          (r) => r.orderId === order.$id && r.mealId === mealId,
        )

        if (!hasReview) {
          pendingReviews.push({
            orderId: order.$id,
            mealId,
            orderDate: order.$createdAt,
          })
        }
      }
    }

    return { pendingReviews }
  },
)

// ============================================
// AI FEEDBACK ANALYSIS (for ML training)
// ============================================

export const getAIFeedbackDataFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        mealId: z.string().optional(),
        minRating: z.number().min(1).max(5).optional(),
        maxRating: z.number().min(1).max(5).optional(),
        limit: z.number().min(1).max(500).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin check in production

    const queries: string[] = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 100),
    ]

    if (data?.mealId) {
      queries.push(Query.equal('mealId', [data.mealId]))
    }

    if (data?.minRating) {
      queries.push(Query.greaterThanEqual('rating', data.minRating))
    }

    if (data?.maxRating) {
      queries.push(Query.lessThanEqual('rating', data.maxRating))
    }

    const reviews = await db.reviews.list(queries)

    // Format for ML training
    const trainingData = reviews.rows.map((review) => ({
      mealId: review.mealId,
      rating: review.rating,
      comment: review.comment,
      isVerifiedPurchase: review.isVerifiedPurchase,
      timestamp: review.$createdAt,
    }))

    return {
      data: trainingData,
      total: reviews.total,
      exportedAt: new Date().toISOString(),
    }
  })

// ============================================
// HELPER FUNCTIONS
// ============================================

async function updateMealRatingAggregates(
  userId: string,
  mealId: string,
  newRating: number,
  tags?: string[],
) {
  const existing = await db.mealRatingAggregates.list([
    Query.equal('mealId', [mealId]),
    Query.limit(1),
  ])

  if (existing.rows.length === 0) {
    // Create new aggregate
    const ratingCounts = {
      rating5Count: newRating === 5 ? 1 : 0,
      rating4Count: newRating === 4 ? 1 : 0,
      rating3Count: newRating === 3 ? 1 : 0,
      rating2Count: newRating === 2 ? 1 : 0,
      rating1Count: newRating === 1 ? 1 : 0,
    }

    await db.mealRatingAggregates.create({
      createdBy: userId,
      mealId,
      averageRating: newRating,
      totalReviews: 1,
      ...ratingCounts,
      verifiedPurchaseCount: 1,
      sentimentScore: calculateSentimentScore(newRating, tags),
      commonPositiveTags:
        tags?.filter((t) =>
          SENTIMENT_TAGS.POSITIVE.includes(
            t as (typeof SENTIMENT_TAGS.POSITIVE)[number],
          ),
        ) || null,
      commonNegativeTags:
        tags?.filter((t) =>
          SENTIMENT_TAGS.NEGATIVE.includes(
            t as (typeof SENTIMENT_TAGS.NEGATIVE)[number],
          ),
        ) || null,
      lastCalculatedAt: new Date().toISOString(),
    })
  } else {
    // Update existing aggregate
    const agg = existing.rows[0]
    const newTotal = agg.totalReviews + 1
    const newAverage =
      (agg.averageRating * agg.totalReviews + newRating) / newTotal

    const ratingKey = `rating${newRating}Count` as keyof MealRatingAggregates
    const currentCount = (agg[ratingKey] as number) || 0

    await db.mealRatingAggregates.update(agg.$id, {
      averageRating: Math.round(newAverage * 10) / 10,
      totalReviews: newTotal,
      [ratingKey]: currentCount + 1,
      verifiedPurchaseCount: (agg.verifiedPurchaseCount || 0) + 1,
      sentimentScore: calculateSentimentScore(newAverage, tags),
      lastCalculatedAt: new Date().toISOString(),
    })
  }
}

async function recalculateMealAggregates(userId: string, mealId: string) {
  // Get all reviews for this meal
  const reviews = await db.reviews.list([Query.equal('mealId', [mealId])])

  if (reviews.rows.length === 0) {
    // Delete aggregate if no reviews
    const existing = await db.mealRatingAggregates.list([
      Query.equal('mealId', [mealId]),
      Query.limit(1),
    ])

    if (existing.rows.length > 0) {
      await db.mealRatingAggregates.delete(existing.rows[0].$id)
    }
    return
  }

  // Calculate new aggregates
  const ratings = reviews.rows.map((r) => r.rating)
  const averageRating = ratings.reduce((a, b) => a + b, 0) / ratings.length

  const ratingCounts = {
    rating5Count: ratings.filter((r) => r === 5).length,
    rating4Count: ratings.filter((r) => r === 4).length,
    rating3Count: ratings.filter((r) => r === 3).length,
    rating2Count: ratings.filter((r) => r === 2).length,
    rating1Count: ratings.filter((r) => r === 1).length,
  }

  const verifiedCount = reviews.rows.filter((r) => r.isVerifiedPurchase).length

  const existing = await db.mealRatingAggregates.list([
    Query.equal('mealId', [mealId]),
    Query.limit(1),
  ])

  if (existing.rows.length > 0) {
    await db.mealRatingAggregates.update(existing.rows[0].$id, {
      averageRating: Math.round(averageRating * 10) / 10,
      totalReviews: reviews.total,
      ...ratingCounts,
      verifiedPurchaseCount: verifiedCount,
      lastCalculatedAt: new Date().toISOString(),
    })
  } else {
    await db.mealRatingAggregates.create({
      createdBy: userId,
      mealId,
      averageRating: Math.round(averageRating * 10) / 10,
      totalReviews: reviews.total,
      ...ratingCounts,
      verifiedPurchaseCount: verifiedCount,
      sentimentScore: null,
      commonPositiveTags: null,
      commonNegativeTags: null,
      lastCalculatedAt: new Date().toISOString(),
    })
  }
}

function calculateSentimentScore(rating: number, tags?: string[]): number {
  // Base score from rating (0-100 scale)
  let score = (rating / 5) * 100

  if (tags && tags.length > 0) {
    const positiveCount = tags.filter((t) =>
      SENTIMENT_TAGS.POSITIVE.includes(
        t as (typeof SENTIMENT_TAGS.POSITIVE)[number],
      ),
    ).length
    const negativeCount = tags.filter((t) =>
      SENTIMENT_TAGS.NEGATIVE.includes(
        t as (typeof SENTIMENT_TAGS.NEGATIVE)[number],
      ),
    ).length

    // Adjust score based on tags
    score += positiveCount * 5
    score -= negativeCount * 5
  }

  return Math.max(0, Math.min(100, Math.round(score)))
}
