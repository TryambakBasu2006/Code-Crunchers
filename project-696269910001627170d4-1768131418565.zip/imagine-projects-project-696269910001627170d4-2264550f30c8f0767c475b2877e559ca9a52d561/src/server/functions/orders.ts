import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { OrderItems } from '../lib/appwrite.types'

// Order status flow
export const ORDER_STATUSES = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  PREPARING: 'preparing',
  READY: 'ready',
  PICKED_UP: 'picked_up',
  CANCELLED: 'cancelled',
} as const

export type OrderStatus = (typeof ORDER_STATUSES)[keyof typeof ORDER_STATUSES]

// Schema for creating an order
const createOrderSchema = z.object({
  items: z.array(
    z.object({
      mealId: z.string(),
      quantity: z.number().min(1).max(20),
      unitPrice: z.number().positive(),
      portionSize: z.enum(['small', 'regular', 'large', 'family']).optional(),
      spiceLevel: z.number().min(0).max(4).optional(),
      addOns: z.array(z.string()).optional(),
      addOnPrices: z.array(z.number()).optional(),
      dietaryPreferences: z.array(z.string()).optional(),
      specialInstructions: z.string().max(500).optional(),
    }),
  ),
  notes: z.string().max(500).optional(),
  pickupTime: z.string().optional(), // ISO datetime
})

// Create a new order
export const createOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(createOrderSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const { items, notes, pickupTime } = data

    // Calculate totals
    const mealIds: string[] = []
    const quantities: number[] = []
    let totalPrice = 0

    for (const item of items) {
      mealIds.push(item.mealId)
      quantities.push(item.quantity)

      const addOnsTotal = item.addOnPrices?.reduce((sum, p) => sum + p, 0) || 0
      const itemTotal = (item.unitPrice + addOnsTotal) * item.quantity
      totalPrice += itemTotal
    }

    // Create the order
    const order = await db.orders.create({
      createdBy: currentUser.$id,
      mealIds,
      quantities,
      totalPrice,
      status: ORDER_STATUSES.PENDING,
      notes: notes?.trim() || null,
      pickupTime: pickupTime || null,
    })

    // Create order items with customization details
    const orderItems: OrderItems[] = []
    for (const item of items) {
      const addOnsTotal = item.addOnPrices?.reduce((sum, p) => sum + p, 0) || 0
      const itemTotalPrice = (item.unitPrice + addOnsTotal) * item.quantity

      const orderItem = await db.orderItems.create({
        createdBy: currentUser.$id,
        orderId: order.$id,
        mealId: item.mealId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: itemTotalPrice,
        portionSize: item.portionSize || 'regular',
        spiceLevel: item.spiceLevel?.toString() || '1',
        addOns: item.addOns || null,
        addOnPrices: item.addOnPrices || null,
        dietaryPreferences: item.dietaryPreferences || null,
        specialInstructions: item.specialInstructions?.trim() || null,
      })
      orderItems.push(orderItem)
    }

    // Create initial order history entry
    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: order.$id,
      previousStatus: null,
      newStatus: ORDER_STATUSES.PENDING,
      changedBy: currentUser.$id,
      notes: 'Order placed',
    })

    return { order, orderItems }
  })

// Get user's orders
export const getUserOrdersFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        status: z.string().optional(),
        limit: z.number().min(1).max(50).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [
      Query.equal('createdBy', [currentUser.$id]),
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 20),
    ]

    if (data?.status) {
      queries.push(Query.equal('status', [data.status]))
    }

    const orders = await db.orders.list(queries)
    return { orders: orders.rows, total: orders.total }
  })

// Get single order with items
export const getOrderDetailsFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ orderId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const order = await db.orders.get(data.orderId)

    // Verify ownership
    if (order.createdBy !== currentUser.$id) {
      throw new Error('Order not found')
    }

    // Get order items
    const orderItems = await db.orderItems.list([
      Query.equal('orderId', [data.orderId]),
    ])

    // Get order history
    const history = await db.orderHistory.list([
      Query.equal('orderId', [data.orderId]),
      Query.orderDesc('$createdAt'),
    ])

    return {
      order,
      items: orderItems.rows,
      history: history.rows,
    }
  })

// Cancel order (user can only cancel pending orders)
export const cancelOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({ orderId: z.string(), reason: z.string().optional() }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const order = await db.orders.get(data.orderId)

    if (order.createdBy !== currentUser.$id) {
      throw new Error('Order not found')
    }

    if (order.status !== ORDER_STATUSES.PENDING) {
      throw new Error('Only pending orders can be cancelled')
    }

    const previousStatus = order.status

    await db.orders.update(data.orderId, {
      status: ORDER_STATUSES.CANCELLED,
    })

    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: data.orderId,
      previousStatus,
      newStatus: ORDER_STATUSES.CANCELLED,
      changedBy: currentUser.$id,
      notes: data.reason || 'Cancelled by user',
    })

    return { success: true }
  })

// ============================================
// KITCHEN/ADMIN FUNCTIONS
// ============================================

// Get all orders for kitchen (admin only - in production, add role check)
export const getKitchenOrdersFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        statuses: z.array(z.string()).optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check in production
    // if (!currentUser.labels?.includes('admin')) throw new Error('Forbidden')

    const queries = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.statuses && data.statuses.length > 0) {
      queries.push(Query.equal('status', data.statuses))
    }

    const orders = await db.orders.list(queries)

    // Get all order items for these orders
    const orderIds = orders.rows.map((o) => o.$id)
    let allItems: OrderItems[] = []

    if (orderIds.length > 0) {
      const itemsResult = await db.orderItems.list([
        Query.equal('orderId', orderIds),
      ])
      allItems = itemsResult.rows
    }

    // Group items by order
    const ordersWithItems = orders.rows.map((order) => ({
      ...order,
      items: allItems.filter((item) => item.orderId === order.$id),
    }))

    return { orders: ordersWithItems, total: orders.total }
  })

// Update order status (kitchen/admin)
export const updateOrderStatusFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      orderId: z.string(),
      newStatus: z.enum([
        'pending',
        'confirmed',
        'preparing',
        'ready',
        'picked_up',
        'cancelled',
      ]),
      notes: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check in production

    const order = await db.orders.get(data.orderId)
    const previousStatus = order.status

    await db.orders.update(data.orderId, {
      status: data.newStatus,
    })

    await db.orderHistory.create({
      createdBy: currentUser.$id,
      orderId: data.orderId,
      previousStatus,
      newStatus: data.newStatus,
      changedBy: currentUser.$id,
      notes: data.notes || `Status changed to ${data.newStatus}`,
    })

    // Create notification for user when order is ready
    if (data.newStatus === ORDER_STATUSES.READY) {
      await db.notifications.create({
        createdBy: order.createdBy,
        orderId: data.orderId,
        type: 'order_ready',
        title: '🎉 Your order is ready!',
        message:
          'Your order is ready for pickup. Please collect it from the counter.',
        isRead: false,
        channel: 'in_app',
        sentAt: new Date().toISOString(),
      })
    }

    return { success: true, previousStatus, newStatus: data.newStatus }
  })

// Get order statistics for dashboard
export const getOrderStatsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Get today's orders
    const todayOrders = await db.orders.list([
      Query.greaterThanEqual('$createdAt', today.toISOString()),
    ])

    const stats = {
      totalToday: todayOrders.total,
      pending: todayOrders.rows.filter(
        (o) => o.status === ORDER_STATUSES.PENDING,
      ).length,
      preparing: todayOrders.rows.filter(
        (o) => o.status === ORDER_STATUSES.PREPARING,
      ).length,
      ready: todayOrders.rows.filter((o) => o.status === ORDER_STATUSES.READY)
        .length,
      completed: todayOrders.rows.filter(
        (o) => o.status === ORDER_STATUSES.PICKED_UP,
      ).length,
      cancelled: todayOrders.rows.filter(
        (o) => o.status === ORDER_STATUSES.CANCELLED,
      ).length,
      revenue: todayOrders.rows
        .filter((o) => o.status !== ORDER_STATUSES.CANCELLED)
        .reduce((sum, o) => sum + o.totalPrice, 0),
    }

    return { stats }
  },
)
