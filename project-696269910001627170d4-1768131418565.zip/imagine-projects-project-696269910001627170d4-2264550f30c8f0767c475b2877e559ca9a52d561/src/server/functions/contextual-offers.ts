import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'

// ============================================
// CONTEXTUAL OFFERS MANAGEMENT (Admin)
// ============================================

const offerSchema = z.object({
  offerType: z.enum(['pairing', 'time_deal', 'upsell', 'bundle', 'flash_sale']),
  title: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
  triggerType: z.enum([
    'time',
    'meal',
    'category',
    'cart_value',
    'weather',
    'inventory',
  ]),
  triggerMealId: z.string().optional(),
  triggerCategory: z.string().optional(),
  triggerTimeStart: z.string().optional(), // HH:MM format
  triggerTimeEnd: z.string().optional(),
  triggerDaysOfWeek: z.array(z.string()).optional(), // ['0', '1', '2', ...] Sunday = 0
  suggestedMealId: z.string().optional(),
  suggestedAddOnId: z.string().optional(),
  discountType: z.enum(['percentage', 'fixed', 'bogo']).optional(),
  discountValue: z.number().min(0).optional(),
  requiresPastPurchase: z.boolean().default(false),
  minInventoryLevel: z.number().optional(),
  priority: z.number().min(1).max(10).default(5),
  validFrom: z.string(), // ISO datetime
  validUntil: z.string(), // ISO datetime
  isActive: z.boolean().default(true),
})

// Create a new contextual offer
export const createContextualOfferFn = createServerFn({ method: 'POST' })
  .inputValidator(offerSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // TODO: Add admin role check in production

    const offer = await db.contextualOffers.create({
      createdBy: currentUser.$id,
      offerType: data.offerType,
      title: data.title.trim(),
      description: data.description?.trim() || null,
      triggerType: data.triggerType,
      triggerMealId: data.triggerMealId || null,
      triggerCategory: data.triggerCategory || null,
      triggerTimeStart: data.triggerTimeStart || null,
      triggerTimeEnd: data.triggerTimeEnd || null,
      triggerDaysOfWeek: data.triggerDaysOfWeek || null,
      suggestedMealId: data.suggestedMealId || null,
      suggestedAddOnId: data.suggestedAddOnId || null,
      discountType: data.discountType || null,
      discountValue: data.discountValue ?? null,
      requiresPastPurchase: data.requiresPastPurchase,
      minInventoryLevel: data.minInventoryLevel ?? null,
      priority: data.priority,
      validFrom: data.validFrom,
      validUntil: data.validUntil,
      isActive: data.isActive,
    })

    return { offer }
  })

// Get all contextual offers
export const getContextualOffersListFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        activeOnly: z.boolean().optional(),
        offerType: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.activeOnly) {
      queries.push(Query.equal('isActive', [true]))
    }

    if (data?.offerType) {
      queries.push(Query.equal('offerType', [data.offerType]))
    }

    const offers = await db.contextualOffers.list(queries)

    // Enrich with meal/addon details
    const enrichedOffers = await Promise.all(
      offers.rows.map(async (offer) => {
        let suggestedMeal = null
        let suggestedAddOn = null
        let triggerMeal = null

        if (offer.suggestedMealId) {
          try {
            suggestedMeal = await db.meals.get(offer.suggestedMealId)
          } catch {
            // Meal not found
          }
        }

        if (offer.suggestedAddOnId) {
          try {
            suggestedAddOn = await db.addOns.get(offer.suggestedAddOnId)
          } catch {
            // Add-on not found
          }
        }

        if (offer.triggerMealId) {
          try {
            triggerMeal = await db.meals.get(offer.triggerMealId)
          } catch {
            // Meal not found
          }
        }

        return {
          ...offer,
          suggestedMeal,
          suggestedAddOn,
          triggerMeal,
        }
      }),
    )

    return { offers: enrichedOffers, total: offers.total }
  })

// Update a contextual offer
export const updateContextualOfferFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      offerId: z.string(),
      updates: offerSchema.partial(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Record<string, unknown> = {}

    if (data.updates.offerType !== undefined)
      updates.offerType = data.updates.offerType
    if (data.updates.title !== undefined)
      updates.title = data.updates.title.trim()
    if (data.updates.description !== undefined)
      updates.description = data.updates.description?.trim() || null
    if (data.updates.triggerType !== undefined)
      updates.triggerType = data.updates.triggerType
    if (data.updates.triggerMealId !== undefined)
      updates.triggerMealId = data.updates.triggerMealId || null
    if (data.updates.triggerCategory !== undefined)
      updates.triggerCategory = data.updates.triggerCategory || null
    if (data.updates.triggerTimeStart !== undefined)
      updates.triggerTimeStart = data.updates.triggerTimeStart || null
    if (data.updates.triggerTimeEnd !== undefined)
      updates.triggerTimeEnd = data.updates.triggerTimeEnd || null
    if (data.updates.triggerDaysOfWeek !== undefined)
      updates.triggerDaysOfWeek = data.updates.triggerDaysOfWeek || null
    if (data.updates.suggestedMealId !== undefined)
      updates.suggestedMealId = data.updates.suggestedMealId || null
    if (data.updates.suggestedAddOnId !== undefined)
      updates.suggestedAddOnId = data.updates.suggestedAddOnId || null
    if (data.updates.discountType !== undefined)
      updates.discountType = data.updates.discountType || null
    if (data.updates.discountValue !== undefined)
      updates.discountValue = data.updates.discountValue ?? null
    if (data.updates.requiresPastPurchase !== undefined)
      updates.requiresPastPurchase = data.updates.requiresPastPurchase
    if (data.updates.minInventoryLevel !== undefined)
      updates.minInventoryLevel = data.updates.minInventoryLevel ?? null
    if (data.updates.priority !== undefined)
      updates.priority = data.updates.priority
    if (data.updates.validFrom !== undefined)
      updates.validFrom = data.updates.validFrom
    if (data.updates.validUntil !== undefined)
      updates.validUntil = data.updates.validUntil
    if (data.updates.isActive !== undefined)
      updates.isActive = data.updates.isActive

    const offer = await db.contextualOffers.update(data.offerId, updates)

    return { offer }
  })

// Toggle offer active status
export const toggleContextualOfferFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ offerId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const offer = await db.contextualOffers.get(data.offerId)
    const updatedOffer = await db.contextualOffers.update(data.offerId, {
      isActive: !offer.isActive,
    })

    return { offer: updatedOffer }
  })

// Delete a contextual offer
export const deleteContextualOfferFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ offerId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.contextualOffers.delete(data.offerId)

    return { success: true }
  })

// ============================================
// MEAL PAIRING RULES MANAGEMENT
// ============================================

const pairingRuleSchema = z.object({
  primaryMealId: z.string(),
  pairedItemId: z.string(),
  pairedItemType: z.enum(['meal', 'addon']),
  pairingScore: z.number().min(0).max(1).optional(),
  pairingReason: z.string().max(200).optional(),
  isMLGenerated: z.boolean().default(false),
})

// Create a meal pairing rule
export const createMealPairingRuleFn = createServerFn({ method: 'POST' })
  .inputValidator(pairingRuleSchema)
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const rule = await db.mealPairingRules.create({
      createdBy: currentUser.$id,
      primaryMealId: data.primaryMealId,
      pairedItemId: data.pairedItemId,
      pairedItemType: data.pairedItemType,
      pairingScore: data.pairingScore ?? 0.7,
      pairingReason: data.pairingReason?.trim() || null,
      isMLGenerated: data.isMLGenerated,
      acceptanceRate: null,
      timesShown: 0,
      timesAccepted: 0,
    })

    return { rule }
  })

// Get pairing rules for a meal
export const getMealPairingRulesFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const rules = await db.mealPairingRules.list([
      Query.equal('primaryMealId', [data.mealId]),
      Query.orderDesc('pairingScore'),
    ])

    // Enrich with item details
    const enrichedRules = await Promise.all(
      rules.rows.map(async (rule) => {
        let pairedItem = null
        if (rule.pairedItemType === 'meal') {
          try {
            pairedItem = await db.meals.get(rule.pairedItemId)
          } catch {
            // Not found
          }
        } else {
          try {
            pairedItem = await db.addOns.get(rule.pairedItemId)
          } catch {
            // Not found
          }
        }
        return { ...rule, pairedItem }
      }),
    )

    return { rules: enrichedRules }
  })

// Update pairing rule (e.g., after user accepts/rejects)
export const updatePairingRuleStatsFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      ruleId: z.string(),
      wasAccepted: z.boolean(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const rule = await db.mealPairingRules.get(data.ruleId)

    const newTimesShown = (rule.timesShown || 0) + 1
    const newTimesAccepted =
      (rule.timesAccepted || 0) + (data.wasAccepted ? 1 : 0)
    const newAcceptanceRate = newTimesAccepted / newTimesShown

    const updatedRule = await db.mealPairingRules.update(data.ruleId, {
      timesShown: newTimesShown,
      timesAccepted: newTimesAccepted,
      acceptanceRate: newAcceptanceRate,
    })

    return { rule: updatedRule }
  })

// Delete a pairing rule
export const deleteMealPairingRuleFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ ruleId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.mealPairingRules.delete(data.ruleId)

    return { success: true }
  })

// ============================================
// OFFER ANALYTICS
// ============================================

export const getOfferAnalyticsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        offerId: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [Query.limit(1000)]

    if (data?.offerId) {
      queries.push(Query.equal('offerId', [data.offerId]))
    }

    if (data?.startDate) {
      queries.push(Query.greaterThanEqual('displayedAt', [data.startDate]))
    }

    if (data?.endDate) {
      queries.push(Query.lessThanEqual('displayedAt', [data.endDate]))
    }

    const impressions = await db.offerImpressions.list(queries)

    // Calculate metrics
    const totalImpressions = impressions.total
    const accepted = impressions.rows.filter((i) => i.wasAccepted).length
    const dismissed = impressions.rows.filter((i) => i.wasDismissed).length
    const converted = impressions.rows.filter((i) => i.resultingOrderId).length

    const acceptanceRate =
      totalImpressions > 0 ? accepted / totalImpressions : 0
    const dismissalRate =
      totalImpressions > 0 ? dismissed / totalImpressions : 0
    const conversionRate =
      totalImpressions > 0 ? converted / totalImpressions : 0

    // Group by offer
    const offerStats: Record<
      string,
      {
        impressions: number
        accepted: number
        dismissed: number
        converted: number
      }
    > = {}

    for (const impression of impressions.rows) {
      if (!offerStats[impression.offerId]) {
        offerStats[impression.offerId] = {
          impressions: 0,
          accepted: 0,
          dismissed: 0,
          converted: 0,
        }
      }
      offerStats[impression.offerId].impressions++
      if (impression.wasAccepted) offerStats[impression.offerId].accepted++
      if (impression.wasDismissed) offerStats[impression.offerId].dismissed++
      if (impression.resultingOrderId)
        offerStats[impression.offerId].converted++
    }

    return {
      summary: {
        totalImpressions,
        accepted,
        dismissed,
        converted,
        acceptanceRate: Math.round(acceptanceRate * 100),
        dismissalRate: Math.round(dismissalRate * 100),
        conversionRate: Math.round(conversionRate * 100),
      },
      byOffer: offerStats,
    }
  })

// ============================================
// QUICK OFFER TEMPLATES
// ============================================

export const createQuickOfferFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      template: z.enum([
        'afternoon_soup_deal',
        'lunch_rush_combo',
        'happy_hour_drinks',
        'weekend_brunch',
        'late_night_snack',
      ]),
      mealId: z.string().optional(),
      discountValue: z.number().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const now = new Date()
    const tomorrow = new Date(now)
    tomorrow.setDate(tomorrow.getDate() + 1)

    const templates: Record<
      string,
      {
        offerType: string
        title: string
        description: string
        triggerType: string
        triggerTimeStart: string
        triggerTimeEnd: string
        discountType: string
        discountValue: number
        priority: number
      }
    > = {
      afternoon_soup_deal: {
        offerType: 'time_deal',
        title: '🍲 50% Off Soup After 3 PM!',
        description: 'Warm up with our delicious soups at half price',
        triggerType: 'time',
        triggerTimeStart: '15:00',
        triggerTimeEnd: '17:00',
        discountType: 'percentage',
        discountValue: 50,
        priority: 8,
      },
      lunch_rush_combo: {
        offerType: 'bundle',
        title: '⚡ Lunch Rush Combo Deal',
        description: 'Get a drink free with any main course',
        triggerType: 'time',
        triggerTimeStart: '11:30',
        triggerTimeEnd: '13:30',
        discountType: 'fixed',
        discountValue: 3,
        priority: 9,
      },
      happy_hour_drinks: {
        offerType: 'time_deal',
        title: '🍹 Happy Hour: 2-for-1 Drinks',
        description: 'Buy one drink, get one free!',
        triggerType: 'time',
        triggerTimeStart: '17:00',
        triggerTimeEnd: '19:00',
        discountType: 'bogo',
        discountValue: 100,
        priority: 8,
      },
      weekend_brunch: {
        offerType: 'time_deal',
        title: '🥞 Weekend Brunch Special',
        description: '20% off all breakfast items',
        triggerType: 'time',
        triggerTimeStart: '09:00',
        triggerTimeEnd: '12:00',
        discountType: 'percentage',
        discountValue: 20,
        priority: 7,
      },
      late_night_snack: {
        offerType: 'time_deal',
        title: '🌙 Late Night Munchies',
        description: 'Snacks at special prices after 9 PM',
        triggerType: 'time',
        triggerTimeStart: '21:00',
        triggerTimeEnd: '23:00',
        discountType: 'percentage',
        discountValue: 25,
        priority: 6,
      },
    }

    const template = templates[data.template]
    if (!template) throw new Error('Invalid template')

    const offer = await db.contextualOffers.create({
      createdBy: currentUser.$id,
      offerType: template.offerType,
      title: template.title,
      description: template.description,
      triggerType: template.triggerType,
      triggerMealId: data.mealId || null,
      triggerCategory: null,
      triggerTimeStart: template.triggerTimeStart,
      triggerTimeEnd: template.triggerTimeEnd,
      triggerDaysOfWeek: null,
      suggestedMealId: data.mealId || null,
      suggestedAddOnId: null,
      discountType: template.discountType,
      discountValue: data.discountValue ?? template.discountValue,
      requiresPastPurchase: false,
      minInventoryLevel: null,
      priority: template.priority,
      validFrom: now.toISOString(),
      validUntil: tomorrow.toISOString(),
      isActive: true,
    })

    return { offer }
  })
