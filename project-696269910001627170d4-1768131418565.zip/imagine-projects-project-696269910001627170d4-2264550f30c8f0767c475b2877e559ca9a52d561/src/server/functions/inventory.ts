import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { Ingredients, Inventory } from '../lib/appwrite.types'

// ============================================
// INGREDIENT MANAGEMENT
// ============================================

// Get all ingredients
export const getIngredientsFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        category: z.string().optional(),
        search: z.string().optional(),
        availableOnly: z.boolean().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries: string[] = []

    if (data?.availableOnly) {
      queries.push(Query.equal('isAvailable', [true]))
    }

    if (data?.category) {
      queries.push(Query.equal('category', [data.category]))
    }

    if (data?.search) {
      queries.push(Query.search('name', data.search))
    }

    const ingredients = await db.ingredients.list(queries)

    return { ingredients: ingredients.rows, total: ingredients.total }
  })

// Create ingredient
export const createIngredientFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      name: z.string().min(1).max(200),
      category: z.string().optional(),
      unit: z.string().min(1).max(50),
      costPerUnit: z.number().min(0).optional(),
      allergens: z.array(z.string()).optional(),
      isAvailable: z.boolean().default(true),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const ingredient = await db.ingredients.create({
      createdBy: currentUser.$id,
      name: data.name.trim(),
      category: data.category || null,
      unit: data.unit,
      costPerUnit: data.costPerUnit || null,
      allergens: data.allergens || null,
      isAvailable: data.isAvailable,
    })

    return { ingredient }
  })

// Update ingredient
export const updateIngredientFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      ingredientId: z.string(),
      updates: z.object({
        name: z.string().min(1).max(200).optional(),
        category: z.string().optional(),
        unit: z.string().min(1).max(50).optional(),
        costPerUnit: z.number().min(0).optional(),
        allergens: z.array(z.string()).optional(),
        isAvailable: z.boolean().optional(),
      }),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Partial<
      Omit<Ingredients, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {}

    if (data.updates.name !== undefined) updates.name = data.updates.name.trim()
    if (data.updates.category !== undefined)
      updates.category = data.updates.category || null
    if (data.updates.unit !== undefined) updates.unit = data.updates.unit
    if (data.updates.costPerUnit !== undefined)
      updates.costPerUnit = data.updates.costPerUnit || null
    if (data.updates.allergens !== undefined)
      updates.allergens = data.updates.allergens || null
    if (data.updates.isAvailable !== undefined)
      updates.isAvailable = data.updates.isAvailable

    const ingredient = await db.ingredients.update(data.ingredientId, updates)

    return { ingredient }
  })

// Delete ingredient
export const deleteIngredientFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ ingredientId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.ingredients.delete(data.ingredientId)

    return { success: true }
  })

// ============================================
// INVENTORY MANAGEMENT
// ============================================

// Get inventory status
export const getInventoryFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        lowStockOnly: z.boolean().optional(),
        expiringWithinDays: z.number().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const inventory = await db.inventory.list([])

    // Get all ingredients for reference
    const ingredientIds = [
      ...new Set(inventory.rows.map((i) => i.ingredientId)),
    ]
    let ingredients: Ingredients[] = []
    if (ingredientIds.length > 0) {
      const ingredientsResult = await db.ingredients.list([
        Query.equal('$id', ingredientIds),
      ])
      ingredients = ingredientsResult.rows
    }

    // Enrich inventory with ingredient details
    let enrichedInventory = inventory.rows.map((inv) => {
      const ingredient = ingredients.find((i) => i.$id === inv.ingredientId)
      return {
        ...inv,
        ingredient,
        isLowStock: inv.minimumThreshold
          ? inv.quantityInStock <= inv.minimumThreshold
          : false,
      }
    })

    // Filter by low stock
    if (data?.lowStockOnly) {
      enrichedInventory = enrichedInventory.filter((inv) => inv.isLowStock)
    }

    // Filter by expiring soon
    if (data?.expiringWithinDays) {
      const cutoffDate = new Date()
      cutoffDate.setDate(cutoffDate.getDate() + data.expiringWithinDays)
      enrichedInventory = enrichedInventory.filter((inv) => {
        if (!inv.expiresAt) return false
        return new Date(inv.expiresAt) <= cutoffDate
      })
    }

    // Calculate summary stats
    const stats = {
      totalItems: enrichedInventory.length,
      lowStockItems: enrichedInventory.filter((i) => i.isLowStock).length,
      expiringItems: enrichedInventory.filter((i) => {
        if (!i.expiresAt) return false
        const weekFromNow = new Date()
        weekFromNow.setDate(weekFromNow.getDate() + 7)
        return new Date(i.expiresAt) <= weekFromNow
      }).length,
    }

    return { inventory: enrichedInventory, stats }
  })

// Update inventory quantity
export const updateInventoryFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      ingredientId: z.string(),
      quantityChange: z.number(), // Positive for add, negative for subtract
      reason: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Find existing inventory record
    const existing = await db.inventory.list([
      Query.equal('ingredientId', [data.ingredientId]),
      Query.limit(1),
    ])

    if (existing.rows.length === 0) {
      // Create new inventory record
      if (data.quantityChange < 0) {
        throw new Error('Cannot subtract from non-existent inventory')
      }

      const inventory = await db.inventory.create({
        createdBy: currentUser.$id,
        ingredientId: data.ingredientId,
        quantityInStock: data.quantityChange,
        minimumThreshold: null,
        lastRestockedAt: new Date().toISOString(),
        expiresAt: null,
      })

      return { inventory }
    }

    const currentQuantity = existing.rows[0].quantityInStock
    const newQuantity = currentQuantity + data.quantityChange

    if (newQuantity < 0) {
      throw new Error('Insufficient inventory')
    }

    const updates: Partial<
      Omit<Inventory, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {
      quantityInStock: newQuantity,
    }

    if (data.quantityChange > 0) {
      updates.lastRestockedAt = new Date().toISOString()
    }

    const inventory = await db.inventory.update(existing.rows[0].$id, updates)

    return { inventory }
  })

// Set inventory thresholds
export const setInventoryThresholdFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      inventoryId: z.string(),
      minimumThreshold: z.number().min(0),
      expiresAt: z.string().optional(), // ISO datetime
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Partial<
      Omit<Inventory, '$id' | '$createdAt' | '$updatedAt' | 'createdBy'>
    > = {
      minimumThreshold: data.minimumThreshold,
    }

    if (data.expiresAt !== undefined) {
      updates.expiresAt = data.expiresAt || null
    }

    const inventory = await db.inventory.update(data.inventoryId, updates)

    return { inventory }
  })

// Restock inventory
export const restockInventoryFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      ingredientId: z.string(),
      quantity: z.number().positive(),
      expiresAt: z.string().optional(), // ISO datetime
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Find existing inventory record
    const existing = await db.inventory.list([
      Query.equal('ingredientId', [data.ingredientId]),
      Query.limit(1),
    ])

    if (existing.rows.length === 0) {
      // Create new inventory record
      const inventory = await db.inventory.create({
        createdBy: currentUser.$id,
        ingredientId: data.ingredientId,
        quantityInStock: data.quantity,
        minimumThreshold: null,
        lastRestockedAt: new Date().toISOString(),
        expiresAt: data.expiresAt || null,
      })

      return { inventory }
    }

    const inventory = await db.inventory.update(existing.rows[0].$id, {
      quantityInStock: existing.rows[0].quantityInStock + data.quantity,
      lastRestockedAt: new Date().toISOString(),
      expiresAt: data.expiresAt || existing.rows[0].expiresAt,
    })

    return { inventory }
  })

// ============================================
// MEAL-INGREDIENT RELATIONSHIPS
// ============================================

// Get ingredients for a meal
export const getMealIngredientsFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ mealId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const mealIngredients = await db.mealIngredients.list([
      Query.equal('mealId', [data.mealId]),
    ])

    // Get ingredient details
    const ingredientIds = mealIngredients.rows.map((mi) => mi.ingredientId)
    let ingredients: Ingredients[] = []
    if (ingredientIds.length > 0) {
      const ingredientsResult = await db.ingredients.list([
        Query.equal('$id', ingredientIds),
      ])
      ingredients = ingredientsResult.rows
    }

    // Enrich with ingredient details
    const enriched = mealIngredients.rows.map((mi) => ({
      ...mi,
      ingredient: ingredients.find((i) => i.$id === mi.ingredientId),
    }))

    return { mealIngredients: enriched }
  })

// Add ingredient to meal
export const addMealIngredientFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      ingredientId: z.string(),
      quantityRequired: z.number().positive(),
      isOptional: z.boolean().default(false),
      isRemovable: z.boolean().default(true),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const mealIngredient = await db.mealIngredients.create({
      createdBy: currentUser.$id,
      mealId: data.mealId,
      ingredientId: data.ingredientId,
      quantityRequired: data.quantityRequired,
      isOptional: data.isOptional,
      isRemovable: data.isRemovable,
    })

    return { mealIngredient }
  })

// Remove ingredient from meal
export const removeMealIngredientFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ mealIngredientId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.mealIngredients.delete(data.mealIngredientId)

    return { success: true }
  })

// ============================================
// AVAILABILITY CHECKS
// ============================================

// Check if a meal can be made (has all required ingredients in stock)
export const checkMealAvailabilityFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      quantity: z.number().positive().default(1),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get meal ingredients
    const mealIngredients = await db.mealIngredients.list([
      Query.equal('mealId', [data.mealId]),
    ])

    if (mealIngredients.rows.length === 0) {
      // No ingredients defined, assume available
      return { available: true, missingIngredients: [] }
    }

    // Get inventory for all required ingredients
    const ingredientIds = mealIngredients.rows.map((mi) => mi.ingredientId)
    const inventory = await db.inventory.list([
      Query.equal('ingredientId', ingredientIds),
    ])

    // Check each required ingredient
    const missingIngredients: Array<{
      ingredientId: string
      required: number
      available: number
    }> = []

    for (const mi of mealIngredients.rows) {
      if (mi.isOptional) continue

      const inv = inventory.rows.find((i) => i.ingredientId === mi.ingredientId)
      const available = inv?.quantityInStock || 0
      const required = mi.quantityRequired * data.quantity

      if (available < required) {
        missingIngredients.push({
          ingredientId: mi.ingredientId,
          required,
          available,
        })
      }
    }

    return {
      available: missingIngredients.length === 0,
      missingIngredients,
    }
  })

// Deduct ingredients from inventory when order is placed
export const deductInventoryForOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      mealId: z.string(),
      quantity: z.number().positive(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Get meal ingredients
    const mealIngredients = await db.mealIngredients.list([
      Query.equal('mealId', [data.mealId]),
    ])

    // Deduct each ingredient
    for (const mi of mealIngredients.rows) {
      const inventory = await db.inventory.list([
        Query.equal('ingredientId', [mi.ingredientId]),
        Query.limit(1),
      ])

      if (inventory.rows.length > 0) {
        const newQuantity = Math.max(
          0,
          inventory.rows[0].quantityInStock -
            mi.quantityRequired * data.quantity,
        )
        await db.inventory.update(inventory.rows[0].$id, {
          quantityInStock: newQuantity,
        })
      }
    }

    return { success: true }
  })
