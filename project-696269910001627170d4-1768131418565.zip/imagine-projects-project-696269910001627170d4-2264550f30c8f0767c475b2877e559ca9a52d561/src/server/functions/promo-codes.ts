import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { Query } from 'node-appwrite'
import { db } from '../lib/db'
import { authMiddleware } from './auth'
import type { PromoCodes } from '../lib/appwrite.types'

// ============================================
// PROMO CODE VALIDATION & REDEMPTION
// ============================================

// Validate a promo code
export const validatePromoCodeFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      code: z.string().min(1).max(50),
      orderTotal: z.number().positive(),
      mealIds: z.array(z.string()).optional(),
      categories: z.array(z.string()).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const now = new Date().toISOString()

    // Find the promo code
    const promoCodes = await db.promoCodes.list([
      Query.equal('code', [data.code.toUpperCase()]),
      Query.equal('isActive', [true]),
      Query.limit(1),
    ])

    if (promoCodes.rows.length === 0) {
      return {
        valid: false,
        error: 'Invalid promo code',
      }
    }

    const promo = promoCodes.rows[0]

    // Check validity period
    if (now < promo.validFrom || now > promo.validUntil) {
      return {
        valid: false,
        error: 'This promo code has expired',
      }
    }

    // Check usage limits
    if (
      promo.maxUses &&
      promo.currentUses &&
      promo.currentUses >= promo.maxUses
    ) {
      return {
        valid: false,
        error: 'This promo code has reached its usage limit',
      }
    }

    // Check if user has already used this code
    const userRedemptions = await db.promoRedemptions.list([
      Query.equal('promoCodeId', [promo.$id]),
      Query.equal('createdBy', [currentUser.$id]),
    ])

    if (userRedemptions.rows.length > 0) {
      return {
        valid: false,
        error: 'You have already used this promo code',
      }
    }

    // Check minimum order amount
    if (promo.minOrderAmount && data.orderTotal < promo.minOrderAmount) {
      return {
        valid: false,
        error: `Minimum order of $${promo.minOrderAmount.toFixed(2)} required`,
      }
    }

    // Check applicable meals/categories
    if (promo.applicableMealIds && promo.applicableMealIds.length > 0) {
      const hasApplicableMeal = data.mealIds?.some((id) =>
        promo.applicableMealIds?.includes(id),
      )
      if (!hasApplicableMeal) {
        return {
          valid: false,
          error: 'This promo code is not valid for the items in your cart',
        }
      }
    }

    if (promo.applicableCategories && promo.applicableCategories.length > 0) {
      const hasApplicableCategory = data.categories?.some((cat) =>
        promo.applicableCategories?.includes(cat),
      )
      if (!hasApplicableCategory) {
        return {
          valid: false,
          error: 'This promo code is not valid for the items in your cart',
        }
      }
    }

    // Calculate discount
    let discount = 0
    if (promo.discountType === 'percentage') {
      discount = data.orderTotal * (promo.discountValue / 100)
    } else if (promo.discountType === 'fixed') {
      discount = promo.discountValue
    }

    // Apply max discount cap
    if (promo.maxDiscountAmount && discount > promo.maxDiscountAmount) {
      discount = promo.maxDiscountAmount
    }

    // Ensure discount doesn't exceed order total
    discount = Math.min(discount, data.orderTotal)

    return {
      valid: true,
      promoCode: promo,
      discount: Math.round(discount * 100) / 100,
      discountType: promo.discountType,
      discountValue: promo.discountValue,
    }
  })

// Redeem a promo code (called when order is placed)
export const redeemPromoCodeFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      promoCodeId: z.string(),
      orderId: z.string(),
      discountApplied: z.number().min(0),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Create redemption record
    const redemption = await db.promoRedemptions.create({
      createdBy: currentUser.$id,
      promoCodeId: data.promoCodeId,
      orderId: data.orderId,
      discountApplied: data.discountApplied,
    })

    // Increment usage count
    const promo = await db.promoCodes.get(data.promoCodeId)
    await db.promoCodes.update(data.promoCodeId, {
      currentUses: (promo.currentUses || 0) + 1,
    })

    return { redemption }
  })

// ============================================
// ADMIN PROMO CODE MANAGEMENT
// ============================================

// Get all promo codes
export const getPromoCodesFn = createServerFn({ method: 'GET' })
  .inputValidator(
    z
      .object({
        activeOnly: z.boolean().optional(),
        limit: z.number().min(1).max(100).optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const queries = [
      Query.orderDesc('$createdAt'),
      Query.limit(data?.limit || 50),
    ]

    if (data?.activeOnly) {
      queries.push(Query.equal('isActive', [true]))
    }

    const promoCodes = await db.promoCodes.list(queries)

    return { promoCodes: promoCodes.rows, total: promoCodes.total }
  })

// Create promo code
export const createPromoCodeFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      code: z.string().min(3).max(50),
      discountType: z.enum(['percentage', 'fixed']),
      discountValue: z.number().positive(),
      minOrderAmount: z.number().min(0).optional(),
      maxDiscountAmount: z.number().positive().optional(),
      validFrom: z.string(), // ISO datetime
      validUntil: z.string(), // ISO datetime
      maxUses: z.number().positive().optional(),
      applicableMealIds: z.array(z.string()).optional(),
      applicableCategories: z.array(z.string()).optional(),
      isActive: z.boolean().default(true),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    // Check if code already exists
    const existing = await db.promoCodes.list([
      Query.equal('code', [data.code.toUpperCase()]),
    ])

    if (existing.rows.length > 0) {
      throw new Error('A promo code with this code already exists')
    }

    const promoCode = await db.promoCodes.create({
      createdBy: currentUser.$id,
      code: data.code.toUpperCase(),
      discountType: data.discountType,
      discountValue: data.discountValue,
      minOrderAmount: data.minOrderAmount || null,
      maxDiscountAmount: data.maxDiscountAmount || null,
      validFrom: data.validFrom,
      validUntil: data.validUntil,
      maxUses: data.maxUses || null,
      currentUses: 0,
      applicableMealIds: data.applicableMealIds || null,
      applicableCategories: data.applicableCategories || null,
      isActive: data.isActive,
    })

    return { promoCode }
  })

// Update promo code
export const updatePromoCodeFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      promoCodeId: z.string(),
      updates: z.object({
        discountType: z.enum(['percentage', 'fixed']).optional(),
        discountValue: z.number().positive().optional(),
        minOrderAmount: z.number().min(0).optional(),
        maxDiscountAmount: z.number().positive().optional(),
        validFrom: z.string().optional(),
        validUntil: z.string().optional(),
        maxUses: z.number().positive().optional(),
        applicableMealIds: z.array(z.string()).optional(),
        applicableCategories: z.array(z.string()).optional(),
        isActive: z.boolean().optional(),
      }),
    }),
  )
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const updates: Partial<
      Omit<
        PromoCodes,
        '$id' | '$createdAt' | '$updatedAt' | 'createdBy' | 'code'
      >
    > = {}

    if (data.updates.discountType !== undefined)
      updates.discountType = data.updates.discountType
    if (data.updates.discountValue !== undefined)
      updates.discountValue = data.updates.discountValue
    if (data.updates.minOrderAmount !== undefined)
      updates.minOrderAmount = data.updates.minOrderAmount || null
    if (data.updates.maxDiscountAmount !== undefined)
      updates.maxDiscountAmount = data.updates.maxDiscountAmount || null
    if (data.updates.validFrom !== undefined)
      updates.validFrom = data.updates.validFrom
    if (data.updates.validUntil !== undefined)
      updates.validUntil = data.updates.validUntil
    if (data.updates.maxUses !== undefined)
      updates.maxUses = data.updates.maxUses || null
    if (data.updates.applicableMealIds !== undefined)
      updates.applicableMealIds = data.updates.applicableMealIds || null
    if (data.updates.applicableCategories !== undefined)
      updates.applicableCategories = data.updates.applicableCategories || null
    if (data.updates.isActive !== undefined)
      updates.isActive = data.updates.isActive

    const promoCode = await db.promoCodes.update(data.promoCodeId, updates)

    return { promoCode }
  })

// Delete promo code
export const deletePromoCodeFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ promoCodeId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    await db.promoCodes.delete(data.promoCodeId)

    return { success: true }
  })

// Toggle promo code active status
export const togglePromoCodeStatusFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ promoCodeId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const promo = await db.promoCodes.get(data.promoCodeId)
    const promoCode = await db.promoCodes.update(data.promoCodeId, {
      isActive: !promo.isActive,
    })

    return { promoCode }
  })

// Get promo code usage statistics
export const getPromoCodeStatsFn = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ promoCodeId: z.string() }))
  .handler(async ({ data }) => {
    const { currentUser } = await authMiddleware()
    if (!currentUser) throw new Error('Unauthorized')

    const promo = await db.promoCodes.get(data.promoCodeId)

    const redemptions = await db.promoRedemptions.list([
      Query.equal('promoCodeId', [data.promoCodeId]),
    ])

    const totalDiscountGiven = redemptions.rows.reduce(
      (sum, r) => sum + r.discountApplied,
      0,
    )

    return {
      promoCode: promo,
      stats: {
        totalRedemptions: redemptions.rows.length,
        totalDiscountGiven,
        remainingUses: promo.maxUses
          ? promo.maxUses - (promo.currentUses || 0)
          : null,
      },
    }
  })
