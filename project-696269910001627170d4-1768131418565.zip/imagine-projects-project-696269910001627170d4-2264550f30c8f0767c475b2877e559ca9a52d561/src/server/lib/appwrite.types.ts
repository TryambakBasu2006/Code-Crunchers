import { type Models } from 'node-appwrite'

export type Meals = Models.Row & {
  createdBy: string
  name: string
  description: string | null
  price: number
  category: string | null
  calories: number | null
  allergens: string[] | null
  isAvailable: boolean
  imageId: string | null
}

export type Orders = Models.Row & {
  createdBy: string
  mealIds: string[]
  quantities: number[]
  totalPrice: number
  status: string
  notes: string | null
  pickupTime: string | null
}

export type Favorites = Models.Row & {
  createdBy: string
  mealId: string
}

export type DietaryProfiles = Models.Row & {
  createdBy: string
  dietaryRestrictions: string[] | null
  allergens: string[] | null
  dislikes: string[] | null
  preferences: string[] | null
  calorieGoal: number | null
  proteinGoal: number | null
}

export type Reviews = Models.Row & {
  createdBy: string
  mealId: string
  orderId: string | null
  rating: number
  comment: string | null
  isVerifiedPurchase: boolean
}

export type Recommendations = Models.Row & {
  createdBy: string
  mealId: string
  reason: string
  reasonType: string | null
  score: number | null
  expiresAt: string | null
}

export type Ingredients = Models.Row & {
  createdBy: string
  name: string
  category: string | null
  unit: string
  costPerUnit: number | null
  allergens: string[] | null
  isAvailable: boolean
}

export type Inventory = Models.Row & {
  createdBy: string
  ingredientId: string
  quantityInStock: number
  minimumThreshold: number | null
  lastRestockedAt: string | null
  expiresAt: string | null
}

export type OrderItems = Models.Row & {
  createdBy: string
  orderId: string
  mealId: string
  quantity: number
  unitPrice: number
  totalPrice: number
  portionSize: string | null
  spiceLevel: string | null
  addOns: string[] | null
  addOnPrices: number[] | null
  dietaryPreferences: string[] | null
  specialInstructions: string | null
}

export type MealIngredients = Models.Row & {
  createdBy: string
  mealId: string
  ingredientId: string
  quantityRequired: number
  isOptional: boolean
  isRemovable: boolean
}

export type Notifications = Models.Row & {
  createdBy: string
  orderId: string | null
  type: string
  title: string
  message: string
  isRead: boolean
  channel: string | null
  sentAt: string | null
}

export type AddOns = Models.Row & {
  createdBy: string
  name: string
  price: number
  calories: number | null
  category: string | null
  allergens: string[] | null
  isAvailable: boolean
  applicableMealCategories: string[] | null
}

export type Payments = Models.Row & {
  createdBy: string
  orderId: string
  amount: number
  currency: string
  status: string
  paymentMethod: string | null
  transactionId: string | null
  gatewayResponse: string | null
  paidAt: string | null
  refundedAt: string | null
}

export type DailySpecials = Models.Row & {
  createdBy: string
  mealId: string
  discountPercent: number | null
  specialPrice: number | null
  validFrom: string
  validUntil: string
  maxQuantity: number | null
  soldCount: number | null
}

export type OrderHistory = Models.Row & {
  createdBy: string
  orderId: string
  previousStatus: string | null
  newStatus: string
  changedBy: string
  notes: string | null
}

export type UserProfiles = Models.Row & {
  createdBy: string
  displayName: string | null
  phoneNumber: string | null
  avatarFileId: string | null
  ssoProvider: string | null
  notifyByPush: boolean
  notifyBySms: boolean
  notifyByEmail: boolean
  preferredPickupLocation: string | null
  defaultPaymentMethod: string | null
  stripeCustomerId: string | null
  isStaff: boolean
  isAdmin: boolean
  gdprConsentAt: string | null
  marketingConsentAt: string | null
}

export type PromoCodes = Models.Row & {
  createdBy: string
  code: string
  discountType: string
  discountValue: number
  minOrderAmount: number | null
  maxDiscountAmount: number | null
  validFrom: string
  validUntil: string
  maxUses: number | null
  currentUses: number | null
  applicableMealIds: string[] | null
  applicableCategories: string[] | null
  isActive: boolean
}

export type KitchenQueue = Models.Row & {
  createdBy: string
  orderId: string
  orderItemId: string | null
  station: string | null
  status: string
  priority: number | null
  assignedTo: string | null
  estimatedPrepTime: number | null
  startedAt: string | null
  completedAt: string | null
  displayPosition: number | null
}

export type PromoRedemptions = Models.Row & {
  createdBy: string
  promoCodeId: string
  orderId: string
  discountApplied: number
}

export type UserSimilarity = Models.Row & {
  createdBy: string
  similarUserId: string
  similarityScore: number
  algorithmVersion: string | null
  sharedMealCount: number | null
  calculatedAt: string | null
}

export type MealEmbeddings = Models.Row & {
  createdBy: string
  mealId: string
  embeddingVector: string
  featureTags: string[] | null
  cuisineType: string | null
  flavorProfile: string[] | null
  proteinContent: number | null
  carbContent: number | null
  fatContent: number | null
  spiceLevel: number | null
  modelVersion: string | null
  generatedAt: string | null
}

export type UserTasteProfile = Models.Row & {
  createdBy: string
  preferredCuisines: string[] | null
  avoidedCuisines: string[] | null
  flavorPreferences: string[] | null
  spiceTolerance: number | null
  preferredProteins: string[] | null
  avoidedIngredients: string[] | null
  preferredMealTimes: string[] | null
  avgOrderFrequency: number | null
  preferredPortionSize: string | null
  budgetPreference: string | null
  tasteVector: string | null
  lastUpdatedAt: string | null
}

export type ContextualOffers = Models.Row & {
  createdBy: string
  offerType: string
  title: string
  description: string | null
  triggerType: string
  triggerMealId: string | null
  triggerCategory: string | null
  triggerTimeStart: string | null
  triggerTimeEnd: string | null
  triggerDaysOfWeek: string[] | null
  suggestedMealId: string | null
  suggestedAddOnId: string | null
  discountType: string | null
  discountValue: number | null
  requiresPastPurchase: boolean
  minInventoryLevel: number | null
  priority: number | null
  validFrom: string | null
  validUntil: string | null
  isActive: boolean
}

export type OfferImpressions = Models.Row & {
  createdBy: string
  offerId: string
  impressionType: string
  wasAccepted: boolean
  wasDismissed: boolean
  resultingOrderId: string | null
  contextMealId: string | null
  displayedAt: string | null
  respondedAt: string | null
}

export type MlModelMetadata = Models.Row & {
  createdBy: string
  modelName: string
  modelType: string
  version: string
  endpoint: string | null
  accuracy: number | null
  trainingDataSize: number | null
  hyperparameters: string | null
  isActive: boolean
  trainedAt: string | null
  deployedAt: string | null
}

export type MealPairingRules = Models.Row & {
  createdBy: string
  primaryMealId: string
  pairedItemId: string
  pairedItemType: string
  pairingScore: number | null
  pairingReason: string | null
  isMLGenerated: boolean
  acceptanceRate: number | null
  timesShown: number | null
  timesAccepted: number | null
}

export type InventoryAlerts = Models.Row & {
  createdBy: string
  ingredientId: string
  mealId: string | null
  alertType: string
  previousQuantity: number | null
  currentQuantity: number
  thresholdTriggered: number | null
  isResolved: boolean
  resolvedAt: string | null
  resolvedBy: string | null
}

export type MealAvailability = Models.Row & {
  createdBy: string
  mealId: string
  isAvailable: boolean
  availableQuantity: number | null
  unavailableReason: string | null
  missingIngredients: string[] | null
  estimatedRestockAt: string | null
  lastCheckedAt: string | null
}

export type ScheduledOrders = Models.Row & {
  createdBy: string
  orderId: string
  scheduledPickupTime: string
  releaseToKitchenAt: string
  queueStatus: string
  estimatedPrepTime: number | null
  priority: number | null
  releasedAt: string | null
  failureReason: string | null
  retryCount: number | null
  maxRetries: number | null
}

export type MealRatingAggregates = Models.Row & {
  createdBy: string
  mealId: string
  averageRating: number
  totalReviews: number
  rating5Count: number | null
  rating4Count: number | null
  rating3Count: number | null
  rating2Count: number | null
  rating1Count: number | null
  verifiedPurchaseCount: number | null
  sentimentScore: number | null
  commonPositiveTags: string[] | null
  commonNegativeTags: string[] | null
  lastCalculatedAt: string | null
}
