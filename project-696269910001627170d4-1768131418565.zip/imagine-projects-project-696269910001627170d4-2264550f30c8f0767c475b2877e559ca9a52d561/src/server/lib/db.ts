import {
  Client,
  TablesDB,
  ID,
  type Models,
  Permission,
  Role,
} from 'node-appwrite'
import type {
  Meals,
  Orders,
  Favorites,
  DietaryProfiles,
  Reviews,
  Recommendations,
  Ingredients,
  Inventory,
  OrderItems,
  MealIngredients,
  Notifications,
  AddOns,
  Payments,
  DailySpecials,
  OrderHistory,
  UserProfiles,
  PromoCodes,
  KitchenQueue,
  PromoRedemptions,
  UserSimilarity,
  MealEmbeddings,
  UserTasteProfile,
  ContextualOffers,
  OfferImpressions,
  MlModelMetadata,
  MealPairingRules,
  InventoryAlerts,
  MealAvailability,
  ScheduledOrders,
  MealRatingAggregates,
} from './appwrite.types'

const client = new Client()
  .setEndpoint(process.env.APPWRITE_ENDPOINT!)
  .setProject(process.env.APPWRITE_PROJECT_ID!)
  .setKey(process.env.APPWRITE_API_KEY!)

const tablesDB = new TablesDB(client)

export const db = {
  meals: {
    create: (
      data: Omit<Meals, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Meals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meals',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Meals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meals',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Meals, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Meals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meals',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meals',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Meals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meals',
        queries,
      }),
  },
  orders: {
    create: (
      data: Omit<Orders, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Orders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'orders',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Orders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'orders',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Orders, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Orders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'orders',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'orders',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Orders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'orders',
        queries,
      }),
  },
  favorites: {
    create: (
      data: Omit<Favorites, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Favorites>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'favorites',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Favorites>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'favorites',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Favorites, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Favorites>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'favorites',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'favorites',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Favorites>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'favorites',
        queries,
      }),
  },
  dietaryProfiles: {
    create: (
      data: Omit<DietaryProfiles, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<DietaryProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'dietary-profiles',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<DietaryProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'dietary-profiles',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<DietaryProfiles, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<DietaryProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'dietary-profiles',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'dietary-profiles',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<DietaryProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'dietary-profiles',
        queries,
      }),
  },
  reviews: {
    create: (
      data: Omit<Reviews, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Reviews>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'reviews',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Reviews>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'reviews',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Reviews, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Reviews>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'reviews',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'reviews',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Reviews>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'reviews',
        queries,
      }),
  },
  recommendations: {
    create: (
      data: Omit<Recommendations, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Recommendations>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'recommendations',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Recommendations>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'recommendations',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Recommendations, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Recommendations>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'recommendations',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'recommendations',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Recommendations>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'recommendations',
        queries,
      }),
  },
  ingredients: {
    create: (
      data: Omit<Ingredients, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Ingredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ingredients',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Ingredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ingredients',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Ingredients, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Ingredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ingredients',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ingredients',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Ingredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ingredients',
        queries,
      }),
  },
  inventory: {
    create: (
      data: Omit<Inventory, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Inventory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Inventory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Inventory, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Inventory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Inventory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory',
        queries,
      }),
  },
  orderItems: {
    create: (
      data: Omit<OrderItems, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<OrderItems>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-items',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<OrderItems>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-items',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<OrderItems, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<OrderItems>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-items',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-items',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<OrderItems>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-items',
        queries,
      }),
  },
  mealIngredients: {
    create: (
      data: Omit<MealIngredients, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MealIngredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-ingredients',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MealIngredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-ingredients',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MealIngredients, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MealIngredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-ingredients',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-ingredients',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MealIngredients>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-ingredients',
        queries,
      }),
  },
  notifications: {
    create: (
      data: Omit<Notifications, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Notifications>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'notifications',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Notifications>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'notifications',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Notifications, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Notifications>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'notifications',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'notifications',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Notifications>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'notifications',
        queries,
      }),
  },
  addOns: {
    create: (
      data: Omit<AddOns, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<AddOns>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'add-ons',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<AddOns>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'add-ons',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<AddOns, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<AddOns>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'add-ons',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'add-ons',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<AddOns>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'add-ons',
        queries,
      }),
  },
  payments: {
    create: (
      data: Omit<Payments, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Payments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'payments',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Payments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'payments',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Payments, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Payments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'payments',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'payments',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Payments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'payments',
        queries,
      }),
  },
  dailySpecials: {
    create: (
      data: Omit<DailySpecials, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<DailySpecials>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'daily-specials',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<DailySpecials>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'daily-specials',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<DailySpecials, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<DailySpecials>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'daily-specials',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'daily-specials',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<DailySpecials>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'daily-specials',
        queries,
      }),
  },
  orderHistory: {
    create: (
      data: Omit<OrderHistory, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<OrderHistory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-history',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<OrderHistory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-history',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<OrderHistory, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<OrderHistory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-history',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-history',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<OrderHistory>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'order-history',
        queries,
      }),
  },
  userProfiles: {
    create: (
      data: Omit<UserProfiles, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<UserProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-profiles',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<UserProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-profiles',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<UserProfiles, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<UserProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-profiles',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-profiles',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<UserProfiles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-profiles',
        queries,
      }),
  },
  promoCodes: {
    create: (
      data: Omit<PromoCodes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<PromoCodes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-codes',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<PromoCodes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-codes',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<PromoCodes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<PromoCodes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-codes',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-codes',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<PromoCodes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-codes',
        queries,
      }),
  },
  kitchenQueue: {
    create: (
      data: Omit<KitchenQueue, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<KitchenQueue>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'kitchen-queue',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<KitchenQueue>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'kitchen-queue',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<KitchenQueue, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<KitchenQueue>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'kitchen-queue',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'kitchen-queue',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<KitchenQueue>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'kitchen-queue',
        queries,
      }),
  },
  promoRedemptions: {
    create: (
      data: Omit<PromoRedemptions, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<PromoRedemptions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-redemptions',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<PromoRedemptions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-redemptions',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<PromoRedemptions, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<PromoRedemptions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-redemptions',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-redemptions',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<PromoRedemptions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'promo-redemptions',
        queries,
      }),
  },
  userSimilarity: {
    create: (
      data: Omit<UserSimilarity, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<UserSimilarity>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-similarity',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<UserSimilarity>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-similarity',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<UserSimilarity, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<UserSimilarity>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-similarity',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-similarity',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<UserSimilarity>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-similarity',
        queries,
      }),
  },
  mealEmbeddings: {
    create: (
      data: Omit<MealEmbeddings, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MealEmbeddings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-embeddings',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MealEmbeddings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-embeddings',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MealEmbeddings, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MealEmbeddings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-embeddings',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-embeddings',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MealEmbeddings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-embeddings',
        queries,
      }),
  },
  userTasteProfile: {
    create: (
      data: Omit<UserTasteProfile, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<UserTasteProfile>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-taste-profile',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<UserTasteProfile>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-taste-profile',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<UserTasteProfile, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<UserTasteProfile>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-taste-profile',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-taste-profile',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<UserTasteProfile>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'user-taste-profile',
        queries,
      }),
  },
  contextualOffers: {
    create: (
      data: Omit<ContextualOffers, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ContextualOffers>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'contextual-offers',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ContextualOffers>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'contextual-offers',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ContextualOffers, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ContextualOffers>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'contextual-offers',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'contextual-offers',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ContextualOffers>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'contextual-offers',
        queries,
      }),
  },
  offerImpressions: {
    create: (
      data: Omit<OfferImpressions, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<OfferImpressions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'offer-impressions',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<OfferImpressions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'offer-impressions',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<OfferImpressions, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<OfferImpressions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'offer-impressions',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'offer-impressions',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<OfferImpressions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'offer-impressions',
        queries,
      }),
  },
  mlModelMetadata: {
    create: (
      data: Omit<MlModelMetadata, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MlModelMetadata>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ml-model-metadata',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MlModelMetadata>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ml-model-metadata',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MlModelMetadata, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MlModelMetadata>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ml-model-metadata',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ml-model-metadata',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MlModelMetadata>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ml-model-metadata',
        queries,
      }),
  },
  mealPairingRules: {
    create: (
      data: Omit<MealPairingRules, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MealPairingRules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-pairing-rules',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MealPairingRules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-pairing-rules',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MealPairingRules, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MealPairingRules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-pairing-rules',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-pairing-rules',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MealPairingRules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-pairing-rules',
        queries,
      }),
  },
  inventoryAlerts: {
    create: (
      data: Omit<InventoryAlerts, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<InventoryAlerts>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory-alerts',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<InventoryAlerts>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory-alerts',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<InventoryAlerts, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<InventoryAlerts>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory-alerts',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory-alerts',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<InventoryAlerts>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'inventory-alerts',
        queries,
      }),
  },
  mealAvailability: {
    create: (
      data: Omit<MealAvailability, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MealAvailability>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-availability',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MealAvailability>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-availability',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MealAvailability, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MealAvailability>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-availability',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-availability',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MealAvailability>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-availability',
        queries,
      }),
  },
  scheduledOrders: {
    create: (
      data: Omit<ScheduledOrders, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ScheduledOrders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'scheduled-orders',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ScheduledOrders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'scheduled-orders',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ScheduledOrders, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ScheduledOrders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'scheduled-orders',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'scheduled-orders',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ScheduledOrders>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'scheduled-orders',
        queries,
      }),
  },
  mealRatingAggregates: {
    create: (
      data: Omit<MealRatingAggregates, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<MealRatingAggregates>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-rating-aggregates',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<MealRatingAggregates>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-rating-aggregates',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<MealRatingAggregates, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<MealRatingAggregates>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-rating-aggregates',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-rating-aggregates',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<MealRatingAggregates>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'meal-rating-aggregates',
        queries,
      }),
  },
}
